# EISA 伊萨 · AGI 结构探索框架

> 仓库：`eisa-agi-structure-explore`
> 定位：**AGI 架构探索实验框架** —— 在推理外层做调度与编排，把一个可调度的超大基座（可设定至 **10T 参数量级**）的推理能力尽可能放大。

## 一、核心设计原则（硬性约束）

| 约束 | 落实方式 |
|---|---|
| 不训练、不产出权重、不写预训练/微调/梯度代码 | 全仓库无任何训练相关代码；`EisaBaseModel` 是只读黑盒抽象，刻意不提供权重级 API |
| 底层是可调度的超大基座（至 10T 参数） | `base_model.params_total = 10_000_000_000_000` 仅作调度元信息；框架只调用统一推理接口 |
| 只写调度框架、控制逻辑、智能编排 | 所有增强能力（多分支、评判、反思、规划）均实现为基座之上的外层调度逻辑 |
| 补丁/提案必须人工审核 | 自迭代引擎设有硬性安全闸门：`pending → approve → apply`，未审核代码永不生效（详见 §7） |
| Python 优先、后端可插拔 | 推理后端统一抽象：Mock（离线）/ OpenAI 兼容（vLLM、SGLang）/ 多端点扇出 |

## 二、总体架构

```
用户输入
   │
   ▼
┌──────────────────────────────────────────────────────────────┐
│                    EisaOrchestrator 总编排器                   │
│                                                              │
│  [记忆层]            [元推理层·核心]          [能力扩展钩子]    │
│  用户画像 ──┐   ┌──────────────────────┐        │            │
│  对话日志 ──┼──►│  MetaReasoningScheduler│◄──扩展 pre_reasoning│
│  EISA自我档案┘   │ 「思考自己该怎么思考」  │        │            │
│                  │  难度/类型识别          │                   │
│                  │  策略选择(4档)          │                   │
│                  │  范式×人格×预算         │                   │
│                  └──────────┬───────────┘                   │
│                             ▼                               │
│              [多分支并行推理 BranchEngine]                     │
│      N 条『人格 × 范式 × 温度』三重差异化思路并行               │
│                             ▼                               │
│              [多层自省评判器 MultiLayerJudge]                  │
│   L1独立评分 → L2交叉互评 → L3矛盾排查 → L4终审裁决            │
│              │低分 → 回溯纠错重生 │top2胶着 → 终局辩论          │
│                             ▼                               │
│              [递归反思器 RecursiveReflector]                  │
│    事实层→逻辑层→假设层→边界层→目标层，逐层扫描+修复            │
│                             ▼                               │
│        最终答案 + 运行轨迹落盘（data/runs/*.json）             │
└──────────────────────────────────────────────────────────────┘
   │失败样例/矛盾/低置信度                          ▲能力提案
   ▼                                             │
┌────────────────────── 进化层（人工闸门）──────────────────────┐
│ 缺陷库 ◄── 评判失败样例    自迭代引擎.analyze()  → 短板报告     │
│ 对话日志 ◄── 交互记录      自迭代引擎.propose() → 补丁(pending) │
│ 评测结果 ◄── 领域专项评测   人工 approve → apply → 可 rollback  │
│                           提案系统.brainstorm()→ 提案(pending) │
│                           人工 approve → 物化为扩展模块并注册   │
└──────────────────────────────────────────────────────────────┘
长程任务：TaskPlanner 拆解→任务栈→执行→里程碑复盘→失败重规划→合成
```

## 三、目录结构

```
eisa-agi-structure-explore/
├── eisa/
│   ├── core/
│   │   ├── base_model.py        # 底层超大基座统一抽象 + Mock/OpenAI兼容/多端点后端
│   │   ├── backend_registry.py  # 后端工厂（对接 vLLM / SGLang 入口）
│   │   └── types.py             # 全框架共享数据结构
│   ├── memory/
│   │   ├── user_profile.py      # ① 用户画像持久化（JSON，自动加载/动态更新）
│   │   ├── self_profile.py      # ② EISA 自我认知画像（自省档案）
│   │   ├── dialog_store.py      #   对话日志（JSONL，失败复盘数据源）
│   │   └── defect_library.py    #   缺陷库（失败样例/矛盾/低置信度）
│   ├── reasoning/
│   │   ├── meta_scheduler.py    # ⑧ 元推理调度器（重点：决定"怎么思考"）
│   │   ├── paradigm.py          #   推理范式库（数学链/工程推演/批判校验/类比/反证…12种+YAML扩展）
│   │   ├── persona_router.py    #   多人格专家路由（8种内置人格+领域专家）
│   │   ├── budget.py            #   思考预算动态分配（难度基线×领域放大×无限模式）
│   │   ├── branch_engine.py     # ⑤ 多分支并行推理引擎
│   │   └── judge.py             # ⑤ 多层自省评判器（择优 + 回溯纠错 + 终局辩论）
│   ├── planning/
│   │   ├── task_planner.py      # ⑥ 长程任务规划（拆解/任务栈/里程碑复盘/重规划）
│   │   └── recursive_reflector.py# ⑥ 递归反思链（五层扫描+逐层修复）
│   ├── domain/
│   │   ├── domain_detector.py   # ④ 领域识别（本地关键词计分+基座精化）
│   │   ├── domain_amplifier.py  # ④ 定向放大（领域包：专属思考链+专家子路由+分支加成）
│   │   └── eval_builder.py      # ④ 专项评测集（难题生成→跑分→判卷→缺陷回流）
│   ├── evolution/
│   │   ├── self_iterate_engine.py# ③ 自迭代引擎（分析短板→补丁提案→人工闸门→应用/回滚）
│   │   ├── patch_generator.py   # ③ 补丁生成（锚点替换，含风险评估）
│   │   └── proposal_system.py   # ⑦ 自主能力拓展提案系统
│   ├── extensions/
│   │   ├── loader.py            #   能力扩展加载器（只加载已登记模块，异常隔离）
│   │   └── contrib/             #   提案批准后的扩展模块落盘位置
│   ├── orchestrator.py          # 总编排器（完整推理链路）
│   ├── demo.py                  # 一键演示
│   ├── cli.py                   # 命令行入口
│   ├── config.py                # 配置系统（YAML 覆盖 + 环境变量）
│   └── utils.py                 # 通用工具（零第三方依赖）
├── configs/
│   ├── eisa.yaml                # 主配置（含 vLLM/SGLang 接入示例）
│   └── paradigms.yaml           # 推理范式扩展/覆盖示例
├── examples/demo.py             # 演示脚本
├── tests/test_eisa.py           # 11 项端到端测试（pytest 或直接运行）
└── data/                        # 运行时数据（画像/日志/缺陷/补丁/提案/轨迹）
```

## 四、快速开始

### 1. 离线联调（零依赖，推荐首次运行）

```bash
pip install pyyaml httpx        # pyyaml 缺失时自动回退内置默认值，httpx 仅真后端需要
python examples/demo.py         # 一键演示：对话→长任务→短板分析→提案生成
# 或
python -m eisa.cli demo
```

MockBackend 是确定性离线后端（按提示词哈希种子合成结构化输出），
能让全部调度链路（多分支→评判→反思→规划→进化）在无任何模型的情况下端到端跑通。

### 2. 交互对话

```bash
python -m eisa.cli chat --user alice
# REPL 内命令：
#   /task <目标>   长程任务
#   /profile       查看用户画像
#   /self          查看 EISA 自我画像
#   /plan          查看最近一次元推理轨迹
#   /exit
```

### 3. 对接 vLLM / SGLang（OpenAI 兼容服务）

两推理引擎均暴露 OpenAI 兼容接口，修改 `configs/eisa.yaml`：

```yaml
backend:
  name: openai_compat          # 或 multi_endpoint（多实例扇出）
  base_url: http://127.0.0.1:8000/v1    # vLLM: python -m vllm.entrypoints.openai.api_server --model <模型> --port 8000
  model: eisa-base-10t
  api_key: EMPTY

# 多端点并行扇出示例（框架层自动轮询分发批量请求）：
# backend:
#   name: multi_endpoint
#   endpoints:
#     - {name: vllm-0,   base_url: "http://127.0.0.1:8000/v1",   model: eisa-base-10t}
#     - {name: sglang-0, base_url: "http://127.0.0.1:30000/v1",  model: eisa-base-10t}
```

### 4. 补丁审核流（自迭代）

```bash
python -m eisa.cli iterate analyze    # 短板分析
python -m eisa.cli iterate propose    # 生成补丁提案（全部进入 pending）
python -m eisa.cli patch list
python -m eisa.cli patch show <id>
python -m eisa.cli patch approve <id> --note "同意调参"
python -m eisa.cli patch apply <id>   # 自动备份；支持 rollback
python -m eisa.cli patch rollback <id>
```

### 5. 能力提案流

```bash
python -m eisa.cli proposal list
python -m eisa.cli proposal show <id>
python -m eisa.cli proposal approve <id>   # 代码物化至 eisa/extensions/contrib/ 并注册
python -m eisa.cli proposal reject <id>
```

### 6. 领域定向放大与专项评测

```bash
python -m eisa.cli domain status
python -m eisa.cli domain pack --name 数学与算法       # 生成/加载领域包
python -m eisa.cli domain eval --name 数学与算法 --n 5 # 生成难题集→跑分→缺陷回流
```

## 五、核心机制说明

### 5.1 元推理调度器（性能放大的大脑）

回答「这个问题该用什么方式思考」：

1. **问题分析**：难度四档（简单/中等/困难/极难）、类型七类、歧义度、是否需要长程规划；
2. **策略四档**：
   | 难度 | 策略 | 分支基线 | 评判 | 反思 | 辩论 |
   |---|---|---|---|---|---|
   | 简单 | direct | 1 | L1 | 0层 | 0 |
   | 中等 | dual_verify | 2 | L1-L4 | 1层 | 0 |
   | 困难 | multi_branch | 4 | L1-L4+修复 | 2层 | 1 |
   | 极难 | extreme | 8（末位分支魔鬼代言人） | 全链路 | 3层 | 2 |
3. **预算动态分配**：难度基线 × 领域加成 × `unlimited_mode`（整体加倍，框架级相对量，不受现实算力约束）；
4. **自我档案守卫**：读取 EISA 自我画像，若历史存在「逻辑矛盾」类缺陷，自动提高交叉校验轮次；
5. 每次决策产出可审计的**元推理轨迹**（`/plan` 查看）。

### 5.2 多分支并行 + 多层自省择优（放大核心）

- **分支差异化**：人格（8 种内置 + 领域专家）× 范式（12+ 种）× 温度阶梯，确保思路真正分歧；
- **四层评判**：L1 六维独立评分（正确性/完整性/一致性/深度/可行性/清晰度）→
  L2 交叉互评扣分 → L3 全分支矛盾排查（定位两两冲突）→ L4 加权终审；
- **回溯纠错**：胜者低于阈值时重生成最弱分支（注入评审意见）再评，循环至预算上限；
- **终局辩论**：top2 分差小于 `debate_margin` 时触发多轮对抗后终裁；
- **失败回流**：矛盾/低置信度/失败分支样例自动写入缺陷库，供自迭代引擎复盘。

### 5.3 长程任务与递归反思

- **TaskPlanner**：目标 → DAG 子任务拆解 → 任务栈调度（依赖就绪即执行）→
  里程碑复盘 → 失败自动重规划补充补救子任务 → 全量合成终稿；
- **RecursiveReflector**：事实层 → 逻辑层 → 假设层 → 边界层 → 目标层逐层扫描，
  发现漏洞即修复并带入下一层，深度由元调度器预算控制。

### 5.4 领域定向放大

用户在某领域熟练度 ≥ 3（可配）时自动构建**领域包**：
专属思考链（固化领域方法论步骤）+ 专家人格子路由（优先占用分支）+ 分支/预算加成 +
`critical_check` 范式强制注入。领域包持久化于 `data/domains/`，可被评测与补丁持续优化。

### 5.5 自迭代与安全闸门（硬约束）

```
analyze: 对话失败样例 + 缺陷库 + 评测结果 → 短板报告
propose: 每类短板 → 补丁提案（kind/target/anchor/replacement/风险/收益/回滚方案）→ pending
人工审核: approve / reject（CLI 或人工编辑 JSON 均可）
apply:   仅 approved 可应用；路径越界拒绝；锚点不存在/不唯一拒绝；
         先备份原文件 → 单点替换 → 记录迁移 → 写入自我档案迭代历史
rollback: 一键从备份恢复
```

- 提案系统生成的扩展模块代码同样先落盘 pending，**approve 后**才物化为
  `eisa/extensions/contrib/*.py` 并登记 `registry.json`；
- 加载器只执行登记过的模块，且所有钩子异常隔离 —— 未审核代码永不运行。

## 六、配置要点

| 配置项 | 说明 | 默认 |
|---|---|---|
| `backend.name` | mock / openai_compat / multi_endpoint | mock |
| `base_model.params_total` | 基座参数量级设定（仅元数据） | 10T |
| `reasoning.unlimited_mode` | 无限思考模式（预算整体加倍） | true |
| `judge.score_threshold` | 终审通过阈值（示例补丁会调它） | 7.0 |
| `domain.strong_level_threshold` | 触发领域放大的熟练度门槛 | 3 |
| `EISA_DATA_DIR` 环境变量 | 数据目录覆盖（测试沙箱用） | `<项目>/data` |

## 七、测试

```bash
python tests/test_eisa.py     # 11 项：记忆/管线/元调度/长任务/闸门/扩展
# 或 pytest tests/
```

覆盖关键安全约束：**未审核补丁 apply 必被拒绝**、approve→apply→内容变更→rollback 全链路、
扩展未登记不加载等。

## 八、边界与免责

- 本仓库是**架构探索框架**：所有推理能力来自所接入的基座模型；框架在调度层放大（分支、对抗、反思、规划），
  不改变基座内部任何东西；
- MockBackend 的输出为确定性占位文本，仅用于跑通链路与测试，不代表模型行为；
- 补丁系统可修改的文件被严格限制在项目根目录内，且必须经人工审核。
