# -*- coding: utf-8 -*-
"""EISA 命令行入口。

子命令：
  chat          交互对话（REPL）
  task          长程任务
  self-profile  查看/重置 EISA 自我画像
  patch         补丁审核流：list/show/approve/reject/apply/rollback
  proposal      能力提案流：list/show/approve/reject
  domain        领域状态/领域包/专项评测
  iterate       短板分析 + 提案生成
  backend-check 推理后端健康检查
  demo          一键演示
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from eisa.orchestrator import EisaOrchestrator  # noqa: E402
from eisa.utils import get_logger  # noqa: E402

logger = get_logger("cli")


def _print_json(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))


# ===========================================================================
# chat REPL
# ===========================================================================

async def _chat(args) -> None:
    orch = EisaOrchestrator(args.config)
    user = args.user
    print(f"EISA 交互模式（backend={orch.backend.name}，数据目录={orch.paths['root']}）")
    print("命令: /task <目标> | /profile | /self | /defects | /exit")
    last_result = None
    while True:
        try:
            text = input("\n你> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见。")
            return
        if not text:
            continue
        if text in ("/exit", "/quit"):
            print("再见。")
            return
        if text == "/profile":
            p = orch.user_profiles.load(user)
            _print_json({
                "expertise": p.expertise, "knowledge_gaps": p.knowledge_gaps,
                "questioning_habits": p.questioning_habits,
                "style_preferences": p.style_preferences,
                "long_term_goals": p.long_term_goals,
                "project_context": p.project_context,
                "interaction_stats": p.interaction_stats,
            })
            continue
        if text == "/self":
            print(orch.self_profile.render_for_prompt())
            continue
        if text == "/defects":
            print(orch.defects.to_prompt_summary())
            continue
        if text.startswith("/task "):
            goal = text[len("/task "):].strip()
            tr = await orch.run_long_task(user, goal)
            print(tr.tree_text())
            print("\n终稿:", tr.final_answer)
            continue
        result = await orch.handle_message(user, text)
        print("\n" + result.brief())
        if result.plan and result.plan.paradigms:
            print(f"◇ 范式组合: {', '.join(result.plan.paradigms[:6])}")
        print("\nEISA> " + result.answer)


# ===========================================================================
# patch 审核流
# ===========================================================================

def _patch(args) -> None:
    orch = EisaOrchestrator(args.config)
    eng = orch.iterate
    if args.action == "list":
        rows = eng.list_patches()
        if not rows:
            print("（暂无补丁）")
            return
        for r in rows:
            print(f"[{r['status']:>11}] {r['patch_id']}  {r['kind']:<16} -> {r['target_file']}")
    elif args.action == "show":
        if not args.patch_id:
            print("需要 --id <patch_id>")
            return
        p = eng.load_patch(args.patch_id)
        _print_json(p.__dict__ if p else {"error": "补丁不存在"})
    elif args.action == "approve":
        out = eng.approve_patch(args.patch_id, note=args.note or "")
        print(out["message"])
    elif args.action == "reject":
        out = eng.reject_patch(args.patch_id, note=args.note or "")
        print(out["message"])
    elif args.action == "apply":
        out = eng.apply_patch(args.patch_id)
        print(out["message"])
    elif args.action == "rollback":
        out = eng.rollback_patch(args.patch_id)
        print(out["message"])


# ===========================================================================
# proposal 审核流
# ===========================================================================

def _proposal(args) -> None:
    orch = EisaOrchestrator(args.config)
    sysm = orch.proposals
    if args.action == "list":
        rows = sysm.list_proposals()
        if not rows:
            print("（暂无提案）")
            return
        for r in rows:
            print(f"[{r['status']:>8}] {r['proposal_id']}  {r['name']}  (模块: {r['module_name']})")
    elif args.action == "show":
        if not args.proposal_id:
            print("需要 --id <proposal_id>")
            return
        p = sysm.load_proposal(args.proposal_id)
        if p is None:
            print("提案不存在")
            return
        out = p.__dict__.copy()
        out["code"] = out["code"][:600] + ("...(截断)" if len(p.code) > 600 else "")
        _print_json(out)
    elif args.action == "approve":
        out = sysm.approve_proposal(args.proposal_id, note=args.note or "")
        print(out["message"])
    elif args.action == "reject":
        out = sysm.reject_proposal(args.proposal_id, note=args.note or "")
        print(out["message"])


# ===========================================================================
# domain / iterate / self-profile / backend
# ===========================================================================

def _domain(args) -> None:
    orch = EisaOrchestrator(args.config)
    if args.action == "status":
        packs = orch.domain_amplifier.packs_summary()
        if not packs:
            print("（暂无领域包；与用户深入对话后自动生成）")
            return
        _print_json(packs)
        return
    if args.action == "pack":
        name = args.name or "通用领域"
        pack = asyncio.run(orch.domain_amplifier.ensure_pack(name))
        _print_json({
            "domain_id": pack.domain_id, "name": pack.name,
            "keywords": pack.keywords, "chain_steps": pack.chain_steps,
            "expert_personas": pack.expert_personas, "branch_bonus": pack.branch_bonus,
        })
        return
    if args.action == "eval":
        name = args.name or "通用领域"
        pack = asyncio.run(orch.domain_amplifier.ensure_pack(name))
        n = args.n or orch.cfg.get("domain.eval_problems_per_domain", 10)
        problems = asyncio.run(orch.eval_builder.collect_hard_problems(name, pack, n=n))

        async def _run():
            return await orch.eval_builder.run_eval(name, pack, orch.answer_only)

        summary = asyncio.run(_run())
        _print_json({"problems": len(problems), **summary})
        return


def _iterate(args) -> None:
    orch = EisaOrchestrator(args.config)
    if args.action == "analyze":
        report = orch.iterate.analyze()
        _print_json({
            "report_id": report.report_id, "summary": report.summary,
            "top_weaknesses": report.top_weaknesses, "source_stats": report.source_stats,
        })
    elif args.action == "propose":
        out = asyncio.run(orch.analyze_and_propose())
        print("已生成待审核补丁与提案（绝不自动应用）：")
        _print_json(out)


def _self_profile(args) -> None:
    orch = EisaOrchestrator(args.config)
    if args.action == "show":
        print(orch.self_profile.render_for_prompt(max_items=8))
        _print_json(orch.self_profile.load().__dict__)
    elif args.action == "bump":
        v = orch.self_profile.bump_strategy_version(note=args.note or "")
        print("策略版本已升级:", v)


def _backend_check(args) -> None:
    orch = EisaOrchestrator(args.config)
    import asyncio
    ok = asyncio.run(orch.backend.health())
    print(f"后端[{orch.backend.name}] 健康状态: {'正常' if ok else '异常'}")
    print(f"基座元信息: {orch.base_model.meta.name} | 设定参数量级: {orch.base_model.meta.params_total:,}")


def main() -> None:
    ap = argparse.ArgumentParser(prog="eisa", description="EISA AGI 结构探索框架")
    ap.add_argument("--config", default=None, help="配置文件路径（默认自动加载 configs/eisa.yaml）")
    sub = ap.add_subparsers(dest="cmd")

    p_chat = sub.add_parser("chat", help="交互对话")
    p_chat.add_argument("--user", default="default_user")
    p_chat.set_defaults(func=_chat)

    p_task = sub.add_parser("task", help="长程任务")
    p_task.add_argument("--user", default="default_user")
    p_task.add_argument("--goal", required=True)
    p_task.set_defaults(func=lambda a: print(
        asyncio.run(EisaOrchestrator(a.config).run_long_task(a.user, a.goal)).tree_text()))

    p_patch = sub.add_parser("patch", help="补丁审核流（人工闸门）")
    p_patch.add_argument("action", choices=["list", "show", "approve", "reject", "apply", "rollback"])
    p_patch.add_argument("--id", dest="patch_id", default=None)
    p_patch.add_argument("--note", default="")
    p_patch.set_defaults(func=_patch)

    p_prop = sub.add_parser("proposal", help="能力拓展提案流（人工闸门）")
    p_prop.add_argument("action", choices=["list", "show", "approve", "reject"])
    p_prop.add_argument("--id", dest="proposal_id", default=None)
    p_prop.add_argument("--note", default="")
    p_prop.set_defaults(func=_proposal)

    p_dom = sub.add_parser("domain", help="领域状态/领域包/专项评测")
    p_dom.add_argument("action", choices=["status", "pack", "eval"])
    p_dom.add_argument("--name", default=None)
    p_dom.add_argument("--n", type=int, default=None)
    p_dom.set_defaults(func=_domain)

    p_it = sub.add_parser("iterate", help="短板分析 + 提案生成")
    p_it.add_argument("action", choices=["analyze", "propose"])
    p_it.set_defaults(func=_iterate)

    p_self = sub.add_parser("self-profile", help="EISA 自我画像")
    p_self.add_argument("action", choices=["show", "bump"], nargs="?", default="show")
    p_self.add_argument("--note", default="")
    p_self.set_defaults(func=_self_profile)

    p_bc = sub.add_parser("backend-check", help="后端健康检查")
    p_bc.set_defaults(func=_backend_check)

    p_demo = sub.add_parser("demo", help="一键演示全链路")
    p_demo.set_defaults(func=lambda a: asyncio.run(
        __import__("eisa.demo", fromlist=["run_demo"]).run_demo()))

    args = ap.parse_args()
    if not hasattr(args, "func"):
        ap.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
