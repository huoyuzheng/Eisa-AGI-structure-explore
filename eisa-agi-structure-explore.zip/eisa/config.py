# -*- coding: utf-8 -*-
"""EISA 全局配置：默认值、YAML 合并、环境变量覆盖、数据目录解析。

配置解析优先级（高 -> 低）：
1. 环境变量 EISA_DATA_DIR（数据目录覆盖，便于测试沙箱）
2. YAML 配置文件（默认自动加载 configs/eisa.yaml，可用 --config 指定）
3. 本文件的 DEFAULT_CONFIG 内置默认值
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Optional

from eisa.utils import deep_merge, get_logger

logger = get_logger("config")

# 项目根目录 = eisa 包的上一级
PROJECT_ROOT = Path(__file__).resolve().parent.parent

DEFAULT_CONFIG: Dict[str, Any] = {
    "project": {"name": "eisa-agi-structure-explore", "version": "0.1.0"},

    # ---- 底层超大基座元信息（仅元数据；框架绝不加载/修改/存储权重）----
    "base_model": {
        "name": "EISA-Base-Hypothetical",
        "params_total": 10_000_000_000_000,  # 10T 参数规模（仅作调度层元信息，不对应任何真实权重）
        "context_window": 10_000_000,
        "note": "只读抽象：框架仅调用推理接口，不触及基座内部张量权重",
    },

    # ---- 推理后端（mock 离线联调 / openai_compat 对接 vLLM、SGLang / multi_endpoint 多实例扇出）----
    "backend": {
        "name": "mock",
        "base_url": "http://127.0.0.1:8000/v1",
        "model": "eisa-base-10t",
        "api_key": "EMPTY",
        "timeout": 600,
        "endpoints": [
            # 多端点扇出示例（取消注释并按实际服务修改）：
            # {"name": "vllm-0",   "base_url": "http://127.0.0.1:8000/v1",  "model": "eisa-base-10t", "api_key": "EMPTY"},
            # {"name": "sglang-0", "base_url": "http://127.0.0.1:30000/v1", "model": "eisa-base-10t", "api_key": "EMPTY"}
        ],
    },

    # ---- 记忆层 ----
    "memory": {
        "max_dialog_context": 5,          # 装载进上下文的最近对话轮数
        "profile_update_enabled": True,   # 每次对话后自动更新用户画像
    },

    # ---- 推理层 ----
    "reasoning": {
        "unlimited_mode": True,                       # 不受现实算力约束：预算全面放大
        "default_concurrency": 8,                     # 分支并行协程并发度
        "branch_temperatures": [0.3, 0.5, 0.7, 0.85, 1.0],
        "amplify_branch_bonus": 2,                    # 领域放大时额外增加的分支数
    },

    # ---- 评判层 ----
    "judge": {
        "weights": {
            "correctness": 0.30, "completeness": 0.20, "consistency": 0.15,
            "depth": 0.15, "feasibility": 0.10, "clarity": 0.10,
        },
        "score_threshold": 7.0,   # 终审通过阈值（低于则触发回溯修复）
        "debate_margin": 0.8,     # 前二名分差小于该值时启用辩论机制
        "repair_max_rounds": 2,   # 回溯修复最大轮次
    },

    # ---- 长程规划 ----
    "planner": {
        "max_subtasks": 8,
        "milestone_review": True,   # 每个子目标完成后做阶段性复盘
        "replan_on_fail": True,     # 失败自动重规划
        "max_replans": 2,
    },

    # ---- 递归反思 ----
    "reflector": {"max_depth": 3},

    # ---- 领域放大 ----
    "domain": {
        "strong_level_threshold": 3,       # 用户领域熟练度达到该级即启动定向放大
        "eval_problems_per_domain": 10,    # 每个领域专项评测集默认题量
    },

    # ---- 自迭代 / 提案 ----
    "evolution": {
        "max_patches_per_run": 3,
        "max_proposals_per_run": 2,
        # 安全闸门说明：补丁必须经人工 approve 后才能 apply，该规则不提供任何配置旁路
    },

    "extensions": {"enabled": True},
}


class Config:
    """轻量配置读取器：支持 'backend.name' 形式的点路径访问。"""

    def __init__(self, raw: Dict[str, Any]):
        self._raw = raw

    def get(self, dotted: str, default: Any = None) -> Any:
        cur: Any = self._raw
        for part in dotted.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return default
        return cur

    @property
    def raw(self) -> Dict[str, Any]:
        return self._raw


def load_config(path: Optional[str] = None) -> Config:
    """加载配置：内置默认 -> YAML 合并 -> 环境变量覆盖。"""
    raw = deep_merge({}, DEFAULT_CONFIG)

    candidates = []
    if path:
        candidates.append(Path(path))
    else:
        default_yaml = PROJECT_ROOT / "configs" / "eisa.yaml"
        if default_yaml.exists():
            candidates.append(default_yaml)

    for cand in candidates:
        if cand.exists():
            try:
                import yaml  # 可选依赖：缺失时跳过 YAML 加载
                with open(cand, "r", encoding="utf-8") as f:
                    user_cfg = yaml.safe_load(f) or {}
                if isinstance(user_cfg, dict):
                    raw = deep_merge(raw, user_cfg)
                    logger.info("已加载配置文件: %s", cand)
            except ImportError:
                logger.warning("未安装 pyyaml，跳过配置文件 %s，使用内置默认配置", cand)
            except Exception as e:
                logger.warning("配置文件 %s 解析失败(%s)，使用内置默认配置", cand, e)

    # 数据目录：环境变量 > 配置 > 项目根/data
    data_dir = os.environ.get("EISA_DATA_DIR") or raw.get("data_dir") or str(PROJECT_ROOT / "data")
    raw["data_dir"] = data_dir
    return Config(raw)


def data_paths(cfg: Config) -> Dict[str, Path]:
    """返回标准化的数据子目录布局（运行时按需 ensure_dir）。"""
    root = Path(cfg.get("data_dir", "./data"))
    return {
        "root": root,
        "users": root / "users",
        "self_profile": root / "self_profile.json",
        "dialogs": root / "dialogs",
        "defects": root / "defects" / "defect_library.json",
        "domains": root / "domains",
        "evals": root / "evals",
        "patches": root / "patches",
        "proposals": root / "proposals",
        "reports": root / "reports",
        "runs": root / "runs",
    }
