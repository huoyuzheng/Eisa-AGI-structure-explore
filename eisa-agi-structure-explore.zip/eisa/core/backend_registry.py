# -*- coding: utf-8 -*-
"""推理后端注册与工厂：按配置构造具体后端实例。"""
from __future__ import annotations

from typing import Optional

from eisa.config import Config
from eisa.core.base_model import (
    BaseBackend,
    MockBackend,
    MultiEndpointBackend,
    OpenAICompatBackend,
)
from eisa.utils import get_logger

logger = get_logger("registry")


def build_backend(cfg: Config) -> BaseBackend:
    """根据配置构造推理后端。

    支持：
    - mock           离线确定性后端（默认，零依赖）
    - openai_compat  单端点 OpenAI 兼容服务（vLLM / SGLang）
    - multi_endpoint 多端点并行扇出
    """
    name = cfg.get("backend.name", "mock")

    if name == "mock":
        logger.info("使用 MockBackend（离线联调模式，不调用真实模型）")
        return MockBackend()

    if name == "openai_compat":
        return OpenAICompatBackend(
            base_url=cfg.get("backend.base_url", "http://127.0.0.1:8000/v1"),
            model=cfg.get("backend.model", "eisa-base-10t"),
            api_key=cfg.get("backend.api_key", "EMPTY"),
            timeout=cfg.get("backend.timeout", 600),
        )

    if name == "multi_endpoint":
        eps_cfg = cfg.get("backend.endpoints") or []
        if not eps_cfg:
            raise ValueError("multi_endpoint 后端需要在配置 backend.endpoints 中列出至少一个端点")
        eps = []
        for e in eps_cfg:
            eps.append(OpenAICompatBackend(
                base_url=e["base_url"],
                model=e.get("model", cfg.get("backend.model", "eisa-base-10t")),
                api_key=e.get("api_key", "EMPTY"),
                timeout=cfg.get("backend.timeout", 600),
                name=e.get("name"),
            ))
        return MultiEndpointBackend(eps)

    raise ValueError(
        f"未知后端类型: {name}（可选 mock / openai_compat / multi_endpoint；"
        "openai_compat 可对接 vLLM 或 SGLang 的 OpenAI 兼容服务）")
