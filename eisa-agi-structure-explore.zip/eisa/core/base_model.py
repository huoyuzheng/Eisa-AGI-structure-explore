# -*- coding: utf-8 -*-
"""底层超大基座统一抽象层。

设计原则（对应项目核心规则）：
1. 基座是被调度的黑盒超大模型（可设定至 10T 参数量级），框架只通过统一推理接口调用；
2. 框架绝不读取/修改/保存基座内部张量权重 —— 本模块刻意不提供任何权重级 API；
3. 推理后端可插拔替换：
   - MockBackend          离线确定性后端，零依赖跑通全框架（联调/测试用）
   - OpenAICompatBackend  对接 vLLM / SGLang 等 OpenAI 兼容推理服务
   - MultiEndpointBackend 多端点并行扇出（多实例横向扩展，不受现实算力约束的调度抽象）
"""
from __future__ import annotations

import asyncio
import json
import random
import re
from typing import Any, Dict, List, Optional

from eisa.core.types import BaseModelMeta, GenerationResult, Message
from eisa.utils import get_logger, hash_seed, top_terms, find_eisa_paths

logger = get_logger("base")


# ===========================================================================
# 后端抽象基类
# ===========================================================================

class BaseBackend:
    """推理后端抽象基类：上层框架只依赖本接口。"""

    name: str = "base"
    is_mock: bool = False

    async def chat(self, messages: List[Message], temperature: float = 0.7,
                   max_tokens: int = 8192, stop: Optional[List[str]] = None,
                   extra: Optional[Dict[str, Any]] = None) -> str:
        """单次对话推理，返回模型文本输出。"""
        raise NotImplementedError

    async def chat_many(self, conversations: List[List[Message]],
                        temperature: float = 0.7, max_tokens: int = 8192,
                        concurrency: int = 8, stop: Optional[List[str]] = None,
                        extra: Optional[Dict[str, Any]] = None) -> List[str]:
        """批量并行推理（默认实现：单接口 + 信号量并发控制）。"""
        sem = asyncio.Semaphore(max(1, concurrency))

        async def _one(conv: List[Message]) -> str:
            async with sem:
                return await self.chat(conv, temperature=temperature,
                                       max_tokens=max_tokens, stop=stop, extra=extra)

        return await asyncio.gather(*[_one(c) for c in conversations])

    async def health(self) -> bool:
        """后端健康检查。"""
        return True


# ===========================================================================
# Mock 后端：离线确定性联调
# ===========================================================================

_BOOL_KEYS = {
    "pass", "approved", "needs_repair", "requires_planning", "success",
    "has_contradiction", "replan", "enabled", "ok",
}
_LIST_KEYS = {
    "entities", "issues", "contradictions", "subtasks", "problems", "patches",
    "proposals", "domains", "expert_personas", "criteria", "dimensions",
    "risks", "tags", "insights", "gaps", "claims", "steps", "strengths",
    "weaknesses", "goals", "project_context", "updates", "new_weaknesses",
    "expertise_updates", "top_weaknesses", "chain_steps", "keywords",
    "suggestions", "highlights", "branches", "remedies",
}


class MockBackend(BaseBackend):
    """离线确定性后端：无需任何真实模型即可端到端跑通全框架。

    工作方式：
    - 识别提示词中的【输出要求】JSON 字段声明，按字段语义合成结构化 JSON；
    - 其余情况合成带【结论】/【置信度】标记的推理文本；
    - 所有伪随机由提示词哈希种子驱动，同一输入输出可复现，便于测试回归。
    """

    name = "mock"
    is_mock = True

    async def chat(self, messages: List[Message], temperature: float = 0.7,
                   max_tokens: int = 8192, stop: Optional[List[str]] = None,
                   extra: Optional[Dict[str, Any]] = None) -> str:
        prompt = "\n".join(m.to_prompt() for m in messages)
        rnd = random.Random(hash_seed(prompt) ^ int(temperature * 100))
        if re.search(r"仅输出JSON|输出JSON|JSON格式", prompt):
            keys = self._json_fields(prompt)
            obj = {k: self._synth_value(k, prompt, rnd) for k in keys}
            return json.dumps(obj, ensure_ascii=False, indent=2)
        await asyncio.sleep(0)  # 让出事件循环，保持异步语义一致
        return self._reasoning_text(prompt, rnd)

    # ------------------------------------------------------------------
    @staticmethod
    def _json_fields(prompt: str) -> List[str]:
        """提取提示词最后一处『字段: a, b, c』声明。"""
        ms = re.findall(r"字段[:：]\s*([^\n]+)", prompt)
        if not ms:
            return ["result"]
        raw = ms[-1]
        parts = re.split(r"[，,、;；\s]+", raw)
        keys = [p.strip(" :：。") for p in parts if p.strip(" :：。")]
        return keys or ["result"]

    def _synth_value(self, key: str, prompt: str, rnd: random.Random) -> Any:
        kl = key.lower()
        terms = top_terms(prompt, 4)
        focus = terms[0] if terms else "目标问题"

        # --- 枚举类精确键 ---
        if kl == "difficulty":
            return rnd.choice(["简单", "中等", "困难", "极难"])
        if kl in ("query_type", "type", "category", "domain_hint"):
            return rnd.choice(["事实问答", "数学推理", "代码工程", "分析推演",
                               "创意生成", "任务规划", "研究调查"])
        if kl in ("branch_id", "winner_branch_id"):
            return f"b{rnd.randint(1, 12)}"
        if kl == "primary_domain":
            cands = re.search(r"候选领域[:：]\s*([^\n]+)", prompt)
            if cands:
                items = [x.strip() for x in re.split(r"[，,、/]", cands.group(1)) if x.strip()]
                if items:
                    return rnd.choice(items[:5])
            return focus
        if kl == "level":
            return rnd.randint(1, 5)
        if kl == "style_preferences":
            return {"verbosity": rnd.choice(["简洁", "适中", "详细"]),
                    "tone": rnd.choice(["专业", "友好", "直接"]),
                    "format": rnd.choice(["要点列表", "连贯段落", "结构化文档"])}

        # --- 列表类 ---
        if key in _LIST_KEYS:
            return self._synth_list(key, prompt, rnd)

        # --- 布尔类 ---
        if kl == "pass":
            # 里程碑判卷：75% 通过（模拟正常执行成功率，其余由重规划机制兜底）
            return rnd.choice([True, True, True, False])
        if kl in _BOOL_KEYS:
            return rnd.choice([True, True, False])

        # --- 数值类 ---
        if re.search(r"(score|total|confidence|rating|weight|penalty|ambiguity)", kl):
            if kl == "ambiguity":
                return round(rnd.uniform(0.0, 0.6), 2)
            if kl == "penalty":
                return round(rnd.uniform(0.0, 1.2), 1)
            return round(rnd.uniform(5.5, 9.7), 1)

        # --- 路径类 ---
        if kl in ("target_file", "target_module"):
            paths = find_eisa_paths(prompt)
            return paths[0] if paths else "configs/eisa.yaml"

        # --- 长文本类 ---
        if kl == "statement":
            return f"请深入分析「{focus}」场景下的高难度变体问题（#{rnd.randint(1, 999)}），要求给出严格可验证的完整推导。"
        if kl in ("rationale", "comments", "notes", "description", "design",
                  "motivation", "summary", "integration_plan", "rollback_plan",
                  "expected_gain", "risk_assessment", "grading_hint",
                  "change_summary", "evidence", "goal", "hints", "verdict",
                  "failure_reason", "design_notes"):
            return f"围绕「{focus}」的分析说明（种子{rnd.randint(100, 999)}）：按框架规范推进并留存可追溯依据。"
        if kl.endswith("id"):
            return f"gen_{rnd.randint(1000, 9999)}"

        return f"占位值-{rnd.randint(1000, 9999)}"

    def _synth_list(self, key: str, prompt: str, rnd: random.Random) -> List[Any]:
        terms = top_terms(prompt, 3) or ["目标主题"]
        t = terms[0]
        if key == "subtasks":
            out = []
            for i in range(rnd.randint(3, 5)):
                out.append({
                    "id": f"t{i + 1}",
                    "goal": f"子目标{i + 1}：围绕「{t}」完成阶段{i + 1}的分析、推演与验证",
                    "depends_on": [f"t{i}"] if i > 0 else [],
                    "hints": f"重点关注「{terms[i % len(terms)]}」相关约束",
                })
            return out
        if key == "issues":
            return [{
                "layer": rnd.choice(["事实层", "逻辑层", "假设层", "边界层", "目标层"]),
                "description": f"在{rnd.choice(['推导步骤', '关键假设', '边界条件', '结论表述'])}中存在可改进点{rnd.randint(1, 99)}",
                "severity": rnd.choice(["低", "中", "高"]),
            } for _ in range(rnd.randint(0, 2))]
        if key == "contradictions":
            return [{
                "between": [f"b{rnd.randint(1, 8)}", f"b{rnd.randint(1, 8)}"],
                "description": f"分支间对「{t}」的关键判断不一致",
                "severity": rnd.choice(["低", "低", "中"]),
            } for _ in range(rnd.randint(0, 2))]
        if key == "problems":
            return [{
                "problem_id": f"p{i + 1}",
                "domain": t,
                "difficulty": rnd.randint(3, 5),
                "statement": f"「{t}」领域高难度问题变体{i + 1}：请给出严格、可验证的完整解答。",
                "grading_hint": "检查推导完整性与结论正确性",
            } for i in range(5)]
        if key == "patches":
            return [{
                "kind": rnd.choice(["prompt_template", "strategy_param", "code"]),
                "target_file": (find_eisa_paths(prompt) or ["configs/eisa.yaml"])[0],
                "anchor": "",
                "replacement": "",
                "description": f"针对「{t}」类短板的策略调优补丁",
                "motivation": "基于失败样例与缺陷库分析",
                "risk_notes": "改动范围小、可回滚",
            }]
        if key == "proposals":
            return [{
                "name": f"{t}能力扩展模块",
                "module_name": f"{t}_extender",
                "motivation": f"当前框架在「{t}」方向缺少专项增强",
                "design": "以扩展钩子形式接入 pre/post_reasoning，不侵入主链路",
                "code": "",
                "integration_plan": "审核通过后写入 eisa/extensions/contrib 并注册",
                "risk_notes": "扩展隔离运行，异常自动降级",
            }]
        if key == "domains":
            pool = terms[:3] if terms else ["通用领域"]
            return [{"domain": x, "level": rnd.randint(2, 5),
                     "evidence": f"近期对话多次出现「{x}」相关主题"} for x in pool]
        if key == "expert_personas":
            return [{"id": f"exp_{i + 1}", "name": f"{t}专家{i + 1}",
                     "style": "以该领域最佳实践为准，先列关键假设再推演"} for i in range(2)]
        if key == "expertise_updates":
            pool = terms[:2] if terms else ["通用领域"]
            return [{"domain": x, "level": rnd.randint(1, 4)} for x in pool]
        if key == "top_weaknesses":
            return [{"category": c, "count": rnd.randint(2, 9),
                     "sample": f"典型案例：{c}相关失败样例"}
                    for c in rnd.sample(["推理漏洞", "逻辑矛盾", "事实错误",
                                         "规划失败", "低置信度结果"], k=3)]
        return [f"{key}条目{i + 1}：与「{t}」相关" for i in range(rnd.randint(1, 3))]

    def _reasoning_text(self, prompt: str, rnd: random.Random) -> str:
        q = self._extract_question(prompt)
        # 限制捕获长度，防止提示词中同一标记出现多次时吞入后续文本
        pm = re.search(r"【推理范式】([^：\n｜]{1,24})", prompt)
        paradigm = pm.group(1).strip() if pm else "通用推理链"
        pm2 = re.search(r"【人格】([^：\n｜]{1,24})", prompt)
        persona = pm2.group(1).strip() if pm2 else "通用人格"
        terms = top_terms(q, 4)
        focus = "、".join(terms[:3]) if terms else "核心问题"
        conf = round(rnd.uniform(0.55, 0.93), 2)
        steps = []
        for i in range(rnd.randint(3, 5)):
            steps.append(f"{i + 1}. 从{rnd.choice(['约束条件', '关键定义', '已知事实', '目标反推', '相似案例'])}切入，"
                         f"推演要点{i + 1}（聚焦{focus}）。")
        risk = rnd.choice(["需注意边界条件", "需复核关键假设", "需交叉验证数值", "需警惕隐含前提"])
        return (f"【人格】{persona}｜【推理范式】{paradigm}\n"
                f"【思路】先厘清问题结构，再按所选范式逐层推进。\n" + "\n".join(steps) + "\n"
                f"【中间检验】自检通过；{risk}。\n"
                f"【结论】针对「{focus}」的框架级占位结论：按上述路径推进可在给定约束下得到自洽解答。\n"
                f"【置信度】{conf}")

    @staticmethod
    def _extract_question(prompt: str) -> str:
        ms = re.findall(r"问题[:：]\s*([^\n]+)", prompt)
        if ms:
            return ms[-1].strip()
        lines = [l for l in prompt.splitlines() if l.strip()]
        return (lines[-1].strip()[:200] if lines else "未识别的问题")


# ===========================================================================
# OpenAI 兼容后端：对接 vLLM / SGLang
# ===========================================================================

class OpenAICompatBackend(BaseBackend):
    """OpenAI 兼容 HTTP 后端：可直接对接 vLLM / SGLang 等推理服务。

    vLLM 启动示例:   python -m vllm.entrypoints.openai.api_server --model <模型> --port 8000
    SGLang 启动示例:  python -m sglang.launch_server --model-path <模型> --port 30000
    两者均暴露 /v1/chat/completions OpenAI 兼容接口，本后端直接调用。
    """

    name = "openai_compat"
    is_mock = False

    def __init__(self, base_url: str, model: str, api_key: str = "EMPTY",
                 timeout: float = 600.0, name: Optional[str] = None):
        try:
            import httpx  # 延迟导入：仅在对接真后端时需要
        except ImportError as e:
            raise RuntimeError("使用 openai_compat 后端需要安装 httpx：pip install httpx") from e
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._client = httpx.AsyncClient(
            base_url=self.base_url, timeout=timeout,
            headers={"Authorization": f"Bearer {api_key}"})
        if name:
            self.name = name
        logger.info("OpenAI 兼容后端已连接: %s (model=%s)", self.base_url, model)

    async def chat(self, messages: List[Message], temperature: float = 0.7,
                   max_tokens: int = 8192, stop: Optional[List[str]] = None,
                   extra: Optional[Dict[str, Any]] = None) -> str:
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if stop:
            payload["stop"] = stop
        if extra:
            payload.update(extra)
        resp = await self._client.post("/chat/completions", json=payload)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    async def health(self) -> bool:
        try:
            resp = await self._client.get("/models")
            return resp.status_code == 200
        except Exception:
            return False

    async def aclose(self) -> None:
        await self._client.aclose()


# ===========================================================================
# 多端点扇出后端
# ===========================================================================

class MultiEndpointBackend(BaseBackend):
    """多端点并行扇出后端：将批量请求轮流分发到多个推理服务实例。

    面向『不受现实算力约束』的架构探索：框架层可以假设任意数量的基座实例，
    通过本后端把多分支推理的批量请求横向铺开。
    """

    name = "multi_endpoint"
    is_mock = False

    def __init__(self, endpoints: List[OpenAICompatBackend]):
        if not endpoints:
            raise ValueError("MultiEndpointBackend 需要至少一个端点")
        self._endpoints = list(endpoints)
        self._rr = 0

    def _next(self) -> OpenAICompatBackend:
        ep = self._endpoints[self._rr % len(self._endpoints)]
        self._rr += 1
        return ep

    async def chat(self, messages: List[Message], temperature: float = 0.7,
                   max_tokens: int = 8192, stop: Optional[List[str]] = None,
                   extra: Optional[Dict[str, Any]] = None) -> str:
        return await self._next().chat(messages, temperature=temperature,
                                       max_tokens=max_tokens, stop=stop, extra=extra)

    async def chat_many(self, conversations: List[List[Message]],
                        temperature: float = 0.7, max_tokens: int = 8192,
                        concurrency: int = 8, stop: Optional[List[str]] = None,
                        extra: Optional[Dict[str, Any]] = None) -> List[str]:
        n = len(self._endpoints)
        buckets: List[List[tuple]] = [[] for _ in range(n)]
        for i, conv in enumerate(conversations):
            buckets[i % n].append((i, conv))
        results: List[Optional[str]] = [None] * len(conversations)

        async def run_bucket(idx: int) -> None:
            ep = self._endpoints[idx]
            pairs = buckets[idx]
            if not pairs:
                return
            idxs = [i for i, _ in pairs]
            convs = [c for _, c in pairs]
            outs = await ep.chat_many(convs, temperature=temperature, max_tokens=max_tokens,
                                      concurrency=concurrency, stop=stop, extra=extra)
            for i, o in zip(idxs, outs):
                results[i] = o

        await asyncio.gather(*[run_bucket(k) for k in range(n)])
        return [r if r is not None else "" for r in results]

    async def health(self) -> bool:
        for ep in self._endpoints:
            if await ep.health():
                return True
        return False


# ===========================================================================
# 超大基座代理（框架与基座的唯一边界）
# ===========================================================================

class EisaBaseModel:
    """底层超大基座的调度代理 —— 外层框架访问基座的唯一入口。

    - 只暴露 infer / batch_infer 两个推理接口；
    - 携带基座元信息（参数规模可设定至 10T）；
    - 刻意不提供任何加载/导出/修改权重的方法，落实『框架不改动基座』的约束。
    """

    def __init__(self, backend: BaseBackend, meta: Optional[BaseModelMeta] = None):
        self.backend = backend
        self.meta = meta or BaseModelMeta(backend_name=backend.name)

    @property
    def backend_name(self) -> str:
        return self.backend.name

    @property
    def is_mock(self) -> bool:
        return self.backend.is_mock

    async def infer(self, messages: List[Message], temperature: float = 0.7,
                    max_tokens: int = 8192, stop: Optional[List[str]] = None,
                    extra: Optional[Dict[str, Any]] = None) -> GenerationResult:
        text = await self.backend.chat(messages, temperature=temperature,
                                       max_tokens=max_tokens, stop=stop, extra=extra)
        return GenerationResult(text=text, backend=self.backend.name,
                                meta={"model": self.meta.name,
                                      "params_total": self.meta.params_total})

    async def batch_infer(self, conversations: List[List[Message]],
                          temperature: float = 0.7, max_tokens: int = 8192,
                          concurrency: int = 8) -> List[GenerationResult]:
        texts = await self.backend.chat_many(conversations, temperature=temperature,
                                             max_tokens=max_tokens, concurrency=concurrency)
        return [GenerationResult(text=t, backend=self.backend.name,
                                 meta={"model": self.meta.name}) for t in texts]
