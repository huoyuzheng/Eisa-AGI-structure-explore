# -*- coding: utf-8 -*-
"""EISA 核心数据结构：消息、分支、评审、计划、任务、补丁、提案等全框架共享类型。

所有跨模块流转的数据结构集中在此定义，保证层与层之间解耦。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# 常量词表
# ---------------------------------------------------------------------------

DIFFICULTY_LEVELS = ["简单", "中等", "困难", "极难"]
QUERY_TYPES = ["事实问答", "数学推理", "代码工程", "分析推演", "创意生成", "任务规划", "研究调查"]
STRATEGIES = ["direct", "dual_verify", "multi_branch", "extreme"]

# 评判维度（英文键用于 JSON 序列化，中文标签用于展示）
JUDGE_DIMENSIONS = [
    ("correctness", "正确性"),
    ("completeness", "完整性"),
    ("consistency", "一致性"),
    ("depth", "深度"),
    ("feasibility", "可行性"),
    ("clarity", "清晰度"),
]

# 递归反思层（由浅入深）
REFLECTION_LAYERS = [
    ("fact", "事实层", "核对事实性断言、数据、引用是否可靠"),
    ("logic", "逻辑层", "检查推理链条是否存在逻辑跳跃、循环论证或自相矛盾"),
    ("assumption", "假设层", "挖掘未言明的隐含假设，评估其成立条件"),
    ("boundary", "边界层", "检查极端情况、边界条件与适用范围"),
    ("goal", "目标层", "检验答案是否对准用户的真实目标与语境"),
]


# ---------------------------------------------------------------------------
# 基础消息与生成结果
# ---------------------------------------------------------------------------

@dataclass
class Message:
    """统一消息结构（role: system / user / assistant）。"""
    role: str = "user"
    content: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_prompt(self) -> str:
        return f"{self.role}: {self.content}"


@dataclass
class GenerationResult:
    """一次基座推理调用的返回。"""
    text: str = ""
    backend: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BaseModelMeta:
    """底层超大基座的元信息（框架只读，不对应任何真实权重）。"""
    name: str = "EISA-Base-Hypothetical"
    params_total: float = 10_000_000_000_000  # 10T 参数（仅调度层元信息）
    context_window: int = 10_000_000
    backend_name: str = "mock"
    note: str = "只读抽象：框架不加载/修改/存储基座权重"


# ---------------------------------------------------------------------------
# 推理计划与分支
# ---------------------------------------------------------------------------

@dataclass
class Budget:
    """一次推理任务的思考预算（框架层调度概念，不受现实算力约束）。"""
    max_branches: int = 2
    tokens_per_branch: int = 8192
    judge_rounds: int = 1
    reflect_depth: int = 1
    debate_rounds: int = 0
    concurrency: int = 8
    unlimited: bool = False


@dataclass
class QueryAnalysis:
    """元推理调度器的第一步：问题分析产物。"""
    difficulty: str = "中等"
    query_type: str = "分析推演"
    entities: List[str] = field(default_factory=list)
    ambiguity: float = 0.2
    requires_planning: bool = False
    domain_hint: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ReasoningPlan:
    """元推理调度器的输出：本次推理该如何思考的完整计划。"""
    plan_id: str = ""
    strategy: str = "dual_verify"
    difficulty: str = "中等"
    query_type: str = "分析推演"
    paradigms: List[str] = field(default_factory=list)
    persona_hints: List[str] = field(default_factory=list)
    budget: Optional[Budget] = None
    requires_planning: bool = False
    reflect_depth: int = 1
    domain_chain: List[str] = field(default_factory=list)   # 领域专属思考链步骤
    domain_amplified: bool = False
    notes: str = ""
    created_at: str = ""


@dataclass
class ReasoningBranch:
    """多分支并行推理中的一条思考分支。"""
    branch_id: str = ""
    paradigm: str = ""            # 范式 id
    persona: str = ""             # 人格 id
    temperature: float = 0.7
    answer: str = ""              # 分支完整输出
    conclusion: str = ""          # 提取出的【结论】
    trace: List[Dict[str, Any]] = field(default_factory=list)
    self_score: Dict[str, float] = field(default_factory=dict)   # 独立评分
    indep: float = 0.0            # 独立评分加权汇总
    critiques: List[str] = field(default_factory=list)           # 交叉互评指出的问题
    cross_penalty: float = 0.0
    aggregate: float = 0.0        # 综合得分（惩罚后）
    repaired: bool = False
    status: str = "pending"       # pending / ok / failed / regenerated


# ---------------------------------------------------------------------------
# 评审与反思
# ---------------------------------------------------------------------------

@dataclass
class JudgeReport:
    """多层自省评判器的完整裁决报告。"""
    winner_branch_id: str = ""
    final_answer: str = ""
    scores: Dict[str, float] = field(default_factory=dict)          # branch_id -> 综合分
    dimensions: Dict[str, Dict[str, float]] = field(default_factory=dict)
    contradictions: List[Dict[str, Any]] = field(default_factory=list)
    verdict_rationale: str = ""
    confidence: float = 0.0
    repair_rounds: int = 0
    debate_used: bool = False
    debate_transcript: List[str] = field(default_factory=list)
    defects: List[Dict[str, Any]] = field(default_factory=list)     # 送入缺陷库的失败样例


@dataclass
class ReflectionReport:
    """递归反思链路的报告。"""
    layers_checked: List[str] = field(default_factory=list)
    issues_found: List[Dict[str, Any]] = field(default_factory=list)
    repairs: List[Dict[str, Any]] = field(default_factory=list)
    confidence: float = 0.0
    final_answer: str = ""


# ---------------------------------------------------------------------------
# 长程任务
# ---------------------------------------------------------------------------

@dataclass
class TaskNode:
    """任务栈中的一个子目标节点（支持 DAG 依赖）。"""
    task_id: str = ""
    goal: str = ""
    hints: str = ""
    depends_on: List[str] = field(default_factory=list)
    status: str = "pending"       # pending / running / done / failed
    result: str = ""
    review: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# 记忆与领域
# ---------------------------------------------------------------------------

@dataclass
class InteractionRecord:
    """一次完整交互的落盘记录（JSONL）。"""
    interaction_id: str = ""
    ts: str = ""
    user_id: str = ""
    query: str = ""
    answer: str = ""
    strategy: str = ""
    difficulty: str = ""
    query_type: str = ""
    winner_branch_id: str = ""
    score: float = 0.0
    confidence: float = 0.0
    defect_categories: List[str] = field(default_factory=list)
    success: bool = True
    failure_reason: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DefectRecord:
    """缺陷库条目。"""
    defect_id: str = ""
    category: str = ""
    description: str = ""
    trigger_context: str = ""
    severity: str = "中"
    frequency: int = 1
    first_seen: str = ""
    last_seen: str = ""
    status: str = "open"          # open / fixing / fixed
    related_ids: List[str] = field(default_factory=list)


@dataclass
class DomainPack:
    """领域定向放大包：专属思考链 + 专家人格 + 放大策略。"""
    domain_id: str = ""
    name: str = ""
    keywords: List[str] = field(default_factory=list)
    chain_steps: List[str] = field(default_factory=list)
    expert_personas: List[Dict[str, Any]] = field(default_factory=list)
    branch_bonus: int = 2
    eval_summary: Dict[str, Any] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""


@dataclass
class EvalProblem:
    """专项评测集中的一道难题。"""
    problem_id: str = ""
    domain: str = ""
    difficulty: int = 4           # 1-5
    statement: str = ""
    grading_hint: str = ""


# ---------------------------------------------------------------------------
# 自迭代与拓展提案
# ---------------------------------------------------------------------------

@dataclass
class PatchProposal:
    """自迭代补丁提案：必须经人工 approve 后才允许 apply（安全闸门）。"""
    patch_id: str = ""
    created_at: str = ""
    kind: str = "strategy_param"  # strategy_param / prompt_template / code / new_file
    target_file: str = ""         # 相对项目根的路径
    anchor: str = ""              # 被替换的精确原文片段（锚点）
    replacement: str = ""         # 替换后的新片段
    description: str = ""
    motivation: str = ""
    risk_level: str = "低"        # 低 / 中 / 高
    risk_assessment: str = ""
    expected_gain: str = ""
    rollback_plan: str = ""
    status: str = "pending"       # pending / approved / rejected / applied / rolled_back
    review_note: str = ""
    applied_at: str = ""


@dataclass
class CapabilityProposal:
    """自主能力拓展提案：EISA 提议的新能力模块（含可直接落盘的代码骨架）。"""
    proposal_id: str = ""
    created_at: str = ""
    name: str = ""
    module_name: str = ""
    motivation: str = ""
    design: str = ""
    code: str = ""
    integration_plan: str = ""
    risk_notes: str = ""
    status: str = "pending"       # pending / approved / rejected
    review_note: str = ""


@dataclass
class WeaknessReport:
    """自迭代引擎的短板分析报告。"""
    report_id: str = ""
    created_at: str = ""
    top_weaknesses: List[Dict[str, Any]] = field(default_factory=list)
    summary: str = ""
    source_stats: Dict[str, Any] = field(default_factory=dict)
