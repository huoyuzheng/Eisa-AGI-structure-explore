# -*- coding: utf-8 -*-
"""EISA 演示模块（供 CLI demo 子命令与 examples/demo.py 复用）。"""
from __future__ import annotations

from typing import Any, Dict

from eisa.orchestrator import EisaOrchestrator
from eisa.utils import get_logger

logger = get_logger("demo")


async def run_demo(orch: EisaOrchestrator | None = None) -> Dict[str, Any]:
    """端到端演示：返回关键结果摘要。"""
    orch = orch or EisaOrchestrator()
    user = "demo_user"

    r1 = await orch.handle_message(user, "什么是递归？")
    r2 = await orch.handle_message(
        user, "请系统性分析：如何为超大规模分布式系统设计一致性保证方案？请证明你的方案在各故障场景下依然成立。")
    tr = await orch.run_long_task(user, "设计一个高可用分布式消息队列，包含容量规划、故障恢复与监控告警")
    out = await orch.analyze_and_propose()

    return {
        "simple_answer": r1.answer[:200],
        "hard_brief": r2.brief(),
        "hard_branches": r2.branches,
        "long_task": tr.tree_text(),
        "pending_patches": out["pending_patches"],
        "pending_proposals": out["pending_proposals"],
    }
