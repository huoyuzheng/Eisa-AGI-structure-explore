# -*- coding: utf-8 -*-
"""领域定向能力放大模块。

对用户深耕领域构建「领域包 DomainPack」：
  - 专属思考链（领域方法论的固化步骤）
  - 专家子路由（领域专家人格优先占用分支）
  - 分支加成（该领域问题自动增加并行分支与预算）
领域包一次生成、本地缓存、可被自迭代补丁持续优化。
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import DomainPack, Message, ReasoningPlan
from eisa.utils import dc_from, dc_to, ensure_dir, extract_json, get_logger, load_json, now_iso, save_json

logger = get_logger("domain_amp")

DEFAULT_CHAIN_STEPS = [
    "澄清领域内问题的关键定义与约束",
    "调用领域公认方法/定理建立主推导线",
    "对关键中间结论做领域标准校验",
    "构造边界条件与反例检验稳健性",
    "按领域规范整理并呈现最终答案",
]


def domain_id_of(name: str) -> str:
    """领域名 -> 稳定短 id。"""
    h = hashlib.md5(name.encode("utf-8")).hexdigest()[:6]
    return f"dom_{h}"


class DomainAmplifier:
    """领域包管理与计划放大。"""

    def __init__(self, base_model: EisaBaseModel, store_dir: Path, cfg: Config):
        self.base_model = base_model
        self.dir = ensure_dir(store_dir)
        self.cfg = cfg

    # ------------------------------------------------------------------
    def _pack_path(self, domain_id: str) -> Path:
        return self.dir / f"{domain_id}.json"

    async def ensure_pack(self, domain_name: str) -> Optional[DomainPack]:
        """获取或创建领域包（一次生成，持久缓存）。"""
        if not domain_name:
            return None
        did = domain_id_of(domain_name)
        data = load_json(self._pack_path(did), None)
        if isinstance(data, dict) and data.get("domain_id"):
            pack = dc_from(DomainPack, data)
            pack.name = domain_name
            return pack

        pack = DomainPack(domain_id=did, name=domain_name,
                          keywords=[], chain_steps=[], expert_personas=[],
                          branch_bonus=int(self.cfg.get("reasoning.amplify_branch_bonus", 2)),
                          created_at=now_iso())

        # 基座生成专属思考链 + 专家人格（mock 后端亦可合成结构化占位）
        system = "你是 EISA 领域放大器：为深耕领域构建专属思考链与专家人格。仅输出JSON。"
        user = (
            f"领域: {domain_name}\n"
            "chain_steps 需体现该领域方法论；expert_personas 为 1-2 位该领域专家人格。\n"
            "【输出要求】仅输出JSON，字段: keywords, chain_steps, expert_personas"
        )
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.4, max_tokens=4096)
            data = extract_json(out.text) or {}
            if isinstance(data.get("keywords"), list):
                pack.keywords = [str(k)[:30] for k in data["keywords"]][:10]
            if isinstance(data.get("chain_steps"), list) and data["chain_steps"]:
                pack.chain_steps = [str(s)[:80] for s in data["chain_steps"]][:8]
            if isinstance(data.get("expert_personas"), list):
                pack.expert_personas = [
                    {"id": str(p.get("id", f"exp_{i + 1}")),
                     "name": str(p.get("name", f"{domain_name}专家{i + 1}"))[:24],
                     "style": str(p.get("style", "以领域最佳实践为准"))[:120]}
                    for i, p in enumerate(data["expert_personas"][:2])
                    if isinstance(p, dict)
                ]
        except Exception as e:
            logger.warning("领域包生成失败，使用默认模板: %s", e)

        if not pack.chain_steps:
            pack.chain_steps = list(DEFAULT_CHAIN_STEPS)
        save_json(self._pack_path(did), dc_to(pack))
        logger.info("已创建领域包[%s]: 思考链 %d 步, 专家 %d 位",
                    domain_name, len(pack.chain_steps), len(pack.expert_personas))
        return pack

    # ------------------------------------------------------------------
    def amplify_plan(self, plan: ReasoningPlan, pack: Optional[DomainPack]) -> ReasoningPlan:
        """把领域包注入推理计划：专属思考链 + 专家子路由 + 分支加成。"""
        if pack is None:
            return plan
        plan.domain_chain = list(pack.chain_steps)
        plan.domain_amplified = True
        if plan.budget is not None:
            plan.budget.max_branches = min(64, plan.budget.max_branches + pack.branch_bonus)
            plan.budget.tokens_per_branch = int(plan.budget.tokens_per_branch * 1.5)
        if "critical_check" not in plan.paradigms:
            plan.paradigms.append("critical_check")  # 领域问题强制附加批判校验分支
        plan.persona_hints = [ep.get("id", "") for ep in pack.expert_personas] + plan.persona_hints
        plan.notes += (f"；领域放大：注入「{pack.name}」专属思考链({len(pack.chain_steps)}步) "
                       f"+ 专家子路由({len(pack.expert_personas)}位) + 分支加成(+{pack.branch_bonus})")
        return plan

    # ------------------------------------------------------------------
    def packs_summary(self) -> List[Dict[str, Any]]:
        """列出全部领域包摘要。"""
        out = []
        for f in sorted(self.dir.glob("dom_*.json")):
            data = load_json(f, None)
            if isinstance(data, dict):
                out.append({"domain_id": data.get("domain_id"), "name": data.get("name"),
                            "chain_steps": len(data.get("chain_steps") or []),
                            "experts": len(data.get("expert_personas") or []),
                            "branch_bonus": data.get("branch_bonus"),
                            "eval_summary": data.get("eval_summary") or {}})
        return out
