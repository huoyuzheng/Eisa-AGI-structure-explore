# -*- coding: utf-8 -*-
"""领域识别模块：自动发现用户集中深耕的领域。

本地关键词计分打底（零成本、稳定），基座分类精化（仅非 mock 后端启用，
避免离线模式下合成领域污染画像）。识别结果写回用户画像 expertise。
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any, Dict, List, Optional

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import Message
from eisa.memory.user_profile import UserProfile
from eisa.utils import extract_json, get_logger, top_terms

logger = get_logger("domain_detect")

# 领域种子关键词表（可按需扩展）
DOMAIN_SEEDS: Dict[str, List[str]] = {
    "数学与算法": ["数学", "证明", "算法", "复杂度", "概率", "线性代数", "优化", "微积分", "组合"],
    "软件工程": ["代码", "架构", "重构", "API", "并发", "调试", "设计模式", "测试", "编译"],
    "机器学习": ["模型", "训练", "transformer", "embedding", "推理", "微调", "梯度", "神经网络"],
    "系统与基础设施": ["部署", "k8s", "性能", "监控", "数据库", "分布式", "缓存", "消息队列"],
    "科研写作": ["论文", "实验", "综述", "引用", "期刊", "审稿", "投稿"],
    "商业分析": ["市场", "商业", "增长", "竞品", "ROI", "营收", "商业模式"],
    "创意写作": ["小说", "文案", "剧本", "风格", "叙事", "角色"],
}


class DomainDetector:
    """领域识别器。"""

    def __init__(self, base_model: EisaBaseModel, cfg: Config):
        self.base_model = base_model
        self.cfg = cfg

    # ------------------------------------------------------------------
    def local_scores(self, texts: List[str]) -> Counter:
        """基于种子关键词的本地领域计分。"""
        counter: Counter = Counter()
        for t in texts:
            low = (t or "").lower()
            for domain, kws in DOMAIN_SEEDS.items():
                hits = sum(1 for k in kws if k.lower() in low)
                if hits:
                    counter[domain] += hits
        return counter

    def _level_from_count(self, count: int) -> int:
        """出现频次 -> 熟练度 1-5。"""
        if count >= 12:
            return 5
        if count >= 8:
            return 4
        if count >= 4:
            return 3
        if count >= 2:
            return 2
        return 1

    # ------------------------------------------------------------------
    async def detect(self, user_profile: Optional[UserProfile],
                     recent_texts: List[str]) -> Dict[str, Any]:
        """识别当前主要领域；返回 {primary_domain, domains, confidence}。"""
        local = self.local_scores(recent_texts)
        # 融合历史画像的领域计数
        if user_profile is not None:
            for d, lv in (user_profile.expertise or {}).items():
                local[d] += lv  # 历史熟练度作为累计权重

        candidates = [d for d, c in local.most_common(6) if c > 0]
        result: Dict[str, Any] = {"primary_domain": "", "domains": [], "confidence": 0.0,
                                  "top_level": 0}

        # 本地命中：直接采信（稳定、零成本）
        if candidates:
            primary = candidates[0]
            result["primary_domain"] = primary
            result["domains"] = [{"domain": d, "level": self._level_from_count(local[d])}
                                 for d in candidates]
            result["confidence"] = min(1.0, 0.5 + 0.1 * local[candidates[0]])
            result["top_level"] = max((d["level"] for d in result["domains"]), default=0)
            self._sync_profile(user_profile, result["domains"])
            return result

        # 本地无命中：仅真后端时用基座精化（mock 模式跳过，避免合成领域污染）
        if not self.base_model.backend.is_mock and recent_texts:
            try:
                system = "你是 EISA 领域识别器：判断用户当前深耕领域。仅输出JSON。"
                user = (
                    f"近期输入摘要:\n" + "\n".join(f"- {t[:120]}" for t in recent_texts[:5]) + "\n"
                    "【输出要求】仅输出JSON，字段: primary_domain, domains, confidence"
                )
                out = await self.base_model.infer(
                    [Message(role="system", content=system), Message(role="user", content=user)],
                    temperature=0.2, max_tokens=2048)
                data = extract_json(out.text) or {}
                if data.get("primary_domain"):
                    result["primary_domain"] = str(data["primary_domain"])[:40]
                    doms = data.get("domains") or []
                    result["domains"] = [{"domain": str(d.get("domain"))[:40],
                                          "level": int(d.get("level", 2))}
                                         for d in doms if isinstance(d, dict)][:6]
                    result["confidence"] = 0.6
                    result["top_level"] = max((d["level"] for d in result["domains"]), default=0)
                    self._sync_profile(user_profile, result["domains"])
            except Exception as e:
                logger.debug("领域识别基座精化失败（忽略）: %s", e)
        return result

    # ------------------------------------------------------------------
    def _sync_profile(self, profile: Optional[UserProfile], domains: List[Dict[str, Any]]) -> None:
        """把识别结果同步进用户画像（取历史最大熟练度）。"""
        if profile is None:
            return
        for d in domains:
            name, lv = d.get("domain"), int(d.get("level", 1))
            if not name:
                continue
            profile.expertise[name] = max(profile.expertise.get(name, 0), lv)
