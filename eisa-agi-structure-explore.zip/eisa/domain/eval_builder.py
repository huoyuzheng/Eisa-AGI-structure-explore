# -*- coding: utf-8 -*-
"""专项评测集构建器：自动收集领域难题、构建评测集、跑分并回流缺陷库。

流程：collect_hard_problems 生成难题集 -> run_eval 逐题走完整推理链路 ->
判卷 -> 结果落盘 -> 未通过样本流入缺陷库 -> 更新领域包评测摘要。
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import DomainPack, EvalProblem, Message
from eisa.utils import (dc_from, dc_to, ensure_dir, extract_json, get_logger,
                        load_json, new_id, now_iso, save_json, truncate)

logger = get_logger("eval")

AnswerFn = Callable[[str], Awaitable[Tuple[str, Any, Any]]]  # (answer, judge, reflection)


class EvalBuilder:
    """领域专项评测集构建与执行。"""

    def __init__(self, base_model: EisaBaseModel, evals_dir: Path, cfg: Config):
        self.base_model = base_model
        self.dir = ensure_dir(evals_dir)
        self.cfg = cfg

    # ------------------------------------------------------------------
    def _dom_dir(self, domain_id: str) -> Path:
        return ensure_dir(self.dir / domain_id)

    # ------------------------------------------------------------------
    async def collect_hard_problems(self, domain_name: str, pack: DomainPack,
                                    n: Optional[int] = None) -> List[EvalProblem]:
        """生成领域难题集（难度 3-5 级），持久化 problems.json。"""
        n = int(n or self.cfg.get("domain.eval_problems_per_domain", 10))
        system = "你是 EISA 评测集构建器：为领域生成高难度、可判卷的问题集。仅输出JSON。"
        user = (
            f"领域: {domain_name}\n领域关键词: {', '.join(pack.keywords[:6]) or '无'}\n"
            f"生成 {n} 道 3-5 级难度难题，每题附判卷要点。\n"
            "【输出要求】仅输出JSON，字段: problems"
        )
        problems: List[EvalProblem] = []
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.6, max_tokens=8192)
            data = extract_json(out.text) or {}
            for it in (data.get("problems") or [])[:n]:
                if isinstance(it, dict) and it.get("statement"):
                    problems.append(EvalProblem(
                        problem_id=str(it.get("problem_id") or new_id("p")),
                        domain=domain_name,
                        difficulty=int(it.get("difficulty", 4)),
                        statement=str(it["statement"])[:500],
                        grading_hint=str(it.get("grading_hint", ""))[:200],
                    ))
        except Exception as e:
            logger.warning("难题生成失败: %s", e)
        if not problems:
            problems = [EvalProblem(problem_id=f"p{i + 1}", domain=domain_name,
                                    difficulty=4,
                                    statement=f"「{domain_name}」领域高难度综合题 #{i + 1}",
                                    grading_hint="检查推导完整性与结论正确性")
                        for i in range(3)]
        save_json(self._dom_dir(pack.domain_id) / "problems.json",
                  [dc_to(p) for p in problems])
        logger.info("领域[%s] 评测集构建完成: %d 题", domain_name, len(problems))
        return problems

    def load_problems(self, domain_id: str) -> List[EvalProblem]:
        data = load_json(self._dom_dir(domain_id) / "problems.json", None)
        return [dc_from(EvalProblem, d) for d in (data or []) if isinstance(d, dict)]

    # ------------------------------------------------------------------
    async def run_eval(self, domain_name: str, pack: DomainPack, answer_fn: AnswerFn,
                       limit: Optional[int] = None, on_fail=None) -> Dict[str, Any]:
        """跑评测：answer_fn(statement) -> (answer, judge, reflection)。"""
        problems = self.load_problems(pack.domain_id)
        if not problems:
            problems = await self.collect_hard_problems(domain_name, pack)
        if limit:
            problems = problems[:limit]

        results: List[Dict[str, Any]] = []
        passed = 0
        for p in problems:
            try:
                answer, judge, _ = await answer_fn(p.statement)
                conf = float(judge.confidence) if judge is not None else 8.0
            except Exception as e:
                answer, conf = f"评测执行异常: {e}", 0.0
            grade = await self._grade(p, answer)
            ok = bool(grade.get("pass", False)) and conf >= 6.0
            passed += 1 if ok else 0
            rec = {"problem_id": p.problem_id, "difficulty": p.difficulty,
                   "statement": p.statement, "answer": truncate(answer, 600),
                   "confidence": conf, "grade": grade, "pass": ok}
            results.append(rec)
            if not ok and on_fail is not None:
                on_fail(p, rec)

        summary = {
            "domain_id": pack.domain_id, "domain": domain_name,
            "total": len(results), "passed": passed,
            "pass_rate": round(passed / max(1, len(results)), 3),
            "ran_at": now_iso(),
        }
        save_json(self._dom_dir(pack.domain_id) / "results.json",
                  {"summary": summary, "results": results})
        pack.eval_summary = summary
        logger.info("领域[%s] 评测完成: %d/%d 通过", domain_name, passed, len(results))
        return summary

    # ------------------------------------------------------------------
    async def _grade(self, problem: EvalProblem, answer: str) -> Dict[str, Any]:
        """基座判卷。"""
        system = "你是 EISA 评测判卷器：严格判定答案是否正确完整。仅输出JSON。"
        user = (
            f"题目（难度{problem.difficulty}）: {problem.statement}\n"
            f"判卷要点: {problem.grading_hint or '正确性与完整性'}\n"
            f"答案:\n{truncate(answer, 1500)}\n"
            "【输出要求】仅输出JSON，字段: pass, score, notes"
        )
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.1, max_tokens=2048)
            data = extract_json(out.text) or {}
            return {"pass": bool(data.get("pass", False)),
                    "score": float(data.get("score", 0.0)),
                    "notes": str(data.get("notes", ""))[:200]}
        except Exception as e:
            return {"pass": False, "score": 0.0, "notes": f"判卷异常: {e}"}
