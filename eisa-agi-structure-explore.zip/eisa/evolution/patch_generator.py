# -*- coding: utf-8 -*-
"""自迭代补丁生成器：分析短板报告，产出可人工审阅的修改补丁。

补丁三类：strategy_param（参数调优）/ prompt_template（提示词模板）/ code（框架代码）。
每个补丁必须包含：锚点片段、替换片段、改动说明、风险评估、预期收益、回滚方案。
生成后一律进入 pending 目录等待人工审核 —— 本模块无任何自动应用能力。
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from eisa.config import PROJECT_ROOT
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import Message, PatchProposal, WeaknessReport
from eisa.utils import extract_json, get_logger, hash_seed, new_id, now_iso

logger = get_logger("patch_gen")

# 短板类别 -> 建议修改目标
CANDIDATE_TARGETS = {
    "推理漏洞": "eisa/reasoning/meta_scheduler.py",
    "逻辑矛盾": "eisa/reasoning/judge.py",
    "事实错误": "eisa/reasoning/branch_engine.py",
    "规划失败": "eisa/planning/task_planner.py",
    "低置信度结果": "configs/eisa.yaml",
    "分支失败样例": "eisa/reasoning/budget.py",
    "反思未生效": "eisa/planning/recursive_reflector.py",
    "评测未通过": "configs/eisa.yaml",
}

# mock 后端的确定性示例补丁（按类别轮换，验证审核-应用-回滚全链路用）
CANNED_PATCHES: List[Dict[str, str]] = [
    {
        "kind": "strategy_param",
        "target_file": "configs/eisa.yaml",
        "anchor": "  score_threshold: 7.0",
        "replacement": "  score_threshold: 6.5",
        "description": "评审阈值调优：放宽终审通过阈值 7.0 -> 6.5，减少低难度问题的无效回溯修复",
        "motivation": "缺陷库与失败样例分析显示低置信度结果占比偏高",
        "risk_level": "低",
        "risk_assessment": "仅调整调度参数，不改代码逻辑；有备份可一键回滚",
        "expected_gain": "减少无效修复轮次，缩短推理链路",
        "rollback_plan": "执行 patch rollback <patch_id> 恢复备份文件",
    },
    {
        "kind": "strategy_param",
        "target_file": "configs/eisa.yaml",
        "anchor": "  debate_margin: 0.8",
        "replacement": "  debate_margin: 0.6",
        "description": "辩论触发条件调优：缩小 top2 触发辩论的分差阈值 0.8 -> 0.6，提高势均力敌问题的话语对抗强度",
        "motivation": "短板分析显示势均力敌问题的裁决置信度不足",
        "risk_level": "低",
        "risk_assessment": "仅调整调度参数，不改代码逻辑；有备份可一键回滚",
        "expected_gain": "提升胶着问题的裁决质量",
        "rollback_plan": "执行 patch rollback <patch_id> 恢复备份文件",
    },
    {
        "kind": "strategy_param",
        "target_file": "configs/eisa.yaml",
        "anchor": "  repair_max_rounds: 2",
        "replacement": "  repair_max_rounds: 3",
        "description": "回溯纠错轮次调优：2 -> 3，给低分分支更多修复机会",
        "motivation": "短板分析显示一次性修复成功率不足",
        "risk_level": "低",
        "risk_assessment": "仅调整调度参数，不改代码逻辑；有备份可一键回滚",
        "expected_gain": "提升困难问题的最终通过率",
        "rollback_plan": "执行 patch rollback <patch_id> 恢复备份文件",
    },
]


class PatchGenerator:
    """补丁提案生成器。"""

    def __init__(self, base_model: EisaBaseModel, patches_dir: Path):
        self.base_model = base_model
        self.pending_dir = patches_dir / "pending"
        self.pending_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    def assess_risk(self, kind: str, target_file: str, anchor_size: int) -> Tuple[str, str]:
        """自动风险评估。"""
        critical = ("eisa/evolution/", "eisa/core/base_model.py")
        if kind == "code":
            if any(target_file.replace("\\", "/").startswith(c) for c in critical):
                return "高", "修改核心/进化模块代码，可能影响全部推理链路，必须重点人工审查"
            return "中", "修改框架代码，需审查逻辑等价性与边界条件"
        if kind == "prompt_template":
            return "中", "修改提示词模板，可能改变模型行为模式，建议 A/B 观察"
        return "低", "仅调整调度参数，影响范围有限且可回滚"

    # ------------------------------------------------------------------
    def _validate(self, p: PatchProposal) -> Tuple[bool, str]:
        """结构校验：目标必须在项目根内、锚点必须存在且唯一。"""
        target = (PROJECT_ROOT / p.target_file).resolve()
        root = PROJECT_ROOT.resolve()
        if not str(target).startswith(str(root)):
            return False, "目标文件越出项目根"
        if p.kind == "new_file":
            return True, "新建文件"
        if not target.exists():
            return False, "目标文件不存在"
        content = target.read_text(encoding="utf-8")
        if not p.anchor or p.anchor not in content:
            return False, "锚点片段在目标文件中不存在"
        if content.count(p.anchor) != 1:
            return False, "锚点片段不唯一，存在误替换风险"
        return True, "校验通过"

    # ------------------------------------------------------------------
    async def propose_one(self, category: str, report: WeaknessReport) -> Optional[PatchProposal]:
        """为单个短板类别生成补丁提案。"""
        p = PatchProposal(patch_id=new_id("patch"), created_at=now_iso())

        if self.base_model.backend.is_mock:
            # 离线模式：确定性示例补丁（保证审核-应用-回滚链路可完整演练）
            # 按类别哈希轮换示例补丁，避免重复提案
            canned = CANNED_PATCHES[hash_seed(category) % len(CANNED_PATCHES)]
            p.kind = canned["kind"]
            p.target_file = canned["target_file"]
            p.anchor = canned["anchor"]
            p.replacement = canned["replacement"]
            p.description = canned["description"]
            p.motivation = f"短板分析：[{category}] 为当前最高频缺陷（详见 {report.report_id}）"
            p.expected_gain = canned["expected_gain"]
        else:
            system = ("你是 EISA 自迭代补丁生成器：针对短板生成最小、可回滚、"
                      "带精确锚点的框架修改补丁。仅输出JSON。")
            user = (
                f"短板类别: {category}\n"
                f"报告摘要: {report.summary[:300]}\n"
                f"候选目标: {CANDIDATE_TARGETS.get(category, 'configs/eisa.yaml')}\n"
                "anchor 必须是目标文件中真实存在且唯一的片段；replacement 为替换后片段。\n"
                "【输出要求】仅输出JSON，字段: kind, target_file, anchor, replacement, "
                "description, motivation, expected_gain, rollback_plan"
            )
            try:
                out = await self.base_model.infer(
                    [Message(role="system", content=system), Message(role="user", content=user)],
                    temperature=0.3, max_tokens=4096)
                data = extract_json(out.text) or {}
                p.kind = str(data.get("kind", "code"))
                p.target_file = str(data.get("target_file", "")).strip()
                p.anchor = str(data.get("anchor", ""))
                p.replacement = str(data.get("replacement", ""))
                p.description = str(data.get("description", ""))[:400]
                p.motivation = str(data.get("motivation", ""))[:400]
                p.expected_gain = str(data.get("expected_gain", ""))[:200]
            except Exception as e:
                logger.warning("补丁生成失败: %s", e)
                return None

        if not p.target_file or not p.description:
            return None
        p.risk_level, p.risk_assessment = self.assess_risk(p.kind, p.target_file,
                                                           len(p.anchor))
        if not p.rollback_plan:
            p.rollback_plan = "执行 patch rollback <patch_id> 恢复备份"
        ok, msg = self._validate(p)
        if not ok:
            logger.info("补丁 %s 未通过结构校验（%s），已丢弃", p.patch_id, msg)
            return None
        return p

    # ------------------------------------------------------------------
    def save_pending(self, p: PatchProposal) -> Path:
        path = self.pending_dir / f"{p.patch_id}.json"
        from eisa.utils import dc_to, save_json
        save_json(path, dc_to(p))
        return path
