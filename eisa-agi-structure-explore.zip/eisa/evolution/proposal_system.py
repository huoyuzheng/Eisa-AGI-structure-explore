# -*- coding: utf-8 -*-
"""自主能力拓展提案系统。

EISA 运行后可自主思考、枚举新增 AGI 方向能力模块，输出方案、设计思路、
可直接落盘的模块代码骨架。提案必须经人工 approve 后才物化为代码文件并
登记注册表（loader 只执行登记过的模块）—— 无审核代码永不运行。
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.core.base_model import EisaBaseModel
from eisa.core.types import CapabilityProposal
from eisa.extensions import loader as ext_loader
from eisa.memory.defect_library import DefectLibrary
from eisa.memory.self_profile import SelfProfileStore
from eisa.utils import (dc_from, dc_to, ensure_dir, extract_json, get_logger,
                        load_json, new_id, now_iso, save_json)

logger = get_logger("proposal")


# mock 后端的确定性示例提案（代码可直接运行）
CANNED_PROPOSALS: List[Dict[str, str]] = [
    {
        "name": "证据冲突消解器",
        "module_name": "evidence_conflict_resolver",
        "motivation": "多分支结论合并时偶发证据级冲突未被显式标注",
        "design": "post_reasoning 钩子扫描终稿答案，识别多个结论标记并追加人工复核警示",
        "integration_plan": "注册为扩展模块，无需改动主链路",
        "risk_notes": "只读式检查与标注，不改变推理结果本身",
        "code": '''from eisa.extensions.loader import CapabilityBase


class EvidenceConflictResolver(CapabilityBase):
    """证据冲突消解器：终稿前扫描自相矛盾断言并追加警示标注。"""

    name = "evidence_conflict_resolver"
    version = "0.1"
    description = "多分支结论合并后进行证据级冲突扫描，输出冲突标注"

    def post_reasoning(self, ctx, result):
        answer = getattr(result, "answer", "") or ""
        if answer.count("【结论】") > 1:
            result.answer = answer + "\\n\\n[扩展模块提示] 检测到多个结论标记，建议人工复核证据一致性。"
        return result
''',
    },
    {
        "name": "预算自适应调节器",
        "module_name": "adaptive_budget_tuner",
        "motivation": "超长问题在固定预算下反思深度不足",
        "design": "pre_reasoning 钩子按问题长度动态微调分支数与反思深度上限",
        "integration_plan": "注册为扩展模块，运行期热生效",
        "risk_notes": "仅上调预算上限，不降低任何安全阈值",
        "code": '''from eisa.extensions.loader import CapabilityBase


class AdaptiveBudgetTuner(CapabilityBase):
    """预算自适应调节器：按问题长度动态微调分支数与反思深度。"""

    name = "adaptive_budget_tuner"
    version = "0.1"
    description = "pre_reasoning 阶段对推理预算做轻量自适应修正"

    def pre_reasoning(self, ctx):
        plan = ctx.get("plan")
        question = ctx.get("question", "") or ""
        if plan is not None and plan.budget is not None and len(question) > 400:
            plan.budget.max_branches = min(plan.budget.max_branches + 2, 32)
            plan.budget.reflect_depth = min(plan.budget.reflect_depth + 1, 5)
        return ctx
''',
    },
]


class ProposalSystem:
    """能力拓展提案系统。"""

    def __init__(self, base_model: EisaBaseModel, proposals_dir: Path,
                 defect_library: DefectLibrary, self_profile_store: SelfProfileStore):
        self.base_model = base_model
        self.dirs = {s: ensure_dir(proposals_dir / s) for s in ["pending", "approved", "rejected"]}
        self.defects = defect_library
        self.self_profile = self_profile_store

    # ==================================================================
    async def brainstorm(self, n: int = 2) -> List[CapabilityProposal]:
        """自主枚举能力拓展提案（全部进入 pending）。"""
        out: List[CapabilityProposal] = []
        open_defects = self.defects.list_open(limit=5)

        if self.base_model.backend.is_mock:
            sources = CANNED_PROPOSALS[:n]
        else:
            sources = await self._llm_proposals(n, open_defects)

        for src in sources[:n]:
            p = CapabilityProposal(
                proposal_id=new_id("prop"), created_at=now_iso(),
                name=str(src.get("name", "未命名能力"))[:40],
                module_name=str(src.get("module_name", ""))[:60],
                motivation=str(src.get("motivation", ""))[:300],
                design=str(src.get("design", ""))[:500],
                code=str(src.get("code", "")),
                integration_plan=str(src.get("integration_plan", ""))[:200],
                risk_notes=str(src.get("risk_notes", ""))[:200],
            )
            if open_defects and not p.motivation:
                p.motivation = f"针对开放缺陷: {open_defects[0]['description'][:80]}"
            save_json(self.dirs["pending"] / f"{p.proposal_id}.json", dc_to(p))
            out.append(p)
        logger.info("能力提案完成: %d 个进入待审队列", len(out))
        return out

    async def _llm_proposals(self, n: int, open_defects: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """真后端：由基座构思能力提案。"""
        from eisa.core.types import Message
        system = ("你是 EISA 能力拓展提案系统：构思新增 AGI 方向能力模块，"
                  "输出设计思路与可运行的 Python 模块代码（继承 CapabilityBase）。仅输出JSON。")
        defect_brief = "; ".join(d["description"][:60] for d in open_defects[:3]) or "无"
        user = (
            f"当前待优化项: {defect_brief}\n"
            f"提出 {n} 个新能力模块；code 必须是继承 CapabilityBase 的完整 Python 代码。\n"
            "【输出要求】仅输出JSON，字段: proposals"
        )
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.7, max_tokens=8192)
            data = extract_json(out.text) or {}
            items = data.get("proposals") or []
            return [it for it in items if isinstance(it, dict)]
        except Exception as e:
            logger.warning("能力提案生成失败: %s", e)
            return []

    # ==================================================================
    def list_proposals(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for s, d in self.dirs.items():
            if status and s != status:
                continue
            for f in sorted(d.glob("prop_*.json")):
                data = load_json(f, None)
                if isinstance(data, dict):
                    out.append({"proposal_id": data.get("proposal_id", f.stem), "status": s,
                                "name": data.get("name"), "module_name": data.get("module_name"),
                                "risk_notes": data.get("risk_notes"), "path": str(f)})
        return out

    def load_proposal(self, proposal_id: str) -> Optional[CapabilityProposal]:
        for s, d in self.dirs.items():
            f = d / f"{proposal_id}.json"
            if f.exists():
                return dc_from(CapabilityProposal, load_json(f, {}))
        return None

    def approve_proposal(self, proposal_id: str, note: str = "") -> Dict[str, Any]:
        """人工批准提案：物化模块代码 + 登记注册表（此后 loader 才会加载执行）。"""
        p = self.load_proposal(proposal_id)
        if p is None:
            return {"ok": False, "message": "提案不存在"}
        if p.status != "pending":
            return {"ok": False, "message": f"提案当前状态为 {p.status}，不能批准"}
        try:
            file_path = ext_loader.materialize_extension(
                p.name, p.module_name, p.code, p.design)
        except Exception as e:
            return {"ok": False, "message": f"模块落盘失败: {e}"}
        p.status = "approved"
        p.review_note = note or "人工审核通过"
        save_json(self.dirs["approved"] / f"{proposal_id}.json", dc_to(p))
        self._move(proposal_id, "approved")
        self.self_profile.record_iteration({
            "action": "proposal_approved", "proposal_id": proposal_id,
            "module": p.module_name, "note": p.name,
        })
        return {"ok": True, "message": f"提案已批准并注册为扩展模块: {file_path}",
                "module_file": file_path}

    def reject_proposal(self, proposal_id: str, note: str = "") -> Dict[str, Any]:
        p = self.load_proposal(proposal_id)
        if p is None:
            return {"ok": False, "message": "提案不存在"}
        p.status = "rejected"
        p.review_note = note or "人工驳回"
        save_json(self.dirs["rejected"] / f"{proposal_id}.json", dc_to(p))
        self._move(proposal_id, "rejected")
        return {"ok": True, "message": f"提案 {proposal_id} 已驳回"}

    def _move(self, proposal_id: str, to_status: str) -> None:
        import shutil
        for s, d in self.dirs.items():
            src = d / f"{proposal_id}.json"
            if src.exists():
                shutil.move(str(src), str(self.dirs[to_status] / f"{proposal_id}.json"))
                return
