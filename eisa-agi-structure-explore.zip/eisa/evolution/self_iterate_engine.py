# -*- coding: utf-8 -*-
"""自迭代代码引擎（带强制人工审核闸门）。

流程：
  analyze()  —— 读取对话日志失败样例、缺陷库、领域评测结果，产出短板报告
  propose()  —— 为短板生成修改补丁提案（含风险评估/改动说明/回滚方案）
  人工闸门   —— 补丁必须经 `approve` 人工确认后才允许 `apply`；
               apply 前自动备份原文件，支持 rollback 一键回滚。
引擎自身绝不自动应用任何更新（硬性约束）。
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.config import PROJECT_ROOT
from eisa.core.types import PatchProposal, WeaknessReport
from eisa.evolution.patch_generator import PatchGenerator
from eisa.memory.defect_library import DefectLibrary
from eisa.memory.dialog_store import DialogStore
from eisa.memory.self_profile import SelfProfileStore
from eisa.memory.user_profile import UserProfileStore
from eisa.utils import (dc_from, dc_to, ensure_dir, get_logger, load_json,
                        new_id, now_iso, save_json)

logger = get_logger("iterate")

STATUS_DIRS = ["pending", "approved", "rejected", "applied"]


class SelfIterateEngine:
    """自迭代引擎：分析短板 → 生成补丁 → 人工审核 → 应用/回滚。"""

    def __init__(self, cfg, patches_dir: Path,
                 user_profiles: UserProfileStore,
                 defect_library: DefectLibrary,
                 self_profile_store: SelfProfileStore,
                 evals_dir: Path,
                 reports_dir: Path):
        self.cfg = cfg
        self.dirs = {s: ensure_dir(patches_dir / s) for s in STATUS_DIRS}
        self.user_profiles = user_profiles
        self.defects = defect_library
        self.self_profile = self_profile_store
        self.evals_dir = evals_dir
        self.reports_dir = ensure_dir(reports_dir)
        self.dialogs: Optional[DialogStore] = None
        self.patch_gen = PatchGenerator(None, patches_dir)  # 后端由 set_backend 注入
        self._backend = None

    def set_backend(self, base_model) -> None:
        """注入基座引用（生成补丁文本用）。"""
        self._backend = base_model
        self.patch_gen.base_model = base_model

    def set_dialogs(self, dialogs: DialogStore) -> None:
        """注入对话日志存储（失败样例数据源）。"""
        self.dialogs = dialogs

    # ==================================================================
    # 一、短板分析
    # ==================================================================
    def _collect_eval_stats(self) -> Dict[str, Any]:
        """汇总各领域评测结果。"""
        stats: Dict[str, Any] = {}
        if not self.evals_dir.exists():
            return stats
        for f in self.evals_dir.glob("*/results.json"):
            data = load_json(f, None)
            if isinstance(data, dict) and data.get("summary"):
                s = data["summary"]
                stats[s.get("domain", f.parent.name)] = {
                    "total": s.get("total", 0),
                    "passed": s.get("passed", 0),
                    "pass_rate": s.get("pass_rate", 0.0),
                }
        return stats

    def analyze(self) -> WeaknessReport:
        """短板分析：聚合失败样例、缺陷库、评测结果。"""
        report = WeaknessReport(report_id=new_id("weak"), created_at=now_iso())

        fails = self.dialogs.failures(limit=200) if self.dialogs is not None else []
        # dialogs 引用由 orchestrator 注入；未注入时直接从 store 拿
        stats = {
            "failure_samples": len(fails),
            "defects_open": len(self.defects.list_open()),
            "eval_domains": self._collect_eval_stats(),
        }

        # 缺陷库类别聚合（主证据）
        cat_summary = self.defects.summary_by_category()
        top: List[Dict[str, Any]] = []
        samples = {d["category"]: d["description"] for d in self.defects.list_open(limit=50)}
        for cat, cnt in sorted(cat_summary.items(), key=lambda kv: -kv[1]):
            top.append({"category": cat, "count": cnt, "sample": samples.get(cat, "")})

        # 评测通过率过低的领域也视为短板
        for dom, s in (stats["eval_domains"] or {}).items():
            if s["total"] >= 3 and s["pass_rate"] < 0.5:
                top.append({"category": "评测未通过",
                            "count": s["total"] - s["passed"],
                            "sample": f"领域[{dom}] 通过率仅 {s['pass_rate']}"})

        top.sort(key=lambda x: -x["count"])
        report.top_weaknesses = top[:6]
        report.source_stats = stats
        if top:
            report.summary = ("; ".join(f"{t['category']}×{t['count']}" for t in top[:3])
                              + f"。失败样例 {stats['failure_samples']} 条，"
                                f"开放缺陷 {stats['defects_open']} 项。")
        else:
            report.summary = "未发现显著短板。"
        save_json(self.reports_dir / f"{report.report_id}.json", dc_to(report))
        logger.info("短板分析完成: %s", report.summary)
        return report

    # ==================================================================
    # 二、补丁提案（生成后一律 pending）
    # ==================================================================
    async def propose_patches(self, limit: int = 3) -> List[PatchProposal]:
        """按短板生成补丁提案（全部进入 pending 等待人工审核）。"""
        report = self.analyze()
        patches: List[PatchProposal] = []
        items = report.top_weaknesses[:limit]
        if not items:
            # 兜底：即使当前无显著短板，也保留一条常规自调优提案（探索型框架常态机制）
            items = [{"category": "常规自调优", "count": 0, "sample": "无失败样例时的保守参数巡检"}]
        for item in items:
            p = await self.patch_gen.propose_one(item["category"], report)
            if p is None:
                continue
            self.patch_gen.save_pending(p)
            patches.append(p)
        logger.info("补丁提案完成: %d 个进入待审队列", len(patches))
        return patches

    # ==================================================================
    # 三、人工审核闸门（list / show / approve / reject / apply / rollback）
    # ==================================================================
    def list_patches(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """列出补丁（可按状态过滤）。"""
        out: List[Dict[str, Any]] = []
        for s in STATUS_DIRS:
            if status and s != status:
                continue
            for f in sorted(self.dirs[s].glob("patch_*.json")):
                d = load_json(f, None)
                if isinstance(d, dict):
                    out.append({"patch_id": d.get("patch_id", f.stem), "status": s,
                                "kind": d.get("kind"), "target_file": d.get("target_file"),
                                "risk_level": d.get("risk_level"), "path": str(f)})
        return out

    def load_patch(self, patch_id: str) -> Optional[PatchProposal]:
        for s in STATUS_DIRS:
            f = self.dirs[s] / f"{patch_id}.json"
            if f.exists():
                return dc_from(PatchProposal, load_json(f, {}))
        return None

    def _move(self, patch_id: str, to_status: str) -> None:
        """补丁记录在状态目录间迁移。"""
        for s in STATUS_DIRS:
            src = self.dirs[s] / f"{patch_id}.json"
            if src.exists():
                dst = self.dirs[to_status] / f"{patch_id}.json"
                shutil.move(str(src), str(dst))
                return

    def _update_and_move(self, p: PatchProposal, to_status: str) -> None:
        """更新补丁记录内容并迁移到目标状态目录（原子替换，避免双写覆盖）。"""
        for s in STATUS_DIRS:
            src = self.dirs[s] / f"{p.patch_id}.json"
            if src.exists():
                save_json(self.dirs[to_status] / f"{p.patch_id}.json", dc_to(p))
                src.unlink()
                return
        save_json(self.dirs[to_status] / f"{p.patch_id}.json", dc_to(p))

    def approve_patch(self, patch_id: str, note: str = "") -> Dict[str, Any]:
        """人工批准补丁。"""
        p = self.load_patch(patch_id)
        if p is None:
            return {"ok": False, "message": "补丁不存在"}
        if p.status != "pending":
            return {"ok": False, "message": f"补丁当前状态为 {p.status}，不能批准"}
        p.status = "approved"
        p.review_note = note or "人工审核通过"
        self._update_and_move(p, "approved")
        return {"ok": True, "message": f"补丁 {patch_id} 已批准，可执行 apply"}

    def reject_patch(self, patch_id: str, note: str = "") -> Dict[str, Any]:
        """人工驳回补丁。"""
        p = self.load_patch(patch_id)
        if p is None:
            return {"ok": False, "message": "补丁不存在"}
        p.status = "rejected"
        p.review_note = note or "人工驳回"
        self._update_and_move(p, "rejected")
        return {"ok": True, "message": f"补丁 {patch_id} 已驳回"}

    def apply_patch(self, patch_id: str) -> Dict[str, Any]:
        """应用补丁（强制要求已 approve；自动备份，支持回滚）。"""
        p = self.load_patch(patch_id)
        if p is None:
            return {"ok": False, "message": "补丁不存在"}
        # —— 硬性安全闸门：禁止未审核应用 ——
        if p.status != "approved":
            return {"ok": False,
                    "message": f"安全闸门：补丁状态为 {p.status}，必须先经人工审核 approve 后才允许应用（禁止自动改代码）"}
        target = (PROJECT_ROOT / p.target_file).resolve()
        root = PROJECT_ROOT.resolve()
        if not str(target).startswith(str(root)):
            return {"ok": False, "message": "目标文件越出项目根，已拒绝"}
        if not target.exists():
            return {"ok": False, "message": "目标文件不存在"}

        content = target.read_text(encoding="utf-8")
        # 先校验锚点，再备份，最后应用（失败不留任何半改状态）
        if not (p.anchor and p.anchor in content):
            return {"ok": False, "message": "锚点片段未找到，拒绝盲改"}
        backup = self.dirs["applied"] / f"{patch_id}__{target.name}.bak"
        backup.write_text(content, encoding="utf-8")
        new_content = content.replace(p.anchor, p.replacement, 1)
        target.write_text(new_content, encoding="utf-8")

        p.status = "applied"
        p.applied_at = now_iso()
        self._update_and_move(p, "applied")
        self.self_profile.record_iteration({
            "action": "patch_applied", "patch_id": patch_id,
            "kind": p.kind, "target_file": p.target_file, "note": p.description[:150],
        })
        logger.info("补丁 %s 已应用（备份: %s）", patch_id, backup)
        return {"ok": True, "message": f"补丁已应用，备份保存于 {backup}",
                "backup": str(backup)}

    def rollback_patch(self, patch_id: str) -> Dict[str, Any]:
        """回滚已应用补丁。"""
        p = self.load_patch(patch_id)
        if p is None or p.status != "applied":
            return {"ok": False, "message": "仅已应用的补丁可回滚"}
        backups = list(self.dirs["applied"].glob(f"{patch_id}__*.bak"))
        if not backups:
            return {"ok": False, "message": "未找到备份文件"}
        target = (PROJECT_ROOT / p.target_file).resolve()
        shutil.copy(str(backups[0]), str(target))
        p.status = "rolled_back"
        save_json(self.dirs["applied"] / f"{patch_id}.json", dc_to(p))
        self.self_profile.record_iteration({
            "action": "patch_rollback", "patch_id": patch_id,
            "target_file": p.target_file, "note": "已从备份恢复",
        })
        return {"ok": True, "message": f"补丁 {patch_id} 已回滚（原文件已恢复）"}
