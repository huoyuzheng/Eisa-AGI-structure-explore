# -*- coding: utf-8 -*-
"""能力扩展加载器：可插拔增强模块的注册与运行。

安全模型：
1. 提案系统生成的模块代码先落盘至 contrib/ 并登记 registry.json（仅人工批准后才登记）；
2. 加载器只加载 registry.json 中登记的模块 —— 未审核代码永远不会被执行；
3. 所有钩子调用均做异常隔离，扩展故障不影响主链路。
"""
from __future__ import annotations

import importlib.util
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.config import PROJECT_ROOT
from eisa.utils import get_logger, load_json, now_iso, save_json

logger = get_logger("extensions")

CONTRIB_DIR = PROJECT_ROOT / "eisa" / "extensions" / "contrib"
REGISTRY_PATH = PROJECT_ROOT / "eisa" / "extensions" / "registry.json"


class CapabilityBase:
    """能力扩展基类：新模块继承并覆写所需钩子。"""

    name: str = "unnamed"
    version: str = "0.1"
    description: str = ""

    def pre_reasoning(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """推理前钩子：可修改 ctx['plan'] 预算/策略。"""
        return ctx

    def post_reasoning(self, ctx: Dict[str, Any], result: Any) -> Any:
        """推理后钩子：可审查/追加标注最终结果。"""
        return result

    def pre_planning(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """长程规划前钩子。"""
        return ctx

    def on_defect(self, ctx: Dict[str, Any], defect: Dict[str, Any]) -> None:
        """缺陷产生时钩子（观察者）。"""
        return None


# ---------------------------------------------------------------------------
# 注册表管理
# ---------------------------------------------------------------------------

def _registry() -> List[str]:
    data = load_json(REGISTRY_PATH, None)
    names = data.get("registered") if isinstance(data, dict) else None
    return list(names) if isinstance(names, list) else []


def register_extension(module_name: str) -> None:
    """登记模块到注册表（仅由提案审批流程调用）。"""
    names = _registry()
    if module_name not in names:
        names.append(module_name)
    save_json(REGISTRY_PATH, {"registered": names, "updated_at": now_iso()})


def unregister_extension(module_name: str) -> None:
    names = [n for n in _registry() if n != module_name]
    save_json(REGISTRY_PATH, {"registered": names, "updated_at": now_iso()})


def registered_modules() -> List[str]:
    return _registry()


# ---------------------------------------------------------------------------
# 动态加载
# ---------------------------------------------------------------------------

def _import_module(module_name: str):
    """按文件名动态导入 contrib 下的模块。"""
    py = CONTRIB_DIR / f"{module_name}.py"
    if not py.exists():
        logger.warning("扩展模块文件不存在: %s", py)
        return None
    spec = importlib.util.spec_from_file_location(f"eisa.extensions.contrib.{module_name}", py)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
        return mod
    except Exception as e:
        logger.error("扩展模块 %s 导入失败: %s", module_name, e)
        return None


def load_extensions() -> List[CapabilityBase]:
    """加载注册表中登记的全部能力模块（未登记代码不执行）。"""
    caps: List[CapabilityBase] = []
    for name in _registry():
        mod = _import_module(name)
        if mod is None:
            continue
        found = False
        for attr in vars(mod).values():
            if (isinstance(attr, type) and issubclass(attr, CapabilityBase)
                    and attr is not CapabilityBase):
                try:
                    inst = attr()
                    caps.append(inst)
                    logger.info("能力扩展已加载: %s v%s", inst.name, inst.version)
                    found = True
                except Exception as e:
                    logger.error("能力扩展 %s 实例化失败: %s", name, e)
        if not found:
            logger.warning("模块 %s 中未找到 CapabilityBase 子类", name)
    return caps


class ExtensionRunner:
    """扩展钩子统一执行器（异常隔离）。"""

    def __init__(self, capabilities: Optional[List[CapabilityBase]] = None):
        self.capabilities = capabilities or []

    def run_pre_reasoning(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        for cap in self.capabilities:
            try:
                ctx = cap.pre_reasoning(ctx) or ctx
            except Exception as e:
                logger.warning("扩展 %s pre_reasoning 异常（跳过）: %s", cap.name, e)
        return ctx

    def run_post_reasoning(self, ctx: Dict[str, Any], result: Any) -> Any:
        for cap in self.capabilities:
            try:
                result = cap.post_reasoning(ctx, result) or result
            except Exception as e:
                logger.warning("扩展 %s post_reasoning 异常（跳过）: %s", cap.name, e)
        return result

    def run_pre_planning(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        for cap in self.capabilities:
            try:
                ctx = cap.pre_planning(ctx) or ctx
            except Exception as e:
                logger.warning("扩展 %s pre_planning 异常（跳过）: %s", cap.name, e)
        return ctx

    def run_on_defect(self, ctx: Dict[str, Any], defect: Dict[str, Any]) -> None:
        for cap in self.capabilities:
            try:
                cap.on_defect(ctx, defect)
            except Exception as e:
                logger.warning("扩展 %s on_defect 异常（跳过）: %s", cap.name, e)


# ---------------------------------------------------------------------------
# 提案审批后生成模块文件
# ---------------------------------------------------------------------------

DEFAULT_CAPABILITY_TEMPLATE = '''from eisa.extensions.loader import CapabilityBase


class {class_name}(CapabilityBase):
    """占位能力模块：请在此实现自定义增强逻辑。"""

    name = "{module_name}"
    version = "0.1"
    description = "由 EISA 能力拓展提案系统生成的模块"

    def post_reasoning(self, ctx, result):
        return result
'''


def materialize_extension(name: str, module_name: str, code: str, design_note: str = "") -> str:
    """把提案代码落盘为 contrib 模块文件并登记（仅由提案 approve 调用）。"""
    snake = re.sub(r"[^0-9a-zA-Z]+", "_", module_name or name).strip("_").lower() or "cap_module"
    CONTRIB_DIR.mkdir(parents=True, exist_ok=True)
    file_path = CONTRIB_DIR / f"{snake}.py"
    if not (code or "").strip():
        class_name = "".join(w.capitalize() for w in snake.split("_"))
        code = DEFAULT_CAPABILITY_TEMPLATE.format(class_name=class_name, module_name=snake)
    header = (
        "# -*- coding: utf-8 -*-\n"
        f'"""能力扩展模块：{name}（经人工审核后由提案系统生成）。\n\n'
        f"设计说明: {design_note[:300]}\n"
        f'"""\n\n'
    )
    file_path.write_text(header + code.strip() + "\n", encoding="utf-8")
    register_extension(snake)
    logger.info("能力扩展已落盘并登记: %s -> %s", name, file_path)
    return str(file_path)
