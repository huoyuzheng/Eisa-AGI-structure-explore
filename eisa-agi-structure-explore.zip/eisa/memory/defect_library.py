# -*- coding: utf-8 -*-
"""缺陷库：收集失败样例、矛盾、低置信度结果等缺陷，供自迭代引擎分析短板。

每次多分支推理产生的失败分支、矛盾排查结论、低置信度结果都会写入这里，
作为 EISA 自我迭代的证据来源。
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.core.types import DefectRecord
from eisa.utils import (dc_from, dc_to, get_logger, load_json, new_id,
                        now_iso, save_json)

logger = get_logger("defects")


class DefectLibrary:
    """缺陷库（JSON 持久化，按 category+描述 去重并累计频次）。"""

    def __init__(self, library_path: Path):
        self.path = Path(library_path)
        data = load_json(self.path, None)
        self._defects: List[DefectRecord] = []
        if isinstance(data, dict):
            for d in data.get("defects") or []:
                self._defects.append(dc_from(DefectRecord, d))

    # ------------------------------------------------------------------
    def _save(self) -> None:
        save_json(self.path, {"defects": [dc_to(d) for d in self._defects]})

    def add(self, category: str, description: str, trigger_context: str = "",
            severity: str = "中", related_ids: Optional[List[str]] = None) -> DefectRecord:
        """登记缺陷；同类目且描述相近则频次 +1。"""
        now = now_iso()
        key = (category, description[:60])
        for d in self._defects:
            if (d.category, d.description[:60]) == key and d.status != "fixed":
                d.frequency += 1
                d.last_seen = now
                if related_ids:
                    for rid in related_ids:
                        if rid not in d.related_ids:
                            d.related_ids.append(rid)
                self._save()
                return d
        rec = DefectRecord(
            defect_id=new_id("defect"),
            category=category,
            description=description[:400],
            trigger_context=trigger_context[:400],
            severity=severity,
            first_seen=now,
            last_seen=now,
            related_ids=list(related_ids or []),
        )
        self._defects.append(rec)
        self._save()
        logger.info("新缺陷登记: [%s] %s", category, description[:80])
        return rec

    # ------------------------------------------------------------------
    def list_open(self, limit: int = 20) -> List[Dict[str, Any]]:
        """未修复缺陷（按频次降序）。"""
        opens = [d for d in self._defects if d.status != "fixed"]
        opens.sort(key=lambda d: -d.frequency)
        return [dc_to(d) for d in opens[:limit]]

    def summary_by_category(self) -> Dict[str, int]:
        """按类目聚合未修复缺陷频次。"""
        out: Dict[str, int] = {}
        for d in self._defects:
            if d.status != "fixed":
                out[d.category] = out.get(d.category, 0) + d.frequency
        return out

    def mark_fixed(self, defect_id: str, note: str = "") -> bool:
        """标记缺陷为已修复（补丁应用后可调用）。"""
        for d in self._defects:
            if d.defect_id == defect_id:
                d.status = "fixed"
                if note:
                    d.description = (d.description + f"｜修复备注: {note}")[:400]
                self._save()
                return True
        return False

    def to_prompt_summary(self, limit: int = 10) -> str:
        """压缩为提示词摘要（供反思/自迭代提示词使用）。"""
        opens = self.list_open(limit=limit)
        if not opens:
            return "（缺陷库为空）"
        lines = [f"- [{d['category']}|{d['severity']}|频次{d['frequency']}] {str(d['description'])[:80]}"
                 for d in opens]
        return "当前已知缺陷:\n" + "\n".join(lines)

    def __len__(self) -> int:
        return len(self._defects)
