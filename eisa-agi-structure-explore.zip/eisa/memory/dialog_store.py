# -*- coding: utf-8 -*-
"""对话日志存储：JSONL 追加式记录每次完整交互，供自迭代引擎复盘分析。"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.core.types import InteractionRecord
from eisa.utils import append_jsonl, dc_from, dc_to, ensure_dir, get_logger, now_iso, read_jsonl

logger = get_logger("dialog_store")


class DialogStore:
    """按用户分文件的 JSONL 交互日志。"""

    def __init__(self, dialogs_dir: Path):
        self.dir = ensure_dir(dialogs_dir)

    def _path(self, user_id: str) -> Path:
        safe = re.sub(r"[^\w\-.]+", "_", user_id).strip("_") or "anonymous"
        return self.dir / f"{safe}.jsonl"

    def append(self, record: InteractionRecord) -> None:
        """追加一条交互记录（含策略、评分、缺陷标记，供失败复盘）。"""
        if not record.ts:
            record.ts = now_iso()
        append_jsonl(self._path(record.user_id), dc_to(record))

    def recent(self, user_id: str, n: int = 5) -> List[Dict[str, Any]]:
        """最近 n 条记录（构造对话上下文用）。"""
        recs = read_jsonl(self._path(user_id))
        return recs[-n:]

    def _all_files(self) -> List[Path]:
        return sorted(self.dir.glob("*.jsonl"))

    def all_records(self, limit: int = 500) -> List[Dict[str, Any]]:
        """全部用户的所有记录（按时间倒序，限 limit 条）。"""
        recs: List[Dict[str, Any]] = []
        for f in self._all_files():
            recs.extend(read_jsonl(f))
        recs.sort(key=lambda r: r.get("ts", ""), reverse=True)
        return recs[:limit]

    def failures(self, limit: int = 100) -> List[Dict[str, Any]]:
        """全部失败/低置信度样例（自迭代引擎的主要输入之一）。"""
        fails = [r for r in self.all_records(limit=2000) if r.get("success") is False]
        return fails[:limit]

    def dialog_brief(self, user_id: str, n: int = 5) -> str:
        """把最近对话压缩成上下文摘要文本。"""
        recs = self.recent(user_id, n=n)
        if not recs:
            return "（本轮为首次对话，无历史上下文）"
        lines = []
        for r in recs:
            q = str(r.get("query", ""))[:80]
            a = str(r.get("answer", ""))[:80]
            lines.append(f"- 问: {q} -> 答: {a}（策略 {r.get('strategy', '?')}，置信度 {r.get('confidence', '?')}）")
        return "最近对话摘要:\n" + "\n".join(lines)
