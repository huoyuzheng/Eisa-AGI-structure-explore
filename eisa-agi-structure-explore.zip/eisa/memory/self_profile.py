# -*- coding: utf-8 -*-
"""EISA 自我认知画像模块。

独立的自我档案：记录自身框架能力、已知缺陷、当前策略版本、待优化清单、
能力边界、历史迭代记录。EISA 在推理时可读取这份档案，实现自省式推理。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.utils import (dc_from, dc_to, get_logger, load_json, now_iso, save_json)

logger = get_logger("self_profile")


@dataclass
class SelfProfile:
    """EISA 自我档案。"""
    version: str = "v0.1"
    updated_at: str = ""
    framework_capabilities: List[Dict[str, Any]] = field(default_factory=list)  # {module, capability, status}
    known_defects: List[Dict[str, Any]] = field(default_factory=list)           # {defect_id, category, description, status}
    current_strategy_version: str = "strategy-2026-11-v1"
    pending_optimizations: List[Dict[str, Any]] = field(default_factory=list)   # {item, priority, source}
    capability_boundaries: List[str] = field(default_factory=list)              # 能力边界声明
    iteration_history: List[Dict[str, Any]] = field(default_factory=list)       # 历史迭代记录
    self_metrics: Dict[str, Any] = field(default_factory=lambda: {
        "total_interactions": 0, "total_branches": 0, "sum_confidence": 0.0})


class SelfProfileStore:
    """自我档案仓：加载 / 保存 / 缺陷同步 / 迭代记录 / 提示词渲染。"""

    def __init__(self, profile_path: Path):
        self.path = Path(profile_path)
        self._cache: Optional[SelfProfile] = None

    # ------------------------------------------------------------------
    def load(self) -> SelfProfile:
        if self._cache is not None:
            return self._cache
        data = load_json(self.path, None)
        profile = dc_from(SelfProfile, data) if isinstance(data, dict) else SelfProfile()
        if not profile.updated_at:
            self._seed_defaults(profile)
        self._cache = profile
        return profile

    def save(self) -> None:
        p = self.load()
        p.updated_at = now_iso()
        save_json(self.path, dc_to(p))

    @staticmethod
    def _seed_defaults(profile: SelfProfile) -> None:
        """首次运行时写入初始自我认知（框架自带能力的诚实声明）。"""
        profile.framework_capabilities = [
            {"module": "meta_scheduler", "capability": "动态选择推理范式/分支数/预算", "status": "可用"},
            {"module": "branch_engine", "capability": "多分支异构并行推理", "status": "可用"},
            {"module": "judge", "capability": "多层自省评判（独立评分/交叉互评/矛盾排查/终审）", "status": "可用"},
            {"module": "recursive_reflector", "capability": "分层递归反思与修复", "status": "可用"},
            {"module": "task_planner", "capability": "长程任务拆解与里程碑复盘", "status": "可用"},
            {"module": "domain_amplifier", "capability": "领域专属思考链与专家子路由", "status": "可用"},
            {"module": "self_iterate_engine", "capability": "短板分析并生成补丁提案（须人工审核）", "status": "可用"},
            {"module": "proposal_system", "capability": "提出新能力模块提案（须人工审核）", "status": "可用"},
        ]
        profile.capability_boundaries = [
            "不训练、不修改基座权重：所有增强只发生在推理外层调度",
            "补丁与能力提案必须经人工审核，绝不自动改代码",
            "依赖底层基座的固有能力边界；框架只能放大、不能凭空创造基座没有的知识",
            "长上下文任务受基座 context_window 约束，框架通过任务拆解缓解而非突破",
        ]

    # ------------------------------------------------------------------
    def sync_defects(self, defect_library) -> None:
        """把缺陷库 top 缺陷同步进自我档案（自省素材）。"""
        p = self.load()
        open_items = defect_library.list_open(limit=10)
        p.known_defects = [{
            "defect_id": d.get("defect_id"),
            "category": d.get("category"),
            "description": d.get("description"),
            "frequency": d.get("frequency"),
            "status": d.get("status"),
        } for d in open_items]
        # 待优化清单：按缺陷类目频次生成
        summary = defect_library.summary_by_category()
        p.pending_optimizations = [{
            "item": f"优化「{cat}」相关推理策略",
            "priority": "高" if cnt >= 3 else ("中" if cnt >= 2 else "低"),
            "source": f"缺陷库频次={cnt}",
        } for cat, cnt in sorted(summary.items(), key=lambda kv: -kv[1])[:5]]
        self.save()

    def record_iteration(self, entry: Dict[str, Any]) -> None:
        """记录一次框架迭代（补丁应用 / 提案通过等）。"""
        p = self.load()
        entry = dict(entry)
        entry.setdefault("ts", now_iso())
        p.iteration_history.append(entry)
        while len(p.iteration_history) > 100:
            p.iteration_history.pop(0)
        self.save()

    def bump_metrics(self, delta: Dict[str, Any]) -> None:
        """累计运行指标。"""
        p = self.load()
        m = p.self_metrics
        for k, v in delta.items():
            if isinstance(v, (int, float)):
                m[k] = m.get(k, 0) + v
        self.save()

    def bump_strategy_version(self, note: str = "") -> str:
        """策略版本升级（补丁应用后调用）。"""
        p = self.load()
        p.current_strategy_version = f"strategy-{now_iso().replace(':', '').replace('-', '')}"
        if note:
            p.iteration_history.append({"ts": now_iso(), "action": "strategy_bump", "note": note})
        self.save()
        return p.current_strategy_version

    # ------------------------------------------------------------------
    def render_for_prompt(self, max_items: int = 5) -> str:
        """压缩渲染自我档案，注入推理提示词（EISA 读取档案自省）。"""
        p = self.load()
        caps = "；".join(f"{c.get('module')}:{c.get('capability')}"
                         for c in p.framework_capabilities[:max_items])
        defects = "；".join(f"[{d.get('category')}] {str(d.get('description'))[:40]}（频次{d.get('frequency')}）"
                            for d in p.known_defects[:max_items]) or "暂无已知未修复缺陷"
        pending = "；".join(str(o.get("item")) for o in p.pending_optimizations[:max_items]) or "暂无"
        boundaries = "；".join(p.capability_boundaries[:3])
        return (f"[EISA自我档案 v{p.version}｜策略版本 {p.current_strategy_version}] "
                f"框架能力: {caps} | 已知缺陷: {defects} | 待优化: {pending} | 能力边界: {boundaries}")
