# -*- coding: utf-8 -*-
"""用户画像持久化模块。

自动结构化记录：擅长领域、知识短板、提问习惯、回答风格偏好、长期目标、项目上下文。
JSON 本地持久存储；每次对话自动加载，并在对话结束后动态更新。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.core.types import InteractionRecord, Message
from eisa.utils import (append_unique, dc_from, dc_to, ensure_dir, extract_json,
                        get_logger, load_json, now_iso, save_json, top_terms)

logger = get_logger("user_profile")


@dataclass
class UserProfile:
    """单用户画像。"""
    user_id: str = ""
    created_at: str = ""
    updated_at: str = ""
    expertise: Dict[str, int] = field(default_factory=dict)          # 擅长领域 -> 熟练度 1-5
    knowledge_gaps: List[str] = field(default_factory=list)          # 知识短板
    questioning_habits: List[str] = field(default_factory=list)      # 提问习惯
    style_preferences: Dict[str, str] = field(default_factory=dict)  # 回答风格偏好
    long_term_goals: List[str] = field(default_factory=list)         # 长期目标
    project_context: List[str] = field(default_factory=list)         # 项目上下文
    interaction_stats: Dict[str, Any] = field(default_factory=lambda: {"total": 0, "domains": {}})
    notes: List[str] = field(default_factory=list)                   # 其他备注


class UserProfileStore:
    """用户画像仓：加载 / 保存 / 对话后自动增量更新。"""

    def __init__(self, users_dir: Path, base_model):
        self.dir = ensure_dir(users_dir)
        self.base_model = base_model

    # ------------------------------------------------------------------
    def _path(self, user_id: str) -> Path:
        safe = re.sub(r"[^\w\-.]+", "_", user_id).strip("_") or "anonymous"
        return self.dir / f"{safe}.json"

    def load(self, user_id: str) -> UserProfile:
        """加载画像；不存在则创建默认画像并落盘（每次对话自动加载）。"""
        data = load_json(self._path(user_id), None)
        if isinstance(data, dict):
            profile = dc_from(UserProfile, data)
            profile.user_id = user_id
        else:
            profile = UserProfile(user_id=user_id, created_at=now_iso(),
                                  interaction_stats={"total": 0, "domains": {}})
        profile.interaction_stats.setdefault("total", 0)
        profile.interaction_stats.setdefault("domains", {})
        self.save(profile)
        return profile

    def save(self, profile: UserProfile) -> None:
        profile.updated_at = now_iso()
        save_json(self._path(profile.user_id), dc_to(profile))

    # ------------------------------------------------------------------
    async def update_from_interaction(self, profile: UserProfile,
                                      record: InteractionRecord) -> UserProfile:
        """每次对话结束后自动更新画像（启发式信号 + 基座抽取增量，二者合并）。"""
        # 1) 启发式提问习惯信号（零成本，始终执行）
        for h in self._habit_signals(record.query):
            append_unique(profile.questioning_habits, h, cap=15)

        # 2) 基座抽取画像增量
        delta = await self._extract_delta(profile, record)
        self._merge_delta(profile, delta)

        # 3) 交互统计
        stats = profile.interaction_stats
        stats["total"] = int(stats.get("total", 0)) + 1
        domains: Dict[str, int] = stats.setdefault("domains", {})
        key = record.query_type or "未分类"
        domains[key] = int(domains.get(key, 0)) + 1

        self.save(profile)
        return profile

    # ------------------------------------------------------------------
    async def _extract_delta(self, profile: UserProfile,
                             record: InteractionRecord) -> Dict[str, Any]:
        """调用基座抽取画像增量（JSON）。Mock 后端会按字段声明合成占位增量。"""
        known = "、".join(list(profile.expertise.keys())[:8]) or "暂无记录"
        system = "你是用户画像抽取器。根据本轮对话，抽取用户画像增量。"
        user = (
            f"用户已知擅长领域: {known}\n"
            f"用户提问: {record.query[:600]}\n"
            f"EISA 回答摘要: {(record.answer or '')[:300]}\n"
            f"问题类型: {record.query_type}\n"
            "【输出要求】仅输出JSON，字段: expertise_updates, new_weaknesses, "
            "style_preferences, goals, project_context, notes"
        )
        try:
            res = await self.base_model.infer([Message(role="system", content=system),
                                               Message(role="user", content=user)],
                                              temperature=0.3, max_tokens=2048)
            delta = extract_json(res.text)
            return delta if isinstance(delta, dict) else {}
        except Exception as e:
            logger.warning("画像增量抽取失败（跳过本轮增量）: %s", e)
            return {}

    def _merge_delta(self, profile: UserProfile, delta: Dict[str, Any]) -> None:
        """把抽取增量合并进画像（合并策略：领域取最高、列表去重封顶）。"""
        for item in delta.get("expertise_updates") or []:
            if isinstance(item, dict) and item.get("domain"):
                d = str(item["domain"])[:40]
                try:
                    lv = int(item.get("level") or 1)
                except Exception:
                    lv = 1
                profile.expertise[d] = max(profile.expertise.get(d, 0), min(lv, 5))
        for w in delta.get("new_weaknesses") or []:
            if isinstance(w, str):
                append_unique(profile.knowledge_gaps, w[:120], cap=20)
        sp = delta.get("style_preferences")
        if isinstance(sp, dict):
            profile.style_preferences.update({str(k): str(v)[:40] for k, v in sp.items() if v})
        for g in delta.get("goals") or []:
            if isinstance(g, str):
                append_unique(profile.long_term_goals, g[:120], cap=20)
        for c in delta.get("project_context") or []:
            if isinstance(c, str):
                append_unique(profile.project_context, c[:200], cap=30)
        n = delta.get("notes")
        if isinstance(n, str) and n.strip():
            append_unique(profile.notes, n[:200], cap=50)

    # ------------------------------------------------------------------
    @staticmethod
    def _habit_signals(text: str) -> List[str]:
        """零成本启发式：从提问文本推断提问习惯。"""
        signals: List[str] = []
        if len(text) > 300:
            signals.append("长问题描述型")
        if re.search(r"步骤|分步|一步步|firstly|step", text, re.I):
            signals.append("偏好分步说明")
        if re.search(r"```|def |class |import ", text):
            signals.append("常附代码上下文")
        if re.match(r"^\s*(帮我|请|帮我做|给我)", text):
            signals.append("任务委托式提问")
        if re.search(r"为什么|原因|机理|底层", text):
            signals.append("追问原理型")
        if re.search(r"对比|区别|差异|vs|versus", text, re.I):
            signals.append("对比分析型")
        if text.endswith("?") or text.endswith("？"):
            signals.append("疑问句式")
        return signals

    # ------------------------------------------------------------------
    def render_style(self, profile: Optional[UserProfile]) -> str:
        """仅渲染风格偏好（注入分支提示词用）。"""
        if profile is None or not profile.style_preferences:
            return ""
        return "；".join(f"{k}={v}" for k, v in list(profile.style_preferences.items())[:6])

    def render_for_prompt(self, profile: UserProfile) -> str:
        """把画像压缩为可注入提示词的短文本。"""
        if profile is None:
            return "（无用户画像）"
        exp = "、".join(f"{k}(L{v})" for k, v in list(profile.expertise.items())[:6]) or "暂无"
        gaps = "、".join(profile.knowledge_gaps[:5]) or "暂无"
        style = "；".join(f"{k}={v}" for k, v in list(profile.style_preferences.items())[:5]) or "未设定"
        goals = "；".join(profile.long_term_goals[:3]) or "暂无"
        habits = "、".join(profile.questioning_habits[:5]) or "暂无"
        return (f"[用户画像] 擅长领域: {exp} | 知识短板: {gaps} | 提问习惯: {habits} | "
                f"风格偏好: {style} | 长期目标: {goals}")
