# -*- coding: utf-8 -*-
"""EISA 总编排器：串联记忆 → 元调度 → 多分支 → 评判 → 反思 → 进化的完整链路。

主链路（handle_message）：
  1. 加载用户画像 + 对话上下文
  2. 元推理调度：问题分析 → 策略决策 → 领域放大 → 自我档案守卫
  3. 能力扩展 pre_reasoning 钩子
  4. （按需）长程任务规划执行 / 多分支并行推理 + 多层评判
  5. 递归反思修复
  6. 能力扩展 post_reasoning 钩子
  7. 落盘：交互日志、运行轨迹、缺陷入库、画像更新、自我档案指标
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from eisa.config import Config, data_paths, load_config
from eisa.core.backend_registry import build_backend
from eisa.core.base_model import BaseModelMeta, EisaBaseModel
from eisa.core.types import (InteractionRecord, JudgeReport, ReasoningBranch,
                             ReasoningPlan, ReflectionReport)
from eisa.domain.domain_amplifier import DomainAmplifier
from eisa.domain.domain_detector import DomainDetector
from eisa.domain.eval_builder import EvalBuilder
from eisa.evolution.patch_generator import PatchGenerator
from eisa.evolution.proposal_system import ProposalSystem
from eisa.evolution.self_iterate_engine import SelfIterateEngine
from eisa.extensions.loader import ExtensionRunner, load_extensions
from eisa.memory.defect_library import DefectLibrary
from eisa.memory.dialog_store import DialogStore
from eisa.memory.self_profile import SelfProfileStore
from eisa.memory.user_profile import UserProfile, UserProfileStore
from eisa.planning.recursive_reflector import RecursiveReflector
from eisa.planning.task_planner import TaskPlanner, TaskRunResult
from eisa.reasoning.branch_engine import BranchEngine
from eisa.reasoning.budget import BudgetAllocator
from eisa.reasoning.judge import MultiLayerJudge
from eisa.reasoning.meta_scheduler import MetaReasoningScheduler
from eisa.reasoning.paradigm import ParadigmLibrary
from eisa.reasoning.persona_router import PersonaRouter
from eisa.utils import dc_to, ensure_dir, get_logger, new_id, now_iso, save_json

logger = get_logger("orchestrator")


@dataclass
class EisaResult:
    """一次对话的完整结果。"""
    interaction_id: str = ""
    answer: str = ""
    plan: Optional[ReasoningPlan] = None
    branches: List[Dict[str, Any]] = field(default_factory=list)   # 分支摘要
    judge: Optional[JudgeReport] = None
    reflection: Optional[ReflectionReport] = None
    long_task: Optional[TaskRunResult] = None

    def brief(self) -> str:
        """人类可读的调度简报。"""
        lines = [f"◇ 交互ID: {self.interaction_id}"]
        if self.plan:
            b = self.plan.budget
            lines.append(
                f"◇ 元推理: 难度[{self.plan.difficulty}] 类型[{self.plan.query_type}] "
                f"策略[{self.plan.strategy}] 分支[{b.max_branches if b else '-'}] "
                f"反思深度[{self.plan.reflect_depth}]")
            if self.plan.domain_amplified:
                lines.append("◇ 领域放大: 已注入专属思考链 + 专家子路由")
        if self.long_task is not None:
            lines.append(f"◇ 长程任务: 子任务{len(self.long_task.nodes)}个, "
                         f"里程碑复盘{len(self.long_task.reviews)}次, 重规划{self.long_task.replans}次")
        if self.judge:
            lines.append(
                f"◇ 多层评判: 胜出分支[{self.judge.winner_branch_id}] "
                f"置信度[{self.judge.confidence}] 修复轮次[{self.judge.repair_rounds}] "
                f"辩论[{'启用' if self.judge.debate_used else '未启用'}]")
        if self.reflection and self.reflection.issues_found:
            lines.append(f"◇ 递归反思: 发现问题[{len(self.reflection.issues_found)}] "
                         f"已修复[{len(self.reflection.repairs)}]")
        return "\n".join(lines)


class EisaOrchestrator:
    """EISA 总编排器（框架入口）。"""

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)
        self.paths = data_paths(self.cfg)
        # 目录型路径预创建（self_profile.json / defect_library.json 是文件路径，跳过）
        for key in ("root", "users", "dialogs", "domains", "evals",
                    "patches", "proposals", "reports", "runs"):
            ensure_dir(self.paths[key])

        # ---- 基座与后端 ----
        self.backend = build_backend(self.cfg)
        self.base_model = EisaBaseModel(self.backend, BaseModelMeta(
            name=self.cfg.get("base_model.name"),
            params_total=self.cfg.get("base_model.params_total"),
            context_window=self.cfg.get("base_model.context_window"),
            backend_name=self.backend.name))

        # ---- 推理层 ----
        self.paradigm_lib = ParadigmLibrary.from_config()
        self.persona_router = PersonaRouter()
        self.budget_allocator = BudgetAllocator(self.cfg)
        self.branch_engine = BranchEngine(self.base_model, self.paradigm_lib,
                                          self.persona_router, self.cfg)
        self.judge = MultiLayerJudge(self.base_model, self.branch_engine, self.cfg)
        self.scheduler = MetaReasoningScheduler(
            self.base_model, self.paradigm_lib, self.budget_allocator, self.cfg)

        # ---- 规划层 ----
        self.reflector = RecursiveReflector(self.base_model, self.cfg)
        self.planner = TaskPlanner(self.base_model, self.cfg)

        # ---- 领域层 ----
        self.domain_detector = DomainDetector(self.base_model, self.cfg)
        self.domain_amplifier = DomainAmplifier(self.base_model, self.paths["domains"], self.cfg)
        self.eval_builder = EvalBuilder(self.base_model, self.paths["evals"], self.cfg)

        # ---- 记忆层 ----
        self.user_profiles = UserProfileStore(self.paths["users"], self.base_model)
        self.self_profile = SelfProfileStore(self.paths["self_profile"])
        self.dialogs = DialogStore(self.paths["dialogs"])
        self.defects = DefectLibrary(self.paths["defects"])

        # ---- 进化层 ----
        self.patch_gen = PatchGenerator(self.base_model, self.paths["patches"])
        self.iterate = SelfIterateEngine(
            self.cfg, self.paths["patches"], self.user_profiles, self.defects,
            self.self_profile, self.paths["evals"], self.paths["reports"])
        self.iterate.set_backend(self.base_model)
        self.iterate.set_dialogs(self.dialogs)
        self.proposals = ProposalSystem(self.base_model, self.paths["proposals"],
                                        self.defects, self.self_profile)

        # ---- 能力扩展 ----
        self.extensions = ExtensionRunner(load_extensions())

        logger.info("EISA 编排器就绪: backend=%s | 数据目录=%s | 范式=%d个 | 已注册扩展=%d",
                    self.backend.name, self.paths["root"], len(self.paradigm_lib.all_ids()),
                    len(self.extensions.capabilities))

    # ==================================================================
    # 主入口：单轮对话
    # ==================================================================
    async def handle_message(self, user_id: str, text: str) -> EisaResult:
        if not text or not text.strip():
            raise ValueError("输入不能为空")
        interaction_id = new_id("it")

        # 1. 记忆加载
        profile = self.user_profiles.load(user_id)
        dialog_ctx = self.dialogs.dialog_brief(user_id, n=self.cfg.get("memory.max_dialog_context", 5))

        # 2. 元推理调度
        analysis = await self.scheduler.analyze_query(text, profile, dialog_ctx)
        domain_info = await self.domain_detector.detect(profile, [text])
        domain_info["candidates"] = domain_info.get("candidates") or []
        pack = None
        strong_lv = self.cfg.get("domain.strong_level_threshold", 3)
        if domain_info.get("primary_domain") and domain_info.get("top_level", 0) >= strong_lv:
            pack = await self.domain_amplifier.ensure_pack(domain_info["primary_domain"])
        plan = self.scheduler.decide_plan(analysis, pack)
        if pack is not None:
            plan = self.domain_amplifier.amplify_plan(plan, pack)

        ctx = {"question": text, "plan": plan, "user_id": user_id}
        ctx = self.extensions.run_pre_reasoning(ctx)
        plan = ctx.get("plan", plan)

        # 3. 推理执行
        if plan.requires_planning:
            task_result = await self.run_long_task(user_id, text, plan=plan)
            result = EisaResult(
                interaction_id=interaction_id, answer=task_result.final_answer,
                plan=plan, long_task=task_result,
                reflection=await self.reflector.reflect(
                    text, task_result.final_answer, depth=min(plan.reflect_depth, 2)),
            )
            result.answer = result.reflection.final_answer
        else:
            answer, judge, reflection, branches = await self._reasoning_core(
                text, profile, plan, pack, dialog_ctx)
            result = EisaResult(interaction_id=interaction_id, answer=answer, plan=plan,
                                judge=judge, reflection=reflection,
                                branches=[self._branch_summary(b) for b in branches])

        # 4. 能力扩展 post_reasoning
        self.extensions.run_post_reasoning(ctx, result)

        # 5. 落盘与画像更新
        await self._persist(user_id, text, result, analysis)

        # 6. 领域画像回写
        self.user_profiles.save(profile)
        return result

    # ==================================================================
    # 推理内核：多分支 + 多层评判 + 递归反思
    # ==================================================================
    async def _reasoning_core(self, question: str,
                              profile: Optional[UserProfile],
                              plan: ReasoningPlan,
                              pack=None,
                              dialog_ctx: str = "",
                              save_trace: bool = True,
                              ) -> Tuple[str, Optional[JudgeReport], ReflectionReport,
                                         List[ReasoningBranch]]:
        style = self.user_profiles.render_style(profile) if profile else ""
        branches = await self.branch_engine.spawn(question, plan, dialog_ctx,
                                                  domain_pack=pack, user_style=style)
        judge_report = await self.judge.evaluate(question, branches, plan, dialog_ctx)

        if plan.reflect_depth > 0:
            reflection = await self.reflector.reflect(
                question, judge_report.final_answer,
                context_note=self.self_profile.render_for_prompt(max_items=3),
                depth=plan.reflect_depth)
        else:
            reflection = ReflectionReport(final_answer=judge_report.final_answer,
                                          confidence=judge_report.confidence)
        answer = reflection.final_answer

        if save_trace:
            save_json(self.paths["runs"] / f"{plan.plan_id}.json", {
                "ts": now_iso(), "question": question,
                "plan": dc_to(plan),
                "branches": [self._branch_summary(b) for b in branches],
                "judge": dc_to(judge_report),
                "reflection": dc_to(reflection),
                "answer": answer,
            })
        return answer, judge_report, reflection, branches

    # ==================================================================
    # 长程任务入口
    # ==================================================================
    async def run_long_task(self, user_id: str, goal: str,
                            plan: Optional[ReasoningPlan] = None) -> TaskRunResult:
        """长程任务：拆解 → 任务栈执行 → 里程碑复盘 → 失败重规划 → 合成。"""
        profile = self.user_profiles.load(user_id)
        if plan is None:
            analysis = await self.scheduler.analyze_query(goal, profile, "")
            plan = self.scheduler.decide_plan(analysis, None)
            plan.requires_planning = True

        async def executor(sub_goal: str) -> Tuple[str, bool, Dict[str, Any]]:
            sub_plan = plan if plan.requires_planning else None
            answer, jr, _ = await self._reasoning_core(sub_goal, profile, sub_plan, None, "",
                                                       save_trace=False)
            conf = jr.confidence if jr else 8.0
            threshold = float(self.cfg.get("judge.score_threshold", 7.0)) * 0.5
            return answer, conf >= threshold, {"confidence": conf}

        result = await self.planner.execute(goal, executor)

        # 失败样例入缺陷库
        failed = [n for n in result.nodes if n.status == "failed"]
        for n in failed:
            self.defects.add("规划失败", f"子任务失败: {n.goal[:80]}",
                             trigger_context=goal[:200], severity="中",
                             related_ids=[n.task_id])
        if failed:
            self.self_profile.sync_defects(self.defects)
        return result

    # ==================================================================
    # 无副作用推理（评测/子任务复用）
    # ==================================================================
    async def answer_only(self, question: str) -> Tuple[str, Optional[JudgeReport], ReflectionReport]:
        """纯推理：不写画像/日志（供评测集与长程子任务复用）。"""
        analysis = await self.scheduler.analyze_query(question, None, "")
        plan = self.scheduler.decide_plan(analysis, None, None, self.self_profile)
        answer, judge, reflection, _ = await self._reasoning_core(
            question, None, plan, None, "", save_trace=False)
        return answer, judge, reflection

    # ==================================================================
    # 自迭代与提案入口
    # ==================================================================
    async def analyze_and_propose(self) -> Dict[str, Any]:
        """短板分析 → 补丁提案 + 能力提案（全部待人工审核，绝不自动应用）。"""
        patches = await self.iterate.propose_patches(
            limit=int(self.cfg.get("evolution.max_patches_per_run", 3)))
        props = await self.proposals.brainstorm(
            n=int(self.cfg.get("evolution.max_proposals_per_run", 2)))
        self.self_profile.sync_defects(self.defects)
        return {
            "pending_patches": [{"patch_id": p.patch_id, "kind": p.kind,
                                 "target_file": p.target_file,
                                 "risk_level": p.risk_level,
                                 "description": p.description} for p in patches],
            "pending_proposals": [{"proposal_id": p.proposal_id, "name": p.name,
                                   "module_name": p.module_name} for p in props],
        }

    # ==================================================================
    # 内部工具
    # ==================================================================
    @staticmethod
    def _branch_summary(b: ReasoningBranch) -> Dict[str, Any]:
        return {"branch_id": b.branch_id, "paradigm": b.paradigm, "persona": b.persona,
                "temperature": b.temperature, "aggregate": b.aggregate,
                "conclusion": b.conclusion[:150], "status": b.status,
                "repaired": b.repaired}

    async def _persist(self, user_id: str, text: str, result: EisaResult,
                       analysis) -> None:
        """交互落盘：日志、缺陷、画像、自我档案指标。"""
        judge = result.judge
        conf = judge.confidence if judge else (
            result.reflection.confidence if result.reflection else 8.0)
        has_high_issue = bool(result.reflection and
                              any(i.get("severity") == "高" for i in result.reflection.issues_found))
        record = InteractionRecord(
            interaction_id=result.interaction_id, ts=now_iso(), user_id=user_id,
            query=text[:500], answer=result.answer[:2000],
            strategy=result.plan.strategy if result.plan else "long_task",
            difficulty=analysis.difficulty, query_type=analysis.query_type,
            winner_branch_id=judge.winner_branch_id if judge else "",
            score=judge.confidence if judge else None,
            confidence=conf,
            defect_categories=[d["category"] for d in (judge.defects if judge else [])],
            success=bool(conf >= 6.5 and not has_high_issue),
            failure_reason="" if conf >= 6.5 else f"低置信度 {conf}",
            meta={"domain_amplified": bool(result.plan and result.plan.domain_amplified)},
        )
        self.dialogs.append(record)

        # 缺陷入库 + 自我档案同步
        if judge and judge.defects:
            for d in judge.defects:
                self.defects.add(**d)
            self.self_profile.sync_defects(self.defects)

        # 用户画像动态更新
        if self.cfg.get("memory.profile_update_enabled", True):
            try:
                await self.user_profiles.update_from_interaction(
                    self.user_profiles.load(user_id), record)
            except Exception as e:
                logger.warning("画像更新失败（忽略）: %s", e)

        # 自我档案指标
        self.self_profile.bump_metrics({
            "total_interactions": 1,
            "total_branches": len(result.branches) if result.branches else 0,
            "sum_confidence": float(conf),
        })
