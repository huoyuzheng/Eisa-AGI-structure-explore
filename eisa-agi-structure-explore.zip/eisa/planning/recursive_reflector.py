# -*- coding: utf-8 -*-
"""递归反思器：分层自省 + 递归修复链路。

反思层由浅入深：事实层 → 逻辑层 → 假设层 → 边界层 → 目标层。
每层扫描问题；发现问题即修复答案，再带着修复后的答案进入下一层，
形成「递归检查推理漏洞」的链路。深度由元调度器的预算控制。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import Message, ReflectionReport
from eisa.utils import extract_json, get_logger, truncate

logger = get_logger("reflector")


class RecursiveReflector:
    """分层递归反思与修复。"""

    def __init__(self, base_model: EisaBaseModel, cfg: Config):
        self.base_model = base_model
        self.cfg = cfg

    # ------------------------------------------------------------------
    async def _scan(self, layer_id: str, layer_name: str, layer_hint: str,
                    question: str, answer: str) -> List[Dict[str, Any]]:
        """单层扫描：找该层漏洞。"""
        system = f"你是 EISA 递归反思器的{layer_name}审查员。仅输出JSON。"
        user = (
            f"审查维度: {layer_hint}\n"
            f"问题: {truncate(question, 400)}\n"
            f"待审答案:\n{truncate(answer, 2000)}\n"
            "请找出该维度的问题（无问题则返回空列表）。\n"
            "【输出要求】仅输出JSON，字段: issues, layer_confidence"
        )
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.3, max_tokens=2048)
            data = extract_json(out.text) or {}
            items = data.get("issues") or []
            if isinstance(items, dict):
                items = [items]
            result = []
            for it in items:
                if isinstance(it, dict):
                    result.append({
                        "layer": layer_id,
                        "description": str(it.get("description", it.get("text", "未描述问题")))[:200],
                        "severity": str(it.get("severity", "中")),
                    })
                elif isinstance(it, str):
                    result.append({"layer": layer_id, "description": it[:200], "severity": "中"})
            return result
        except Exception as e:
            logger.warning("反思扫描失败（跳过该层）: %s", e)
            return []

    async def _repair(self, layer_id: str, layer_name: str, question: str,
                      answer: str, issues: List[Dict[str, Any]]) -> str:
        """单层修复：按问题清单重写答案。"""
        issue_lines = "\n".join(f"- [{i.get('severity')}] {i.get('description')}" for i in issues)
        system = f"你是 EISA 反思修复器（{layer_name}）：修复答案中的问题，保持其余内容与整体结构。"
        user = (
            f"问题: {truncate(question, 400)}\n当前答案:\n{truncate(answer, 2500)}\n"
            f"需修复的问题:\n{issue_lines}\n\n请输出修复后的完整答案（保留【结论】行）。"
        )
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.4, max_tokens=8192)
            fixed = out.text.strip()
            return fixed if fixed else answer
        except Exception as e:
            logger.warning("反思修复失败（保留原答案）: %s", e)
            return answer

    # ------------------------------------------------------------------
    async def reflect(self, question: str, answer: str, depth: int = 2,
                      context_note: str = "") -> ReflectionReport:
        """逐层递归反思；depth<=0 时跳过（简单问题直通）。"""
        from eisa.core.types import REFLECTION_LAYERS
        report = ReflectionReport(final_answer=answer)
        if depth <= 0:
            return report

        layers = REFLECTION_LAYERS[:max(1, min(depth, len(REFLECTION_LAYERS)))]
        current = answer
        for layer_id, layer_name, layer_hint in layers:
            report.layers_checked.append(layer_id)
            issues = await self._scan(layer_id, layer_name, layer_hint, question, current)
            if not issues:
                logger.debug("反思层[%s] 无问题", layer_name)
                continue
            report.issues_found.extend(issues)
            high = [i for i in issues if i.get("severity") == "高"]
            fixed = await self._repair(layer_id, layer_name, question, current, issues)
            report.repairs.append({
                "layer": layer_id,
                "n_issues": len(issues),
                "n_high": len(high),
                "changed": fixed != current,
                "summary": issues[0].get("description", ""),
            })
            current = fixed
            logger.info("反思层[%s]: 发现 %d 个问题（高危 %d），已修复", layer_name, len(issues), len(high))

        report.final_answer = current
        report.confidence = round(max(5.0, 9.5 - 0.4 * len(report.issues_found)
                                      - 0.6 * sum(1 for i in report.issues_found
                                                  if i.get("severity") == "高")), 1)
        return report
