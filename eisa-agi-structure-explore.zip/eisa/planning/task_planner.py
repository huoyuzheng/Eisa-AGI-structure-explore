# -*- coding: utf-8 -*-
"""长程任务规划器：自动拆解子目标、维护任务栈、阶段性复盘校验、失败重规划。

执行模型：
  goal -> decompose 拆解为 DAG 子任务 -> 逐个就绪任务执行（复用推理内核）
      -> 每个任务完成后做里程碑复盘 -> 失败则重规划补充子任务 -> 全部完成后合成终稿
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import Message, TaskNode
from eisa.utils import dc_to, extract_json, get_logger, new_id, now_iso, truncate

logger = get_logger("planner")

ExecutorFn = Callable[[str], Awaitable[Tuple[str, bool, Dict[str, Any]]]]


@dataclass
class TaskRunResult:
    """一次长程任务的运行结果。"""
    goal: str = ""
    final_answer: str = ""
    nodes: List[TaskNode] = field(default_factory=list)
    reviews: List[Dict[str, Any]] = field(default_factory=list)
    replans: int = 0
    started_at: str = ""
    finished_at: str = ""

    def tree_text(self) -> str:
        lines = [f"目标: {self.goal}"]
        for n in self.nodes:
            mark = {"done": "✔", "failed": "✘", "pending": "…", "running": "⏳"}.get(n.status, "?")
            lines.append(f"  {mark} {n.task_id} {n.goal[:60]} -> {n.status}")
        return "\n".join(lines)


class TaskPlanner:
    """长程任务规划与执行。"""

    def __init__(self, base_model: EisaBaseModel, cfg: Config):
        self.base_model = base_model
        self.cfg = cfg

    # ------------------------------------------------------------------
    async def decompose(self, goal: str, context_note: str = "") -> List[TaskNode]:
        """把目标拆解为子任务 DAG。"""
        max_sub = int(self.cfg.get("planner.max_subtasks", 8))
        system = "你是 EISA 长程任务规划器：把目标拆解为可独立执行、带依赖关系的子任务。仅输出JSON。"
        user = (
            f"总目标: {goal}\n"
            f"{('上下文: ' + context_note) if context_note else ''}\n"
            f"最多 {max_sub} 个子任务；depends_on 引用其他子任务 id。\n"
            "【输出要求】仅输出JSON，字段: subtasks"
        )
        nodes: List[TaskNode] = []
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.3, max_tokens=4096)
            data = extract_json(out.text) or {}
            items = data.get("subtasks") or []
            valid_ids = set()
            for it in items[:max_sub]:
                if not isinstance(it, dict) or not it.get("goal"):
                    continue
                tid = str(it.get("id") or f"t{len(nodes) + 1}")
                deps = [d for d in (it.get("depends_on") or []) if d in valid_ids]
                nodes.append(TaskNode(task_id=tid, goal=str(it["goal"])[:300],
                                      hints=str(it.get("hints", ""))[:200],
                                      depends_on=deps))
                valid_ids.add(tid)
        except Exception as e:
            logger.warning("任务拆解失败，退化为单任务: %s", e)
        if not nodes:
            nodes = [TaskNode(task_id="t1", goal=goal)]
        # 规范化 id
        for i, n in enumerate(nodes):
            n.task_id = n.task_id or f"t{i + 1}"
        logger.info("任务拆解完成: %d 个子任务", len(nodes))
        return nodes

    # ------------------------------------------------------------------
    async def _review(self, node: TaskNode, goal: str) -> Dict[str, Any]:
        """里程碑复盘：阶段性校验子任务产出。"""
        system = "你是 EISA 里程碑复盘器：校验子任务产出是否达标。仅输出JSON。"
        user = (
            f"总目标: {truncate(goal, 200)}\n子任务 {node.task_id}: {node.goal}\n"
            f"产出: {truncate(node.result, 800)}\n"
            "【输出要求】仅输出JSON，字段: pass, issues, suggestions"
        )
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.2, max_tokens=2048)
            data = extract_json(out.text) or {}
            return {"pass": bool(data.get("pass", True)),
                    "issues": data.get("issues") or [],
                    "suggestions": data.get("suggestions") or []}
        except Exception as e:
            logger.warning("里程碑复盘失败（视为通过）: %s", e)
            return {"pass": True, "issues": [], "suggestions": []}

    async def _replan(self, failed: TaskNode, goal: str) -> List[TaskNode]:
        """失败重规划：为未竟目标生成补救子任务。"""
        system = "你是 EISA 重规划器：针对失败子任务生成补救子任务。仅输出JSON。"
        user = (
            f"总目标: {truncate(goal, 200)}\n"
            f"失败子任务: {failed.goal}\n失败原因/产出: {truncate(failed.result, 400)}\n"
            "【输出要求】仅输出JSON，字段: subtasks"
        )
        nodes: List[TaskNode] = []
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.4, max_tokens=3000)
            data = extract_json(out.text) or {}
            for it in (data.get("subtasks") or [])[:4]:
                if isinstance(it, dict) and it.get("goal"):
                    nodes.append(TaskNode(task_id=f"r{len(nodes) + 1}",
                                          goal=str(it["goal"])[:300],
                                          hints=str(it.get("hints", ""))[:200]))
        except Exception as e:
            logger.warning("重规划失败: %s", e)
        return nodes

    async def _synthesize(self, goal: str, done_nodes: List[TaskNode]) -> str:
        """全部子任务完成后合成终稿。"""
        parts = "\n".join(f"[{n.task_id}] {n.goal}\n{truncate(n.result, 500)}"
                          for n in done_nodes[:12])
        system = "你是 EISA 长程任务终稿撰写者：整合所有子任务产出，输出面向最终目标的完整答案。"
        user = (
            f"总目标: {goal}\n各子任务产出:\n{parts}\n\n"
            "请输出结构完整、前后一致的最终答案；最后一行以【结论】开头给出总结论。"
        )
        out = await self.base_model.infer(
            [Message(role="system", content=system), Message(role="user", content=user)],
            temperature=0.5, max_tokens=16384)
        return out.text

    # ------------------------------------------------------------------
    async def execute(self, goal: str, executor: ExecutorFn,
                      context_note: str = "") -> TaskRunResult:
        """执行长程任务主循环。"""
        result = TaskRunResult(goal=goal, started_at=now_iso())
        nodes = await self.decompose(goal, context_note)
        max_replans = int(self.cfg.get("planner.max_replans", 2))
        review_enabled = bool(self.cfg.get("planner.milestone_review", True))
        replans = 0
        guard = 0

        while guard < 64:
            guard += 1
            done_ids = {n.task_id for n in nodes if n.status == "done"}
            ready = [n for n in nodes if n.status == "pending"
                     and all(d in done_ids for d in n.depends_on)]
            pending = [n for n in nodes if n.status == "pending"]
            if not ready:
                if not pending:
                    break
                ready = [pending[0]]  # 依赖死锁兜底

            for node in ready:
                node.status = "running"
                logger.info("执行子任务 %s: %s", node.task_id, node.goal[:60])
                try:
                    text, ok, meta = await executor(node.goal)
                except Exception as e:
                    text, ok, meta = f"执行异常: {e}", False, {}
                node.result = text
                if review_enabled:
                    review = await self._review(node, goal)
                    result.reviews.append({"task_id": node.task_id, **review})
                    # 复盘通过与执行器置信度取『或』：单点否决不阻断长链路，
                    # 复盘意见始终记录在 reviews 中供递归反思与人工审计。
                    ok = bool(ok or review.get("pass"))
                node.status = "done" if ok else "failed"
                if node.status == "failed" and replans < max_replans:
                    replans += 1
                    result.replans = replans
                    extra = await self._replan(node, goal)
                    for n in extra:
                        nodes.append(n)
                    logger.warning("子任务 %s 失败 → 已补充 %d 个补救子任务",
                                   node.task_id, len(extra))

        done_nodes = [n for n in nodes if n.status == "done"]
        result.nodes = nodes
        result.replans = replans
        result.final_answer = await self._synthesize(goal, done_nodes) if done_nodes else "（无可完成任务）"
        result.finished_at = now_iso()
        logger.info("长程任务完成: 子任务 %d/%d 成功, 重规划 %d 次",
                    len(done_nodes), len(nodes), replans)
        return result
