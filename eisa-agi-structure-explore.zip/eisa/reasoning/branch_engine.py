# -*- coding: utf-8 -*-
"""多分支并行推理引擎（性能放大核心之一）。

同一个问题生成 N 条『人格 × 范式 × 温度』三重差异化的并行思考分支，
交由多层自省评判器择优。分支失败样例会流入缺陷库，供自迭代引擎复盘。
"""
from __future__ import annotations

import asyncio
import re
from typing import Any, Dict, List, Optional, Tuple

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import DomainPack, Message, ReasoningBranch, ReasoningPlan
from eisa.reasoning.paradigm import ParadigmLibrary
from eisa.reasoning.persona_router import PersonaRouter
from eisa.utils import dc_to, get_logger, hash_seed

logger = get_logger("branch")

CONCLUSION_RE = re.compile(r"【结论】[:：]?\s*(.+)")


def extract_conclusion(text: str) -> str:
    """从分支输出中提取【结论】行（供交叉评审摘要与终审使用）。"""
    m = CONCLUSION_RE.search(text or "")
    if m:
        return m.group(1).strip()
    lines = [l for l in (text or "").splitlines() if l.strip()]
    return lines[-1][:200] if lines else ""


class BranchEngine:
    """并行分支生成器。"""

    def __init__(self, base_model: EisaBaseModel, paradigm_lib: ParadigmLibrary,
                 persona_router: PersonaRouter, cfg: Config):
        self.base_model = base_model
        self.paradigm_lib = paradigm_lib
        self.persona_router = persona_router
        self.cfg = cfg

    # ------------------------------------------------------------------
    def build_specs(self, question: str, plan: ReasoningPlan,
                    domain_pack: Optional[DomainPack] = None,
                    user_style: str = "") -> List[Dict[str, Any]]:
        """构造 n 条分支规格：范式 + 人格 + 温度 + 附加指令。"""
        n = plan.budget.max_branches if plan.budget else 2
        paradigms = plan.paradigms or self.paradigm_lib.pick_for(plan.query_type, n)
        seed = hash_seed(question) % 9973
        personas = self.persona_router.select(n, domain_pack=domain_pack, seed=seed)
        temps = list(self.cfg.get("reasoning.branch_temperatures", [0.3, 0.5, 0.7, 0.85, 1.0]))

        specs: List[Dict[str, Any]] = []
        for i in range(n):
            pid = paradigms[i % len(paradigms)]
            persona = personas[i % len(personas)]
            extra = ""
            # 极难任务：末位分支专职魔鬼代言人式攻击
            if plan.difficulty == "极难" and i == n - 1:
                extra = "【附加指令】请额外构造一个试图推翻你自己结论的反例，并说明结论是否仍然成立。"
            specs.append({
                "branch_id": f"b{i + 1}",
                "paradigm_id": pid,
                "persona": persona,
                "temperature": round(temps[i % len(temps)], 2),
                "extra_hint": extra,
            })
        return specs

    def _build_messages(self, question: str, spec: Dict[str, Any],
                        domain_chain: List[str], user_style: str,
                        critiques: Optional[List[str]] = None,
                        context_note: str = "") -> List[Message]:
        """组装分支对话。"""
        p = self.paradigm_lib.get(spec["paradigm_id"])
        p_name = p.name if p else spec["paradigm_id"]
        p_hint = p.hint if p else ""
        persona = spec["persona"]
        system = (
            f"你是 EISA 框架中的一条并行思考分支。\n"
            f"【人格】{persona.name}：{persona.style}\n"
            f"（需规避偏误：{'；'.join(persona.guard) or '无'}）\n"
            f"【推理范式】{p_name}：{p_hint}"
        )
        user_parts = [f"问题：{question}"]
        if context_note:
            user_parts.append(f"【上下文】{context_note}")
        if domain_chain:
            steps = "\n".join(f"{i + 1}. {s}" for i, s in enumerate(domain_chain))
            user_parts.append(f"【领域专属思考链】\n{steps}")
        if user_style:
            user_parts.append(f"【用户偏好】{user_style}")
        if spec.get("extra_hint"):
            user_parts.append(spec["extra_hint"])
        if critiques:
            review = "\n".join(f"- {c}" for c in critiques)
            user_parts.append(f"【评审指出的你的问题】\n{review}\n请据此修正并重新作答。")
        user_parts.append("【回答要求】给出完整推理过程；最后一行以【结论】开头给出最终答案。")
        return [Message(role="system", content=system),
                Message(role="user", content="\n\n".join(user_parts))]

    # ------------------------------------------------------------------
    async def spawn(self, question: str, plan: ReasoningPlan,
                    context_note: str = "",
                    domain_pack: Optional[DomainPack] = None,
                    user_style: str = "") -> List[ReasoningBranch]:
        """并行生成全部分支（异步扇出，信号量控制并发）。"""
        specs = self.build_specs(question, plan, domain_pack=domain_pack, user_style=user_style)
        sem = asyncio.Semaphore(max(1, plan.budget.concurrency if plan.budget else 8))
        max_tokens = plan.budget.tokens_per_branch if plan.budget else 8192

        async def run_one(spec: Dict[str, Any]) -> Tuple[Dict[str, Any], str]:
            msgs = self._build_messages(question, spec, plan.domain_chain, user_style,
                                        context_note=context_note)
            async with sem:
                res = await self.base_model.infer(msgs, temperature=spec["temperature"],
                                                  max_tokens=max_tokens)
            return spec, res.text

        outs = await asyncio.gather(*[run_one(s) for s in specs])
        branches: List[ReasoningBranch] = []
        for spec, text in outs:
            branches.append(ReasoningBranch(
                branch_id=spec["branch_id"],
                paradigm=spec["paradigm_id"],
                persona=spec["persona"].id,
                temperature=spec["temperature"],
                answer=text,
                conclusion=extract_conclusion(text),
                trace=[{"role": m.role, "content": m.content} for m in
                       self._build_messages(question, spec, plan.domain_chain, user_style)],
                status="ok",
            ))
        logger.info("分支生成完成: %d 条（策略=%s 难度=%s）",
                    len(branches), plan.strategy, plan.difficulty)
        return branches

    # ------------------------------------------------------------------
    async def regenerate(self, branch: ReasoningBranch, question: str, plan: ReasoningPlan,
                         critiques: List[str], domain_pack: Optional[DomainPack] = None,
                         user_style: str = "") -> ReasoningBranch:
        """回溯纠错：按评审意见重生成单条分支。"""
        spec = {
            "branch_id": branch.branch_id,
            "paradigm_id": branch.paradigm,
            "persona": self.persona_router.select(1, None, seed=hash_seed(branch.branch_id))[0],
            "temperature": max(0.2, branch.temperature - 0.2),
            "extra_hint": "",
        }
        msgs = self._build_messages(question, spec, plan.domain_chain, user_style,
                                    critiques=critiques)
        res = await self.base_model.infer(msgs, temperature=spec["temperature"],
                                          max_tokens=plan.budget.tokens_per_branch if plan.budget else 8192)
        branch.answer = res.text
        branch.conclusion = extract_conclusion(res.text)
        branch.trace.append({"role": "user", "content": "(评审修复)" + "\n".join(critiques)})
        branch.trace.append({"role": "assistant", "content": res.text})
        branch.repaired = True
        branch.status = "regenerated"
        return branch
