# -*- coding: utf-8 -*-
"""思考预算动态分配器。

按问题难度/类型/领域放大因子动态分配：分支数、每分支 token 预算、
评判轮次、反思深度、辩论轮次。unlimited_mode 开启后整体预算加倍放大 ——
本框架不受现实算力约束，预算只是调度层的相对量。
"""
from __future__ import annotations

from typing import Optional

from eisa.config import Config
from eisa.core.types import Budget, DomainPack
from eisa.utils import get_logger

logger = get_logger("budget")


class BudgetAllocator:
    """难度 -> 预算基线表 + 领域放大 + 无限模式放大。"""

    # 难度基线：分支数 / 每分支 token / 评判轮次 / 反思深度 / 辩论轮次
    TABLE = {
        "简单": {"max_branches": 1, "tokens_per_branch": 2048, "judge_rounds": 1, "reflect_depth": 0, "debate_rounds": 0},
        "中等": {"max_branches": 2, "tokens_per_branch": 8192, "judge_rounds": 1, "reflect_depth": 1, "debate_rounds": 0},
        "困难": {"max_branches": 4, "tokens_per_branch": 32768, "judge_rounds": 2, "reflect_depth": 2, "debate_rounds": 1},
        "极难": {"max_branches": 8, "tokens_per_branch": 131072, "judge_rounds": 3, "reflect_depth": 3, "debate_rounds": 2},
    }

    def __init__(self, cfg: Config):
        self.cfg = cfg

    def allocate(self, difficulty: str, query_type: str,
                 domain_pack: Optional[DomainPack] = None,
                 unlimited: Optional[bool] = None) -> Budget:
        """生成一次推理的思考预算。"""
        base = dict(self.TABLE.get(difficulty, self.TABLE["中等"]))
        if unlimited is None:
            unlimited = bool(self.cfg.get("reasoning.unlimited_mode", True))

        # 领域放大：深耕领域的分支数加成 + token 放大
        if domain_pack is not None:
            base["max_branches"] = int(base["max_branches"]) + int(domain_pack.branch_bonus or 0)
            base["tokens_per_branch"] = int(base["tokens_per_branch"] * 1.5)

        # 无限模式：框架级预算整体加倍（架构探索定位，不受现实算力约束）
        if unlimited:
            base["max_branches"] = int(base["max_branches"]) * 2
            base["tokens_per_branch"] = int(base["tokens_per_branch"]) * 4
            base["judge_rounds"] = max(int(base["judge_rounds"]), 3)
            base["reflect_depth"] = max(int(base["reflect_depth"]), 3)
            base["debate_rounds"] = max(int(base["debate_rounds"]), 2)

        budget = Budget(
            max_branches=min(int(base["max_branches"]), 64),
            tokens_per_branch=int(base["tokens_per_branch"]),
            judge_rounds=int(base["judge_rounds"]),
            reflect_depth=int(base["reflect_depth"]),
            debate_rounds=int(base["debate_rounds"]),
            concurrency=int(self.cfg.get("reasoning.default_concurrency", 8)),
            unlimited=bool(unlimited),
        )
        logger.debug("预算分配: 难度=%s 类型=%s -> %s", difficulty, query_type, budget)
        return budget
