# -*- coding: utf-8 -*-
"""多层自省评判器（性能放大核心之二）。

四层评判链路：
  L1 独立评分   —— 按六维评分表对每条分支独立打分
  L2 交叉互评   —— 每条分支接受针对『其他分支』视角的审查，产出扣分项
  L3 矛盾排查   —— 全分支结论交叉比对，定位两两冲突
  L4 终审裁决   —— 汇总排名选出胜者；不足则触发回溯纠错（重生成最弱分支）
可选对抗机制：终局辩论（top2 分支多轮辩论后终审）。

失败样例（低置信度、矛盾、失败分支）会随报告流入缺陷库。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import (JUDGE_DIMENSIONS, JudgeReport, Message,
                             ReasoningBranch, ReasoningPlan)
from eisa.reasoning.branch_engine import BranchEngine
from eisa.utils import extract_json, get_logger, truncate

logger = get_logger("judge")

_SEVERITY_PENALTY = {"高": 1.5, "中": 1.0, "低": 0.5}


class MultiLayerJudge:
    """多层自省评判器。"""

    def __init__(self, base_model: EisaBaseModel, branch_engine: BranchEngine, cfg: Config):
        self.base_model = base_model
        self.engine = branch_engine
        self.cfg = cfg

    # ------------------------------------------------------------------
    @property
    def weights(self) -> Dict[str, float]:
        return dict(self.cfg.get("judge.weights") or {})

    @property
    def score_threshold(self) -> float:
        return float(self.cfg.get("judge.score_threshold", 7.0))

    # ------------------------------------------------------------------
    async def evaluate(self, question: str, branches: List[ReasoningBranch],
                       plan: ReasoningPlan, context_note: str = "") -> JudgeReport:
        """执行完整多层评判，返回裁决报告。"""
        report = JudgeReport()

        # L1 独立评分
        await self._independent_scores(branches)
        # L2 交叉互评
        await self._cross_reviews(question, branches)
        # L3 矛盾排查
        report.contradictions = await self._contradiction_scan(question, branches)
        # 汇总扣分
        self._aggregate(branches, report.contradictions)

        # L4 终审 + 回溯纠错循环
        max_rounds = max(1, min(plan.budget.judge_rounds if plan.budget else 1,
                                int(self.cfg.get("judge.repair_max_rounds", 2))))
        verdict, winner = await self._arbitrate(question, branches)
        report.verdict_rationale = verdict.get("rationale", "")

        repair_rounds = 0
        while (winner.aggregate < self.score_threshold or
               str(verdict.get("needs_repair", "")).lower() in ("true", "1", "yes")) \
                and repair_rounds < max_rounds and len(branches) > 1:
            weakest = min(branches, key=lambda b: b.aggregate)
            critiques = weakest.critiques or ["推理深度不足，结论依据薄弱，请补全论证链"]
            logger.info("回溯纠错: 重生成最弱分支 %s（第 %d 轮）", weakest.branch_id, repair_rounds + 1)
            weakest = await self.engine.regenerate(weakest, question, plan, critiques)
            await self._independent_scores([weakest])
            self._aggregate([weakest], report.contradictions)
            verdict, winner = await self._arbitrate(question, branches)
            report.verdict_rationale = verdict.get("rationale", report.verdict_rationale)
            repair_rounds += 1
        report.repair_rounds = repair_rounds

        # 终局辩论（top2 接近时启用）
        if plan.budget and plan.budget.debate_rounds > 0 and len(branches) >= 2:
            ranked = sorted(branches, key=lambda b: -b.aggregate)
            if ranked[1].aggregate - ranked[0].aggregate >= -float(self.cfg.get("judge.debate_margin", 0.8)):
                winner, transcript = await self._debate(question, ranked[0], ranked[1],
                                                        plan.budget.debate_rounds)
                report.debate_used = True
                report.debate_transcript = transcript
                report.verdict_rationale += "｜终局辩论后更新胜者"

        report.winner_branch_id = winner.branch_id
        report.final_answer = winner.answer
        report.confidence = round(min(9.9, max(1.0, winner.aggregate)), 1)
        report.scores = {b.branch_id: b.aggregate for b in branches}
        report.dimensions = {b.branch_id: dict(b.self_score) for b in branches}
        report.issues = [
            {"branch_id": b.branch_id, "issues": b.critiques}
            for b in branches if b.critiques
        ]
        report.defects = self._collect_defects(question, branches, report)
        logger.info("评判完成: 胜者=%s 置信度=%.1f 修复轮次=%d", 
                    report.winner_branch_id, report.confidence, report.repair_rounds)
        return report

    # ------------------------------------------------------------------
    async def _independent_scores(self, branches: List[ReasoningBranch]) -> None:
        """L1 独立评分：六维评分表。"""
        dim_keys = [k for k, _ in JUDGE_DIMENSIONS]
        convs, targets = [], []
        for b in branches:
            system = "你是 EISA 多层自省评判器的独立评分层。只依据评分维度严格打分，仅输出JSON。"
            user = (
                f"评分维度（各 0-10）: {', '.join(dim_keys)}\n"
                f"待评答案（分支 {b.branch_id}，范式 {b.paradigm}，人格 {b.persona}）:\n"
                f"{truncate(b.answer, 1500)}\n"
                f"【输出要求】仅输出JSON，字段: {', '.join(dim_keys)}, confidence, comments"
            )
            convs.append([Message(role="system", content=system),
                          Message(role="user", content=user)])
            targets.append(b)

        outs = await self.base_model.backend.chat_many(convs, temperature=0.2, max_tokens=2048)
        for b, out in zip(targets, outs):
            data = extract_json(out) or {}
            scores: Dict[str, float] = {}
            for k in dim_keys:
                try:
                    scores[k] = max(0.0, min(10.0, float(data.get(k, 5.0))))
                except Exception:
                    scores[k] = 5.0
            b.self_score = scores
            b.self_confidence = scores.get("correctness", 5.0)

    async def _cross_reviews(self, question: str, branches: List[ReasoningBranch]) -> None:
        """L2 交叉互评：以其他分支为参照审查每条分支。"""
        if len(branches) < 2:
            for b in branches:
                b.critiques = []
            return
        others_brief = "\n".join(f"- {b.branch_id}（{b.paradigm}）: {truncate(b.conclusion, 120)}"
                                 for b in branches)
        convs, targets = [], []
        for b in branches:
            others = "\n".join(f"- {o.branch_id}: {truncate(o.conclusion, 100)}"
                               for o in branches if o.branch_id != b.branch_id)
            system = "你是 EISA 交叉互评层：站在其他分支的视角审查目标答案的遗漏、错误与含糊之处。仅输出JSON。"
            user = (
                f"问题: {truncate(question, 300)}\n"
                f"目标分支 {b.branch_id} 的答案:\n{truncate(b.answer, 1200)}\n"
                f"其他分支结论摘要:\n{others}\n"
                f"全部分支速览:\n{others_brief[:500]}\n"
                "【输出要求】仅输出JSON，字段: branch_id, issues, penalty, comments"
            )
            convs.append([Message(role="system", content=system),
                          Message(role="user", content=user)])
            targets.append(b)

        outs = await self.base_model.backend.chat_many(convs, temperature=0.2, max_tokens=2048)
        for b, out in zip(targets, outs):
            data = extract_json(out) or {}
            issues = data.get("issues") or []
            if isinstance(issues, str):
                issues = [issues]
            b.critiques = [str(i)[:160] for i in issues][:6]
            try:
                b.cross_penalty = max(0.0, float(data.get("penalty", 0.0)))
            except Exception:
                b.cross_penalty = 0.0

    async def _contradiction_scan(self, question: str,
                                  branches: List[ReasoningBranch]) -> List[Dict[str, Any]]:
        """L3 矛盾排查：全分支结论交叉比对。"""
        if len(branches) < 2:
            return []
        listing = "\n".join(f"分支 {b.branch_id} 结论: {truncate(b.conclusion, 150)}"
                            for b in branches)
        system = "你是 EISA 矛盾排查层：检测多条结论之间的两两冲突。仅输出JSON。"
        user = (
            f"问题: {truncate(question, 300)}\n{listing}\n"
            "【输出要求】仅输出JSON，字段: has_contradiction, contradictions, notes"
        )
        out = await self.base_model.backend.chat(
            [Message(role="system", content=system), Message(role="user", content=user)],
            temperature=0.1, max_tokens=2048)
        data = extract_json(out) or {}
        items = data.get("contradictions") or []
        result: List[Dict[str, Any]] = []
        valid_ids = {b.branch_id for b in branches}
        for it in items if isinstance(items, list) else []:
            if not isinstance(it, dict):
                continue
            between = [x for x in (it.get("between") or []) if x in valid_ids]
            result.append({
                "between": between or [branches[0].branch_id, branches[-1].branch_id],
                "description": str(it.get("description", "结论冲突"))[:200],
                "severity": it.get("severity", "中"),
            })
        return result

    # ------------------------------------------------------------------
    def _aggregate(self, branches: List[ReasoningBranch],
                   contradictions: List[Dict[str, Any]]) -> None:
        """汇总：加权六维分 - 交叉扣分 - 矛盾扣分。"""
        w = self.weights or {k: 1.0 / len(JUDGE_DIMENSIONS) for k, _ in JUDGE_DIMENSIONS}
        contra_penalty: Dict[str, float] = {}
        for c in contradictions:
            p = _SEVERITY_PENALTY.get(str(c.get("severity", "中")), 1.0)
            for bid in c.get("between") or []:
                contra_penalty[bid] = contra_penalty.get(bid, 0.0) + p
        for b in branches:
            base = sum(float(b.self_score.get(k, 5.0)) * float(w.get(k, 0.0))
                       for k, _ in JUDGE_DIMENSIONS)
            b.indep = round(base, 2)
            b.aggregate = round(max(0.0, base - b.cross_penalty
                                    - contra_penalty.get(b.branch_id, 0.0)), 2)

    async def _arbitrate(self, question: str,
                         branches: List[ReasoningBranch]) -> Tuple[Dict[str, Any], ReasoningBranch]:
        """L4 终审裁决。"""
        ranked = sorted(branches, key=lambda b: -b.aggregate)
        table = "\n".join(
            f"{b.branch_id}｜综合{b.aggregate}｜独立{b.indep}｜范式{b.paradigm}｜"
            f"结论: {truncate(b.conclusion, 120)}"
            for b in ranked)
        system = "你是 EISA 终审裁决器：汇总排名与结论，选出最优分支。仅输出JSON。"
        user = (
            f"问题: {truncate(question, 300)}\n分支排名:\n{table}\n"
            "【输出要求】仅输出JSON，字段: winner_branch_id, rationale, needs_repair, confidence"
        )
        out = await self.base_model.backend.chat(
            [Message(role="system", content=system), Message(role="user", content=user)],
            temperature=0.2, max_tokens=2048)
        verdict = extract_json(out) or {}
        winner_id = str(verdict.get("winner_branch_id", ""))
        winner = next((b for b in branches if b.branch_id == winner_id), None)
        if winner is None:
            winner = ranked[0]
        return verdict, winner

    # ------------------------------------------------------------------
    async def _debate(self, question: str, a: ReasoningBranch, b: ReasoningBranch,
                      rounds: int) -> Tuple[ReasoningBranch, List[Dict[str, str]]]:
        """终局辩论：top2 分支多轮攻防后终审。"""
        transcript: List[Dict[str, str]] = []
        for r in range(max(1, int(rounds))):
            for advocate, opponent in ((a, b), (b, a)):
                system = (f"你是辩论中的 {advocate.branch_id} 方辩护人（人格 {advocate.persona}），"
                          "需要捍卫本方结论并反驳对方。仅输出JSON。")
                user = (
                    f"问题: {truncate(question, 300)}\n本方结论: {truncate(advocate.conclusion, 200)}\n"
                    f"对方结论: {truncate(opponent.conclusion, 200)}\n"
                    f"已有辩论记录:\n" +
                    "\n".join(f"[{t['side']}] {t['text'][:120]}" for t in transcript[-6:]) +
                    "\n【输出要求】仅输出JSON，字段: argument, rebuttal"
                )
                out = await self.base_model.backend.chat(
                    [Message(role="system", content=system), Message(role="user", content=user)],
                    temperature=0.7, max_tokens=2048)
                data = extract_json(out) or {}
                text = str(data.get("argument", ""))[:400]
                transcript.append({"side": advocate.branch_id, "text": text})

        system = "你是辩论终审裁判：依据辩论记录选出更可信的结论。仅输出JSON。"
        user = (
            f"问题: {truncate(question, 300)}\n"
            f"{a.branch_id} 结论: {truncate(a.conclusion, 150)}\n"
            f"{b.branch_id} 结论: {truncate(b.conclusion, 150)}\n"
            "辩论记录:\n" + "\n".join(f"[{t['side']}] {t['text'][:150]}" for t in transcript) +
            "\n【输出要求】仅输出JSON，字段: winner_branch_id, rationale"
        )
        out = await self.base_model.backend.chat(
            [Message(role="system", content=system), Message(role="user", content=user)],
            temperature=0.2, max_tokens=2048)
        verdict = extract_json(out) or {}
        wid = str(verdict.get("winner_branch_id", ""))
        winner = a if wid == a.branch_id else (b if wid == b.branch_id else
                                               (a if a.aggregate >= b.aggregate else b))
        return winner, transcript

    # ------------------------------------------------------------------
    def _collect_defects(self, question: str, branches: List[ReasoningBranch],
                         report: JudgeReport) -> List[Dict[str, Any]]:
        """从评判结果中提取失败样例（流入缺陷库）。"""
        defects: List[Dict[str, Any]] = []
        for c in report.contradictions:
            defects.append({
                "category": "逻辑矛盾",
                "description": f"分支矛盾: {c.get('description', '')}",
                "trigger_context": question[:300],
                "severity": str(c.get("severity", "中")),
                "related_ids": c.get("between") or [],
            })
        if report.confidence < 6.0:
            defects.append({
                "category": "低置信度结果",
                "description": f"胜出分支综合分仅 {report.confidence}（阈值 {self.score_threshold}）",
                "trigger_context": question[:300],
                "severity": "中",
                "related_ids": [report.winner_branch_id],
            })
        for b in branches:
            if b.aggregate < 4.0:
                defects.append({
                    "category": "分支失败样例",
                    "description": f"分支 {b.branch_id}（{b.paradigm}）综合分 {b.aggregate}，"
                                   f"结论: {truncate(b.conclusion, 100)}",
                    "trigger_context": question[:300],
                    "severity": "低",
                    "related_ids": [b.branch_id],
                })
        return defects
