# -*- coding: utf-8 -*-
"""元推理调度器 —— 「让模型思考自己该用什么方式思考」。

职责：
1. 问题分析：难度评估 + 类型识别 + 歧义度 + 是否需要长程规划；
2. 策略决策：动态选择推理范式组合、分支数量、思考预算、评审轮次、反思深度；
3. 领域放大：深耕领域包注入专属思考链与专家子路由，定向放大；
4. 自我档案守卫：读取 EISA 自我画像，对已知缺陷类别自动加强对应防线。

调度决策全程产出可读的「元推理轨迹」，便于人工审计调度合理性。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from eisa.config import Config
from eisa.core.base_model import EisaBaseModel
from eisa.core.types import (DIFFICULTY_LEVELS, QUERY_TYPES, DomainPack, Message,
                             QueryAnalysis, ReasoningPlan)
from eisa.memory.user_profile import UserProfile
from eisa.reasoning.budget import BudgetAllocator
from eisa.reasoning.paradigm import ParadigmLibrary
from eisa.utils import extract_json, get_logger, new_id, now_iso

logger = get_logger("meta")

_STRATEGY_BY_DIFFICULTY = {
    "简单": "direct",
    "中等": "dual_verify",
    "困难": "multi_branch",
    "极难": "extreme",
}

_STRATEGY_REASON = {
    "direct": "低难度问题直接链式作答，避免过度调度",
    "dual_verify": "中等难度采用双分支互证，成本与可靠性平衡",
    "multi_branch": "高难度启用多范式异构分支 + 完整多层评判",
    "extreme": "极难任务全链路火力全开：多分支 + 辩论 + 深度递归反思 + 魔鬼代言人对抗",
}


class MetaReasoningScheduler:
    """元推理调度器。"""

    def __init__(self, base_model: EisaBaseModel, paradigm_lib: ParadigmLibrary,
                 budget_allocator: BudgetAllocator, cfg: Config,
                 self_profile_store=None):
        self.base_model = base_model
        self.paradigm_lib = paradigm_lib
        self.budget_allocator = budget_allocator
        self.cfg = cfg
        self.self_profile = self_profile_store

    # ------------------------------------------------------------------
    def _heuristic_difficulty(self, text: str) -> str:
        """零成本难度启发式（基座结果仅作校准，不覆盖启发式的确定信号）。"""
        hard_markers = ["证明", "推导", "架构", "设计", "系统", "复杂", "综合",
                        "优化", "对比", "权衡", "多个", "评估"]
        hits = sum(1 for m in hard_markers if m in text)
        if len(text) > 600 or hits >= 4:
            return "极难"
        if len(text) > 300 or hits >= 2:
            return "困难"
        if len(text) < 40 and hits == 0:
            return "简单"
        return "中等"

    def _heuristic_qtype(self, text: str) -> str:
        type_map = [
            ("事实问答", ["是什么", "什么是", "谁是", "什么时候", "哪里", "多少", "定义"]),
            ("数学推理", ["数学", "证明", "计算", "概率", "几何", "方程", "推导", "积分"]),
            ("代码工程", ["代码", "函数", "bug", "调试", "实现", "重构", "API", "模块", "递归", "并发"]),
            ("任务规划", ["计划", "规划", "步骤", "方案", "排期", "流程", "里程碑"]),
            ("创意生成", ["写一个", "创作", "文案", "故事", "起名", " slogan"]),
            ("研究调查", ["调研", "综述", "前沿", "对比分析", "研究"]),
        ]
        best, best_hits = "分析推演", 0
        for qt, kws in type_map:
            hits = sum(1 for k in kws if k.lower() in text.lower())
            if hits > best_hits:
                best, best_hits = qt, hits
        return best

    # ------------------------------------------------------------------
    async def analyze_query(self, question: str, user_profile: Optional[UserProfile] = None,
                            dialog_brief: str = "") -> QueryAnalysis:
        """问题分析：启发式打底，基座精化（JSON）。"""
        heur_diff = self._heuristic_difficulty(question)
        heur_type = self._heuristic_qtype(question)
        system = "你是 EISA 元推理调度器的问题分析模块。仅输出JSON。"
        user = (
            f"问题: {question[:800]}\n"
            f"{dialog_brief[:400]}\n"
            "【输出要求】仅输出JSON，字段: difficulty, query_type, entities, ambiguity, "
            "requires_planning, domain_hint"
        )
        entities: List[str] = []
        ambiguity, domain_hint, requires_planning = 0.0, "", False
        # mock 后端跳过基座精化：避免合成 JSON 的随机噪声覆盖确定性启发式
        if self.base_model.backend.is_mock:
            return QueryAnalysis(difficulty=heur_diff, query_type=heur_type,
                                 entities=[], ambiguity=0.1,
                                 requires_planning=False, domain_hint="",
                                 raw={"heur_difficulty": heur_diff,
                                      "heur_type": heur_type, "refined": False})
        try:
            out = await self.base_model.infer(
                [Message(role="system", content=system), Message(role="user", content=user)],
                temperature=0.2, max_tokens=2048)
            data = extract_json(out.text) or {}
            if data.get("difficulty") in DIFFICULTY_LEVELS:
                heur_diff = data["difficulty"]
            if data.get("query_type") in QUERY_TYPES:
                heur_type = data["query_type"]
            if isinstance(data.get("entities"), list):
                entities = [str(e)[:40] for e in data["entities"]][:8]
            try:
                ambiguity = max(0.0, min(1.0, float(data.get("ambiguity", 0.0))))
            except Exception:
                pass
            domain_hint = str(data.get("domain_hint", ""))[:40]
            requires_planning = bool(data.get("requires_planning", False))
        except Exception as e:
            logger.warning("问题分析基座调用失败，使用纯启发式: %s", e)

        return QueryAnalysis(difficulty=heur_diff, query_type=heur_type,
                             entities=entities, ambiguity=ambiguity,
                             requires_planning=requires_planning,
                             domain_hint=domain_hint,
                             raw={"heur_difficulty": heur_diff, "heur_type": heur_type})

    # ------------------------------------------------------------------
    def decide_plan(self, analysis: QueryAnalysis,
                    domain_pack: Optional[DomainPack] = None,
                    unlimited: Optional[bool] = None) -> ReasoningPlan:
        """决策推理计划：策略 + 预算 + 范式组合 + 自我档案守卫。"""
        strategy = _STRATEGY_BY_DIFFICULTY.get(analysis.difficulty, "dual_verify")
        budget = self.budget_allocator.allocate(analysis.difficulty, analysis.query_type,
                                                domain_pack=domain_pack, unlimited=unlimited)
        n = budget.max_branches
        paradigms = self.paradigm_lib.pick_for(analysis.query_type, n)

        plan = ReasoningPlan(
            plan_id=new_id("plan"),
            strategy=strategy,
            difficulty=analysis.difficulty,
            query_type=analysis.query_type,
            paradigms=paradigms,
            budget=budget,
            reflect_depth=budget.reflect_depth,
            created_at=now_iso(),
            notes=f"元推理决策：难度[{analysis.difficulty}] 类型[{analysis.query_type}] "
                  f"→ 策略[{strategy}]；理由：{_STRATEGY_REASON.get(strategy, '')}",
        )

        # 长程规划触发：规划/工程/调查类 + 高难度
        if analysis.requires_planning and analysis.difficulty in ("困难", "极难"):
            plan.requires_planning = True
            plan.notes += "；检测到多阶段任务特征 → 启用长程任务规划"
        if analysis.query_type in ("任务规划",) and analysis.difficulty in ("困难", "极难"):
            plan.requires_planning = True

        # 自我档案守卫：已知逻辑矛盾缺陷 → 加强交叉校验轮次
        if self.self_profile is not None:
            try:
                profile = self.self_profile.load()
                known_cats = {d.get("category") for d in profile.known_defects}
                if "逻辑矛盾" in known_cats:
                    budget.judge_rounds = max(budget.judge_rounds, 2)
                    budget.debate_rounds = max(budget.debate_rounds, 1)
                    plan.notes += "；自我档案守卫：检测到历史逻辑矛盾缺陷 → 已提高交叉校验与辩论轮次"
                if "低置信度结果" in known_cats:
                    budget.reflect_depth = max(budget.reflect_depth, 2)
                    plan.notes += "；自我档案守卫：历史低置信度 → 已提高反思深度"
            except Exception as e:
                logger.debug("自我档案守卫读取失败（忽略）: %s", e)

        logger.info("元推理计划 %s: %s", plan.plan_id, plan.notes)
        return plan

    # ------------------------------------------------------------------
    def render_meta_trace(self, analysis: QueryAnalysis, plan: ReasoningPlan) -> str:
        """渲染「元推理轨迹」：展示『怎么思考』的决策依据，便于人工审计。"""
        b = plan.budget
        lines = [
            "═══ 元推理轨迹 ═══",
            f"问题分析: 难度[{analysis.difficulty}] 类型[{analysis.query_type}] "
            f"歧义度[{analysis.ambiguity:.2f}] 实体[{', '.join(analysis.entities[:4]) or '无'}]",
            f"策略选择: {plan.strategy}",
            f"范式组合: {' + '.join(plan.paradigms[:6])}" + (" ..." if len(plan.paradigms) > 6 else ""),
            f"预算分配: 分支[{b.max_branches}] 每分支token[{b.tokens_per_branch}] "
            f"评判轮次[{b.judge_rounds}] 反思深度[{b.reflect_depth}] 辩论[{b.debate_rounds}]"
            f"{' [无限模式]' if b.unlimited else ''}",
            f"决策依据: {plan.notes}",
        ]
        if plan.domain_amplified:
            lines.append(f"领域放大: 已注入专属思考链 {len(plan.domain_chain)} 步 + 专家子路由")
        if plan.requires_planning:
            lines.append("长程规划: 将拆解子目标并执行里程碑复盘")
        return "\n".join(lines)
