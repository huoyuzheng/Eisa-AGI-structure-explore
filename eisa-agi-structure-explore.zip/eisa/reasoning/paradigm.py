# -*- coding: utf-8 -*-
"""推理范式库：内置多种思考范式，支持 YAML 覆盖/扩展。

范式是元推理调度器的核心素材 —— 调度器根据问题类型挑选范式组合，
每条并行分支以不同范式推演，形成异构思路。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from eisa.config import PROJECT_ROOT
from eisa.utils import get_logger, load_json

logger = get_logger("paradigm")


@dataclass
class Paradigm:
    """单个推理范式。"""
    id: str
    name: str
    hint: str                      # 范式操作指引（注入分支系统提示词）
    applicable_types: List[str] = field(default_factory=list)
    cost_weight: float = 1.0       # 相对成本权重（供预算参考）


# 内置范式（代码级默认，YAML 可覆盖同 id 或追加新范式）
BUILTIN_PARADIGMS: List[Paradigm] = [
    Paradigm("direct_chain", "直接链式推理", "按『理解问题→列出条件→逐步推进→检验→结论』的标准链条作答。",
             ["事实问答", "分析推演"], 0.8),
    Paradigm("math_chain", "数学链推演", "先把问题形式化为符号/方程，再逐步推导，每步标注依据，最后代回验算。",
             ["数学推理"], 1.2),
    Paradigm("first_principles", "第一性原理", "剥离类比与惯例，从最基础的公理/物理约束/定义出发重建结论。",
             ["数学推理", "分析推演", "研究调查"], 1.3),
    Paradigm("proof_by_contradiction", "反证法", "假设目标结论不成立，推导出矛盾，从而确立原结论。",
             ["数学推理", "分析推演"], 1.1),
    Paradigm("engineering_deduction", "工程推演", "按『约束→方案空间→权衡→选型→风险清单』的工程流程推演，输出可落地步骤。",
             ["代码工程", "任务规划"], 1.2),
    Paradigm("critical_check", "批判性校验", "以挑错者视角审视问题：找漏洞、找反例、找未验证断言，再给修正后的结论。",
             ["事实问答", "数学推理", "代码工程", "分析推演", "研究调查"], 1.0),
    Paradigm("analogy", "类比推演", "在相邻领域寻找同构问题，迁移其解法，并明确指出类比失效之处。",
             ["分析推演", "创意生成", "研究调查"], 0.9),
    Paradigm("decomposition", "分解递归", "把问题拆成可独立求解的子问题，递归求解后按依赖关系合成。",
             ["代码工程", "任务规划", "数学推理"], 1.2),
    Paradigm("divergent", "发散联想", "先不评判地生成大量候选思路，再按新颖性×可行性双轴筛选。",
             ["创意生成"], 1.0),
    Paradigm("counterfactual", "反事实推演", "构造『如果关键条件反转/消失会怎样』的对照场景，用差异定位因果要素。",
             ["分析推演", "研究调查"], 1.1),
    Paradigm("multi_view", "多视角交叉论证", "分别以技术、用户、商业、伦理等视角独立分析，再交叉比对视角间冲突。",
             ["分析推演", "研究调查", "任务规划"], 1.3),
    Paradigm("devil_advocate", "魔鬼代言人", "专职攻击当前最有希望的结论，输出最强反驳；用于极难任务的对抗分支。",
             ["分析推演", "数学推理", "代码工程"], 1.0),
]

# 问题类型 -> 偏好范式（元调度器选型基础）
PARADIGM_BY_TYPE: Dict[str, List[str]] = {
    "数学推理": ["math_chain", "first_principles", "proof_by_contradiction", "critical_check"],
    "代码工程": ["engineering_deduction", "decomposition", "critical_check", "first_principles"],
    "任务规划": ["decomposition", "engineering_deduction", "critical_check", "multi_view"],
    "分析推演": ["multi_view", "analogy", "critical_check", "counterfactual"],
    "创意生成": ["divergent", "analogy", "multi_view", "direct_chain"],
    "事实问答": ["direct_chain", "critical_check"],
    "研究调查": ["first_principles", "multi_view", "analogy", "counterfactual"],
}
DEFAULT_SET = ["direct_chain", "critical_check", "multi_view"]


class ParadigmLibrary:
    """范式库：内置 + YAML 覆盖/扩展。"""

    def __init__(self, paradigms: Optional[Dict[str, Paradigm]] = None):
        self._paradigms: Dict[str, Paradigm] = dict(paradigms or {})

    @classmethod
    def from_config(cls, cfg=None) -> "ParadigmLibrary":
        """加载内置范式，再用 configs/paradigms.yaml 覆盖/扩展（cfg 可缺省）。"""
        table: Dict[str, Paradigm] = {p.id: p for p in BUILTIN_PARADIGMS}
        yaml_path = Path(PROJECT_ROOT / "configs" / "paradigms.yaml")
        if cfg is not None and cfg.get("paradigms_yaml"):
            yaml_path = Path(cfg.get("paradigms_yaml"))
        data = load_json(yaml_path, None) if yaml_path.suffix == ".json" else None
        if data is None:
            try:
                import yaml  # 可选依赖
                if yaml_path.exists():
                    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
            except ImportError:
                logger.warning("未安装 pyyaml，跳过范式 YAML 加载")
            except Exception as e:
                logger.warning("范式 YAML 解析失败: %s", e)
        if isinstance(data, dict):
            items = data.get("paradigms") or []
            # 兼容两种 YAML 写法：列表式 [{id:..}] 与字典式 {id: {...}}
            if isinstance(items, dict):
                items = [dict(v, id=k) if isinstance(v, dict) else {"id": k}
                         for k, v in items.items()]
            for item in items:
                if not isinstance(item, dict) or not item.get("id"):
                    continue
                old = table.get(item["id"])
                table[item["id"]] = Paradigm(
                    id=item["id"],
                    name=item.get("name", old.name if old else item["id"]),
                    hint=item.get("hint", old.hint if old else ""),
                    applicable_types=item.get("applicable_types", old.applicable_types if old else []),
                    cost_weight=float(item.get("cost_weight", old.cost_weight if old else 1.0)),
                )
            logger.info("范式库就绪：共 %d 个范式", len(table))
        return cls(table)

    # ------------------------------------------------------------------
    def get(self, pid: str) -> Optional[Paradigm]:
        return self._paradigms.get(pid)

    def all_ids(self) -> List[str]:
        return list(self._paradigms.keys())

    def pick_for(self, query_type: str, n: int) -> List[str]:
        """按问题类型选出 n 个范式 id（循环扩充，保证分支间范式差异化）。"""
        base = PARADIGM_BY_TYPE.get(query_type, DEFAULT_SET)
        valid = [p for p in base if p in self._paradigms] or list(self._paradigms.keys())
        out: List[str] = []
        for i in range(max(1, n)):
            out.append(valid[i % len(valid)])
        return out

    def describe(self, pid: str) -> str:
        p = self._paradigms.get(pid)
        return f"{p.name}（{pid}）：{p.hint}" if p else pid
