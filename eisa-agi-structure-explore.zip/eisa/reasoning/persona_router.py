# -*- coding: utf-8 -*-
"""多人格专家路由：为并行分支分配异构人格视角，制造受控的认知多样性。

每个分支由『人格 × 范式 × 温度』三重差异化构成，确保思路真正分歧，
而不是同一条思路的复读。领域包中的专家人格拥有最高优先级（专家子路由）。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from eisa.core.types import DomainPack
from eisa.utils import get_logger, hash_seed

logger = get_logger("persona")


@dataclass
class Persona:
    """单个人格视角。"""
    id: str
    name: str
    style: str                    # 思考风格描述
    strengths: List[str] = field(default_factory=list)
    guard: List[str] = field(default_factory=list)  # 需要规避的偏误


BUILTIN_PERSONAS: List[Persona] = [
    Persona("rigorous_mathematician", "严谨数学家",
            "只接受可证明/可验证的陈述，逐步推导，处处标注依据",
            ["数学推理", "逻辑严谨性"], ["过度追求形式化而忽略实用性"]),
    Persona("engineer", "工程实践者",
            "优先考虑可落地性、成本与风险，习惯给出方案对比与权衡",
            ["工程落地", "系统设计"], ["经验主义，可能忽略理论边界"]),
    Persona("skeptic", "怀疑论者",
            "默认质疑一切断言，要求证据与反例，擅长发现隐含假设",
            ["批判校验", "发现漏洞"], ["可能过度否定而缺少建设性"]),
    Persona("analogist", "类比联想者",
            "跨领域迁移同构问题的解法，善于发现隐藏的结构相似性",
            ["创意突破", "跨界迁移"], ["类比可能失真，需显式标注失效条件"]),
    Persona("devils_advocate", "魔鬼代言人",
            "专职攻击当前最优结论，构造最强反驳与最坏情形",
            ["压力测试", "风险暴露"], ["只为攻击而生，不负责建设"]),
    Persona("minimalist", "极简主义者",
            "追求最小充分解，砍掉一切非必要复杂度",
            ["方案精简", "成本控制"], ["可能漏掉必要的扩展性设计"]),
    Persona("architect", "系统架构师",
            "从全局拓扑、依赖关系与演进路径思考问题",
            ["全局观", "长期演进"], ["可能陷入过度设计"]),
    Persona("empiricist", "实证主义者",
            "一切以数据与实验说话，优先设计可证伪的检验方案",
            ["实验设计", "数据敏感"], ["在无数据场景可能僵化"]),
]


class PersonaRouter:
    """人格路由器：为 n 条分支生成差异化人格序列。"""

    def select(self, n: int, domain_pack: Optional[DomainPack] = None,
               seed: int = 0) -> List[Persona]:
        """返回 n 个人格；领域专家人格优先占用前几位（专家子路由）。"""
        pool = list(BUILTIN_PERSONAS)
        experts: List[Persona] = []
        if domain_pack is not None:
            for ep in domain_pack.expert_personas or []:
                experts.append(Persona(
                    id=str(ep.get("id") or "domain_expert"),
                    name=str(ep.get("name") or "领域专家"),
                    style=str(ep.get("style") or "以领域最佳实践为准，先列关键假设再推演"),
                    strengths=[domain_pack.name],
                    guard=["过度自信"],
                ))
        rot = seed % len(pool) if pool else 0
        ordered = pool[rot:] + pool[:rot]
        personas = experts + ordered
        if not personas:
            personas = pool
        return [personas[i % len(personas)] for i in range(max(1, n))]

    def describe(self, persona: Persona) -> str:
        guard = "；".join(persona.guard) if persona.guard else "无"
        return f"{persona.name}（{persona.id}）：{persona.style}。需规避偏误：{guard}"
