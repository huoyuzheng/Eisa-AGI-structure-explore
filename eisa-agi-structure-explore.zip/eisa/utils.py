# -*- coding: utf-8 -*-
"""EISA 通用工具集：日志、JSON 持久化、ID 生成、JSON 提取、关键词抽取等。

本模块刻意保持零第三方依赖，保证框架在最小环境下可运行。
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import logging
import os
import random
import re
import time
import uuid
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar

T = TypeVar("T")

_CJK_RE = re.compile(r"[\u4e00-\u9fff]+")
_ASCII_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_\-]{2,}")

# 常见英文虚词停用表（仅用于关键词统计，不影响其他逻辑）
_STOPWORDS = {
    "the", "and", "for", "with", "this", "that", "what", "how", "why", "when",
    "which", "please", "give", "tell", "about", "from", "into", "your", "you",
    "are", "can", "will", "should", "could", "would", "there", "their", "have",
    "been", "more", "some", "than", "then", "also", "very", "just", "need",
}


def now_iso() -> str:
    """当前本地时间的 ISO 紧凑串。"""
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())


def new_id(prefix: str) -> str:
    """生成带时间戳与随机后缀的唯一 ID。"""
    return f"{prefix}_{time.strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:6]}"


def hash_seed(text: str) -> int:
    """将任意文本映射为稳定整数种子（用于确定性伪随机，保证可复现）。"""
    return int(hashlib.md5(text.encode("utf-8", "ignore")).hexdigest()[:8], 16)


def ensure_dir(path: Any) -> Path:
    """确保目录存在并返回 Path。"""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


_LOGGERInitialized = False


def get_logger(name: str) -> logging.Logger:
    """统一日志器：格式一致，级别可用环境变量 EISA_LOG_LEVEL 调整。"""
    global _LOGGERInitialized
    if not _LOGGERInitialized:
        level = os.environ.get("EISA_LOG_LEVEL", "INFO").upper()
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%H:%M:%S"))
        root = logging.getLogger("eisa")
        root.addHandler(handler)
        root.setLevel(getattr(logging, level, logging.INFO))
        _LOGGERInitialized = True
    return logging.getLogger(f"eisa.{name}")


def load_json(path: Any, default: Any = None) -> Any:
    """读取 JSON 文件；失败时返回 default。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path: Any, obj: Any) -> None:
    """原子化写入 JSON 文件（先写临时文件再替换，避免写坏）。"""
    p = Path(path)
    ensure_dir(p.parent)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def append_jsonl(path: Any, obj: Dict[str, Any]) -> None:
    """向 JSONL 文件追加一行。"""
    p = Path(path)
    ensure_dir(p.parent)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def read_jsonl(path: Any) -> List[Dict[str, Any]]:
    """读取整个 JSONL 文件，损坏行自动跳过。"""
    out: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        pass
    return out


def extract_json(text: Optional[str]) -> Optional[Any]:
    """从模型输出中稳健地提取第一个 JSON 对象/数组。

    支持代码围栏包裹、前后混有说明文字、尾逗号等情况；
    解析失败返回 None，由调用方做兜底。
    """
    if not text:
        return None
    candidates: List[str] = []
    m = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    if m:
        candidates.append(m.group(1))
    candidates.append(text)
    for c in candidates:
        c = c.strip()
        for opener, closer in (("{", "}"), ("[", "]")):
            start = c.find(opener)
            if start == -1:
                continue
            depth = 0
            in_str = False
            esc = False
            for i in range(start, len(c)):
                ch = c[i]
                if in_str:
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                else:
                    if ch == '"':
                        in_str = True
                    elif ch == opener:
                        depth += 1
                    elif ch == closer:
                        depth -= 1
                        if depth == 0:
                            frag = c[start:i + 1]
                            try:
                                return json.loads(frag)
                            except Exception:
                                try:
                                    return json.loads(re.sub(r",\s*([}\]])", r"\1", frag))
                                except Exception:
                                    break
    return None


def top_terms(text: str, k: int = 6) -> List[str]:
    """轻量关键词抽取：英文整词 + 中文 2-gram 频次统计，无需分词器。"""
    if not text:
        return []
    counts: Counter = Counter()
    for w in _ASCII_WORD_RE.findall(text):
        lw = w.lower()
        if lw not in _STOPWORDS:
            counts[lw] += 1
    for chunk in _CJK_RE.findall(text):
        for i in range(len(chunk) - 1):
            counts[chunk[i:i + 2]] += 1
    return [t for t, _ in counts.most_common(k)]


def truncate(text: Optional[str], limit: int = 600) -> str:
    """截断文本到指定长度并附注原始长度。"""
    if text is None:
        return ""
    t = str(text)
    if len(t) <= limit:
        return t
    return t[:limit] + f"...(已截断，原文共{len(t)}字)"


def find_eisa_paths(text: str) -> List[str]:
    """从文本中提取 eisa/ 或 configs/ 下的文件路径（供补丁目标定位使用）。"""
    if not text:
        return []
    hits = re.findall(r"(?:eisa|configs)/[\w\-./]+\.(?:py|yaml|yml|json)", text)
    seen: List[str] = []
    for h in hits:
        if h not in seen:
            seen.append(h)
    return seen


def dc_to(obj: Any) -> Dict[str, Any]:
    """dataclass -> dict（递归）。"""
    return dataclasses.asdict(obj)


def dc_from(cls: Type[T], data: Optional[Dict[str, Any]]) -> T:
    """dict -> dataclass（过滤未知字段，缺失字段用默认值）。"""
    if not isinstance(data, dict):
        try:
            return cls()
        except Exception:
            raise ValueError(f"无法从 {data!r} 构造 {cls.__name__}（必填字段缺失）")
    fields = {f.name for f in dataclasses.fields(cls)}
    kwargs = {k: v for k, v in data.items() if k in fields}
    return cls(**kwargs)


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """递归合并字典（override 优先），返回新字典。"""
    out = dict(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def append_unique(lst: List[str], item: str, cap: int = 20) -> None:
    """去重追加并封顶（用于画像列表类字段，防止无限膨胀）。"""
    s = str(item).strip()
    if s and s not in lst:
        lst.append(s)
        while len(lst) > cap:
            lst.pop(0)


def random_from(seed_text: str, items: List[Any]) -> Any:
    """按文本种子从列表中确定性选取一个元素。"""
    rnd = random.Random(hash_seed(seed_text))
    return rnd.choice(items) if items else None
