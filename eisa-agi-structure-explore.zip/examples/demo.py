# -*- coding: utf-8 -*-
"""EISA 演示脚本：一次跑通「对话推理 → 长程任务 → 自迭代提案」全链路。

用法: python examples/demo.py
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from eisa.orchestrator import EisaOrchestrator  # noqa: E402
from eisa.utils import get_logger  # noqa: E402

logger = get_logger("demo")


async def run_demo() -> None:
    orch = EisaOrchestrator()
    user = "demo_user"

    print("\n" + "=" * 62)
    print("演示 1｜简单事实问答（direct 策略）")
    print("=" * 62)
    r1 = await orch.handle_message(user, "什么是递归？")
    print(r1.brief())
    print("\n答案:", r1.answer[:400])

    print("\n" + "=" * 62)
    print("演示 2｜困难推理（多分支并行 + 多层评判 + 递归反思）")
    print("=" * 62)
    r2 = await orch.handle_message(
        user, "请证明：任意大于 2 的偶数都可以表示为两个质数之和，并系统性地分析这个命题的证明难点与现有路径的局限。")
    print(r2.brief())
    for b in r2.branches[:6]:
        print(f"  - 分支[{b['branch_id']}] 范式[{b['paradigm']}] 人格[{b['persona']}] "
              f"综合分[{b['aggregate']}] 状态[{b['status']}]")
    print("\n答案:", r2.answer[:400])

    print("\n" + "=" * 62)
    print("演示 3｜长程任务（自动拆解 + 里程碑复盘）")
    print("=" * 62)
    tr = await orch.run_long_task(user, "设计一个高可用的分布式消息队列系统，包含容量规划、故障恢复与监控告警方案")
    print(tr.tree_text())

    print("\n" + "=" * 62)
    print("演示 4｜自迭代短板分析 + 提案生成（全部待人工审核）")
    print("=" * 62)
    out = await orch.analyze_and_propose()
    for p in out["pending_patches"]:
        print(f"  [补丁待审] {p['patch_id']} ({p['kind']}->{p['target_file']}, 风险{p['risk_level']}): {p['description'][:60]}")
    for pr in out["pending_proposals"]:
        print(f"  [提案待审] {pr['proposal_id']}: {pr['name']}")

    print("\n" + "=" * 62)
    print("演示 5｜EISA 自我画像（自省档案）")
    print("=" * 62)
    print(orch.self_profile.render_for_prompt())

    print("\n运行数据目录:", orch.paths["root"])
    print("补丁审核: python -m eisa.cli patch list / approve <id> / apply <id>")


if __name__ == "__main__":
    asyncio.run(run_demo())
