# -*- coding: utf-8 -*-
"""端到端测试：记忆 / 推理管线 / 元调度 / 进化闸门 / 扩展加载。

既可用 pytest 运行，也可直接 `python tests/run_tests.py` 执行。
"""
import asyncio
import os
import shutil
import sys
import tempfile
from pathlib import Path

# 数据目录沙箱化：避免污染项目 data/
_SANDBOX = tempfile.mkdtemp(prefix="eisa_test_")
os.environ["EISA_DATA_DIR"] = _SANDBOX
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def _cleanup():
    shutil.rmtree(_SANDBOX, ignore_errors=True)


# ---------------------------------------------------------------------------
# 记忆层
# ---------------------------------------------------------------------------

def test_user_profile_roundtrip():
    from eisa.memory.user_profile import UserProfileStore
    from pathlib import Path
    store = UserProfileStore(Path(_SANDBOX) / "users", None)
    p = store.load("tester")
    p.expertise["软件工程"] = 4
    p.long_term_goals.append("构建 AGI 框架")
    store.save(p)
    p2 = store.load("tester")
    assert p2.expertise.get("软件工程") == 4
    assert "构建 AGI 框架" in p2.long_term_goals


def test_defect_library_dedupe_and_increment():
    from eisa.memory.defect_library import DefectLibrary
    from pathlib import Path
    lib = DefectLibrary(Path(_SANDBOX) / "defects" / "defect_library.json")
    lib.add("逻辑矛盾", "分支A与分支B结论相反", "测试上下文", "高")
    lib.add("逻辑矛盾", "分支A与分支B结论相反", "测试上下文", "高")
    assert len(lib.list_open()) == 1
    assert lib.list_open()[0]["frequency"] == 2


def test_self_profile_render():
    from eisa.memory.self_profile import SelfProfileStore
    from pathlib import Path
    store = SelfProfileStore(Path(_SANDBOX) / "self_profile.json")
    text = store.render_for_prompt()
    assert "EISA自我档案" in text or "EISA 自我档案" in text


# ---------------------------------------------------------------------------
# 元调度与预算
# ---------------------------------------------------------------------------

def test_meta_scheduler_difficulty_mapping():
    from eisa.core.types import QueryAnalysis
    from eisa.orchestrator import EisaOrchestrator

    orch = EisaOrchestrator()
    sched = orch.scheduler
    q = "请证明哥德巴赫猜想对极大偶数的适用性并系统分析证明难点"
    diff = sched._heuristic_difficulty(q)
    qtype = sched._heuristic_qtype(q)
    assert diff in ("困难", "极难")
    ana = QueryAnalysis(difficulty=diff, query_type=qtype, entities=[],
                        ambiguity=0.2, requires_planning=False, domain_hint="")
    plan = sched.decide_plan(ana, None)
    assert plan.strategy in ("multi_branch", "extreme")
    assert plan.budget.max_branches >= 4
    assert len(plan.paradigms) == plan.budget.max_branches


def test_budget_unlimited_mode():
    from eisa.reasoning.budget import BudgetAllocator
    from eisa.config import load_config
    alloc = BudgetAllocator(load_config(None))
    b = alloc.allocate("困难", "数学推理", unlimited=True)
    assert b.unlimited and b.max_branches >= 8 and b.tokens_per_branch >= 32768 * 4


# ---------------------------------------------------------------------------
# 推理管线（mock 后端端到端）
# ---------------------------------------------------------------------------

def test_handle_message_simple():
    from eisa.orchestrator import EisaOrchestrator
    orch = EisaOrchestrator()
    r = asyncio.run(orch.handle_message("tester", "什么是递归？"))
    assert r.answer, "答案不应为空"
    assert r.plan is not None and r.plan.strategy == "direct"
    assert len(r.branches) >= 1  # direct 基线 1 条；unlimited 模式可能加倍
    # 交互已落盘
    recs = orch.dialogs.recent("tester", 1)
    assert recs and recs[0]["query"].startswith("什么是递归")


def test_handle_message_hard_multibranch():
    from eisa.orchestrator import EisaOrchestrator
    orch = EisaOrchestrator()
    r = asyncio.run(orch.handle_message(
        "tester", "请系统性地设计一个万亿参数模型的推理调度架构，证明其各组件在极端负载下依然稳定，并分析失败模式。"))
    assert r.plan.strategy in ("multi_branch", "extreme")
    assert len(r.branches) >= 4, "困难问题应产生多分支"
    assert r.judge is not None and r.judge.winner_branch_id
    # 多分支分支 ID 唯一
    ids = [b["branch_id"] for b in r.branches]
    assert len(ids) == len(set(ids))


def test_long_task_planning():
    from eisa.orchestrator import EisaOrchestrator
    orch = EisaOrchestrator()
    tr = asyncio.run(orch.run_long_task("tester", "设计分布式消息队列：容量规划、故障恢复与监控告警"))
    assert tr.final_answer
    assert len(tr.nodes) >= 2
    assert any(n.status == "done" for n in tr.nodes)


# ---------------------------------------------------------------------------
# 进化闸门（核心安全约束：无人工审核不得改代码）
# ---------------------------------------------------------------------------

def test_evolution_gate_full_flow():
    from eisa.orchestrator import EisaOrchestrator
    from pathlib import Path
    orch = EisaOrchestrator()
    out = asyncio.run(orch.analyze_and_propose())
    patch_ids = [p["patch_id"] for p in out["pending_patches"]]
    assert patch_ids, "应至少生成一个待审补丁"

    pid = patch_ids[0]
    # 未 approve 时 apply 必须被拒绝
    denied = orch.iterate.apply_patch(pid)
    assert denied["ok"] is False and "审核" in denied["message"]

    # approve 后 apply 成功且目标文件被修改
    ok = orch.iterate.approve_patch(pid, note="测试批准")
    assert ok["ok"] is True
    applied = orch.iterate.apply_patch(pid)
    assert applied["ok"] is True

    p = orch.iterate.load_patch(pid)
    target = Path(p.target_file)
    assert "score_threshold: 6.5" in target.read_text(encoding="utf-8")

    # rollback 恢复原状
    rb = orch.iterate.rollback_patch(pid)
    assert rb["ok"] is True
    assert "score_threshold: 7.0" in target.read_text(encoding="utf-8")


def test_proposal_approve_materializes_extension():
    from eisa.orchestrator import EisaOrchestrator
    from pathlib import Path
    orch = EisaOrchestrator()
    out = asyncio.run(orch.analyze_and_propose())
    prop_ids = [p["proposal_id"] for p in out["pending_proposals"]]
    assert prop_ids
    pid = prop_ids[0]
    res = orch.proposals.approve_proposal(pid, note="测试批准")
    assert res["ok"] is True
    mod_file = Path(res["module_file"])
    assert mod_file.exists(), "批准后应物化为扩展模块文件"
    # 新会话的加载器应识别已登记扩展（加载发生在编排器初始化时）
    orch2 = EisaOrchestrator()
    caps = orch2.extensions.capabilities
    assert any(c.name for c in caps), "新会话应加载已注册扩展"


# ---------------------------------------------------------------------------
# 扩展钩子
# ---------------------------------------------------------------------------

def test_extension_hooks_run():
    from eisa.orchestrator import EisaOrchestrator
    orch = EisaOrchestrator()
    ctx = {"question": "测试", "plan": None}
    ctx2 = orch.extensions.run_pre_reasoning(ctx)
    assert "question" in ctx2
    # post_reasoning 传入非 EisaResult 对象也不应崩溃
    orch.extensions.run_post_reasoning(ctx2, object())


def run_all():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed, failed = 0, 0
    for t in tests:
        try:
            t()
            print(f"[PASS] {t.__name__}")
            passed += 1
        except Exception as e:  # noqa: BLE001
            import traceback
            traceback.print_exc()
            print(f"[FAIL] {t.__name__}: {e}")
            failed += 1
    print(f"\n结果: {passed} 通过, {failed} 失败")
    _cleanup()
    return failed


if __name__ == "__main__":
    sys.exit(1 if run_all() else 0)
